# ULTRA AI FINAL

Natywna aplikacja Android łącząca najlepsze elementy trzech wersji projektu **ULTRA AI**.

**Pakiet:** `pl.ultraai.android`  
**Wersja:** 1.0.0  
**Min SDK:** 28 (Android 9) | **Target/Compile SDK:** 35  
**Stack:** Kotlin | Jetpack Compose | Material 3 | MVVM | Room | OkHttp | DataStore | Android Keystore | Kotlin Coroutines / StateFlow | KSP

---

## Źródła scalone

| Źródło | Rola w integracji |
|--------|-------------------|
| **ULTRA-AI-Android.zip** (`pl.ultraai.android`) | **Baza finalna** – najbardziej kompletna implementacja (czat ze streamingiem, Bitwa AI, Zespół 5 ról, Game Center z silnikami, Tools, Keystore, pricing, speech, dokument analyzer, backup) |
| **UltraAI-Android-Source.zip** / **UltraAI_Android_Project.zip** (`com.ultraai.app`) | Porównanie architektury (Hilt, osobna nawigacja, ekrany Home). Funkcje pokryte przez bazę SRC1; unikalne elementy strukturalne uwzględnione koncepcyjnie |
| Raport techniczny trzeciego projektu | **Nie dostarczono** osobnego pliku raportu w artefaktach. Integracja oparta wyłącznie na kodzie z trzech ZIP-ów |

**Zasada:** jedna aplikacja, jeden pakiet, jedna baza Room, bez atrap przycisków.

---

## Funkcje zaimplementowane

### AI Chat
- Rozmowy z modelami Gemini i Groq
- Historia rozmów (Room)
- Streaming odpowiedzi (OkHttp SSE / stream)
- Zatrzymywanie generowania
- System prompt / postacie
- Temperatura, limit tokenów

### Gemini API & Groq API
- Lista modeli z API (test połączenia)
- Zapytania i streaming
- Obsługa błędów, limitów, braku sieci

### API Key Manager
- Wiele kluczy (Gemini / Groq)
- Testowanie połączeń i pobieranie modeli
- Bezpieczne przechowywanie: **Android Keystore (AES-256-GCM)**
- Brak kluczy w kodzie źródłowym i w logach

### AI Battle
- Porównanie 2–5 modeli jednocześnie
- Pomiary czasu (latency) i szacunkowych kosztów
- Głosowanie użytkownika
- Sędzia AI (osobny model oceniający odpowiedzi)

### AI Team
- Pięć ról: **Architekt | Analityk | Programista | Tester | Recenzent**
- Przypisanie modelu do roli, włączanie/wyłączanie ról
- Sekwencyjne wykonanie z kontekstami poprzednich kroków

### AI Characters
- Tworzenie, edycja, usuwanie postaci
- Własne osobowości / system prompts
- Użycie w czacie

### AI Tools
- Research, Code Studio, Writer, Translator, Tutor
- Prompt Generator + biblioteka szablonów
- Document Analyzer (PDF/TXT, chunking)
- Vision (analiza obrazów – zależnie od modelu)
- Statystyki i historia kosztów
- Backup eksport/import JSON

### Game Center
- 2048
- Connect Four
- Kółko i krzyżyk (Minimax)
- Szachy (pełny silnik: ruchy legalne, szach/mat/pat, roszada, en passant, promocja)
- Kamień-papier-nożyce
- Elementy RPG / dodatkowe tryby w module gier

### Ustawienia
- Motyw: jasny / ciemny / system
- Temperatura, streaming
- PIN / biometria (opcjonalna blokada)
- Prywatność (brak backupu w chmurze domyślnie)
- Statystyki użycia

### Room Database
- Historia rozmów, wiadomości
- Postacie, klucze API (zaszyfrowane)
- Szablony promptów, logi użycia
- Ustawienia aplikacji

---

## Wymagania

- **Android Studio** Ladybug (2024.2+) lub nowszy  
- **JDK 17**  
- **Android SDK Platform 35**  
- Telefon Android 9+ lub emulator  

---

## Budowa APK

```bash
# W katalogu projektu
chmod +x gradlew
./gradlew assembleDebug
```

Wynik:
```
app/build/outputs/apk/debug/app-debug.apk
```

Instalacja:
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

Lub: **Run >** w Android Studio.

### CI (GitHub Actions)

Workflow: `.github/workflows/build-apk.yml`  
Buduje debug APK na `push` / `workflow_dispatch` i udostępnia artefakt `app-debug-apk`.

---

## Pierwsza konfiguracja

1. Uruchom aplikację.
2. Przejdź do **Moduły / Ustawienia → Klucze API**.
3. Dodaj klucz:
   - Gemini: https://aistudio.google.com/apikey  
   - Groq: https://console.groq.com/keys  
4. Kliknij **Testuj** – aplikacja zweryfikuje klucz i pobierze listę modeli.
5. Wybierz model w czacie / bitwie / zespole.

Klucze **nigdy** nie są zapisywane w plain text w repozytorium ani logowane w pełnej postaci.

---

## Struktura katalogów (skrót)

```
ULTRA-AI-FINAL/
├── app/src/main/java/pl/ultraai/android/
│   ├── MainActivity.kt
│   ├── UltraAiApplication.kt          # AppContainer (DI ręczne)
│   ├── core/                          # security, pricing, files, speech
│   ├── data/
│   │   ├── local/                     # Room, DataStore, DAO, Entity
│   │   ├── remote/                    # Gemini, Groq, UnifiedAiGateway
│   │   └── repository/
│   ├── domain/model/
│   └── ui/                            # chat, battle, team, games, tools, settings, characters, theme
├── gradle/libs.versions.toml
├── .github/workflows/build-apk.yml
├── README.md
├── TEST_REPORT.md
└── README_INSTALACJA.md
```

Architektura: **MVVM + Repository + AppContainer** (bez Hilt – świadomy wybór bazowego projektu SRC1; łatwo dodać Hilt później). StateFlow + Coroutines.

---

## Znane ograniczenia

1. **Brak pełnego buildu APK w środowisku integracyjnym** – brak Android SDK / emulatora. Kod i Gradle są przygotowane pod `assembleDebug` lokalnie lub w GitHub Actions.
2. **Hilt** – nie użyty w finalnej bazie (SRC1). SRC3 miał Hilt; funkcje są równoważne przez `AppContainer` + `ViewModelProvider.Factory`.
3. **Raport trzeciego projektu** – nie był dostępny jako plik; nie dodano funkcji „z raportu” bez kodu źródłowego.
4. **Vision / niektóre modele Gemini** – zależne od dostępności modelu i limitu API użytkownika.
5. **Szachy AI** – silnik reguł jest pełny; głębokość AI przeciwnika jest ograniczona (minimax / heurystyka, nie silnik NN).
6. **Release signing** – debug APK bez własnego keystore; release wymaga `keystore.properties` (nie w repo).

Szczegóły: **TEST_REPORT.md**.

---

## Licencja / bezpieczeństwo

- Nie commituj prawdziwych kluczy API.
- `allowBackup="false"` w manifeście.
- Keystore AES-GCM do kluczy użytkownika.
- Cleartext traffic wyłączony.

---

*ULTRA AI FINAL – scalenie z naciskiem na działający kod, nie atrapy.*
