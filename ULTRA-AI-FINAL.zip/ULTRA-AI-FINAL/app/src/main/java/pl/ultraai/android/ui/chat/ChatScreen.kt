package pl.ultraai.android.ui.chat

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Archive
import androidx.compose.material.icons.outlined.AttachFile
import androidx.compose.material.icons.outlined.AutoFixHigh
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.CreateNewFolder
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.IosShare
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import pl.ultraai.android.core.pricing.CostEstimator
import pl.ultraai.android.core.speech.SpeechAndTtsManager
import pl.ultraai.android.data.local.entity.ChatMessageEntity
import pl.ultraai.android.ui.components.CostConfirmationDialog
import pl.ultraai.android.ui.components.EmptyApiBanner
import pl.ultraai.android.ui.components.MarkdownText
import pl.ultraai.android.ui.components.ModelPickerBottomSheet

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    speechManager: SpeechAndTtsManager,
    onNavigateToSettingsApi: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    var inputText by remember { mutableStateOf("") }
    var showModelSheet by remember { mutableStateOf(false) }
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var newFolderName by remember { mutableStateOf("") }

    val isListening by speechManager.isListening.collectAsState()
    val listState = rememberLazyListState()

    val attachmentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            viewModel.attachFile(context, uri)
        }
    }

    LaunchedEffect(state.editingMessage) {
        state.editingMessage?.let { inputText = it.content }
    }

    LaunchedEffect(state.messages.size, state.streamingText) {
        if (state.messages.isNotEmpty()) {
            listState.animateScrollToItem((state.messages.size - 1).coerceAtLeast(0))
        }
    }

    if (showModelSheet) {
        ModelPickerBottomSheet(
            models = state.availableModels,
            selectedModelId = state.selectedModel?.id.orEmpty(),
            selectionMode = state.settings.selectionMode,
            favoriteIds = state.settings.favoriteModelIds,
            onSelectMode = viewModel::setSelectionMode,
            onSelectModel = viewModel::selectModel,
            onToggleFavorite = viewModel::toggleFavoriteModel,
            onDismiss = { showModelSheet = false }
        )
    }

    state.pendingCostConfirmation?.let { (_, estimate) ->
        CostConfirmationDialog(
            estimate = estimate,
            modelName = state.selectedModel?.displayName ?: "Model AI",
            onConfirm = viewModel::confirmAndSendPending,
            onCancel = viewModel::dismissCostDialog
        )
    }

    if (showNewFolderDialog) {
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            title = { Text("Nowy folder rozmów") },
            text = {
                OutlinedTextField(
                    value = newFolderName,
                    onValueChange = { newFolderName = it },
                    label = { Text("Nazwa folderu") },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.createFolder(newFolderName)
                    newFolderName = ""
                    showNewFolderDialog = false
                }) { Text("Utwórz") }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false }) { Text("Anuluj") }
            }
        )
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(modifier = Modifier.widthIn(max = 320.dp)) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Rozmowy i foldery", style = MaterialTheme.typography.titleLarge)
                        IconButton(onClick = { showNewFolderDialog = true }) {
                            Icon(Icons.Outlined.CreateNewFolder, contentDescription = "Nowy folder")
                        }
                    }

                    OutlinedTextField(
                        value = state.searchQuery,
                        onValueChange = viewModel::updateSearchQuery,
                        placeholder = { Text("Szukaj w historii...") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = state.selectedFolderId == null && !state.showArchived,
                            onClick = {
                                viewModel.selectFolder(null)
                                if (state.showArchived) viewModel.toggleShowArchived()
                            },
                            label = { Text("Wszystkie") }
                        )
                        state.folders.forEach { folder ->
                            FilterChip(
                                selected = state.selectedFolderId == folder.id,
                                onClick = { viewModel.selectFolder(folder.id) },
                                label = { Text(folder.name) }
                            )
                        }
                        FilterChip(
                            selected = state.showArchived,
                            onClick = viewModel::toggleShowArchived,
                            label = { Text("Archiwum") }
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(state.sessions, key = { it.id }) { session ->
                            val selected = session.id == state.activeSession?.id
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (selected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectSession(session.id)
                                        scope.launch { drawerState.close() }
                                    }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = (if (session.isPinned) "[P] " else "") + session.title,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            fontWeight = FontWeight.Medium
                                        )
                                        Text(
                                            text = "${session.modelId} • ${session.totalInputTokens + session.totalOutputTokens} tok.",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(onClick = { viewModel.togglePin(session) }, modifier = Modifier.size(30.dp)) {
                                        Icon(Icons.Outlined.PushPin, contentDescription = "Przypnij", modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(onClick = { viewModel.toggleArchive(session) }, modifier = Modifier.size(30.dp)) {
                                        Icon(Icons.Outlined.Archive, contentDescription = "Archiwizuj", modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(onClick = { viewModel.deleteSession(session) }, modifier = Modifier.size(30.dp)) {
                                        Icon(Icons.Outlined.Delete, contentDescription = "Usuń", modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Outlined.History, contentDescription = "Historia rozmów")
                        }
                    },
                    title = {
                        Column(modifier = Modifier.clickable { showModelSheet = true }) {
                            Text(
                                text = state.activeSession?.title ?: if (state.isIncognitoDraft) "Czat prywatny" else "ULTRA AI Czat",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = (state.selectedModel?.displayName ?: "Wybierz model") + " • ${state.settings.selectionMode.labelPl}",
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.startNewChat(incognito = !state.isIncognitoDraft) }) {
                            Icon(
                                Icons.Outlined.VisibilityOff,
                                contentDescription = "Tryb incognito",
                                tint = if (state.isIncognitoDraft) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = {
                            val md = viewModel.exportCurrentSessionMarkdown()
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, md)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Eksportuj rozmowę"))
                        }) {
                            Icon(Icons.Outlined.IosShare, contentDescription = "Eksportuj rozmowę")
                        }
                        IconButton(onClick = { viewModel.startNewChat() }) {
                            Icon(Icons.Outlined.Add, contentDescription = "Nowa rozmowa")
                        }
                    }
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (state.availableModels.isEmpty()) {
                    EmptyApiBanner(onGoToSettings = onNavigateToSettingsApi)
                }

                state.errorBanner?.let { err ->
                    Surface(
                        color = MaterialTheme.colorScheme.error.copy(alpha = 0.16f),
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(err, color = MaterialTheme.colorScheme.error, modifier = Modifier.weight(1f))
                            IconButton(onClick = viewModel::clearError, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Outlined.Close, contentDescription = "Zamknij")
                            }
                        }
                    }
                }

                // Pasek statystyk aktywnej rozmowy
                state.activeSession?.let { session ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                            .padding(horizontal = 14.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Tokeny: ${session.totalInputTokens + session.totalOutputTokens}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Koszt rozmowy: ${CostEstimator.formatUsd(session.totalCostUsd)}",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item { Spacer(modifier = Modifier.height(6.dp)) }

                    if (state.messages.isEmpty() && !state.isGenerating) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 32.dp, horizontal = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("Witaj w ULTRA AI", style = MaterialTheme.typography.headlineMedium)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Szybkie komendy: /tlumacz, /kod, /skrot, /sprawdz • Obsługa PDF, TXT i obrazów • Streaming w czasie rzeczywistym",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    items(state.messages, key = { it.id }) { message ->
                        ChatMessageBubble(
                            message = message,
                            isLastModel = message == state.messages.lastOrNull { it.role == "model" },
                            onCopy = { clipboard.setText(AnnotatedString(message.content)) },
                            onSpeak = { speechManager.speak(message.content) },
                            onEdit = { viewModel.beginEditMessage(message) },
                            onRegenerate = viewModel::regenerateLastResponse,
                            onContinue = viewModel::continueLastResponse
                        )
                    }

                    if (state.isGenerating) {
                        item {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surface,
                                tonalElevation = 1.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text(
                                        text = "${state.selectedModel?.displayName ?: "AI"} pisze...",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    MarkdownText(
                                        markdown = state.streamingText.ifBlank { "Oczekiwanie na pierwsze tokeny..." }
                                    )
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(6.dp)) }
                }

                // Podgląd załącznika lub edycji
                state.pendingAttachment?.let { att ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AssistChip(
                            onClick = viewModel::clearAttachment,
                            label = { Text("Załącznik: ${att.displayName}") },
                            trailingIcon = { Icon(Icons.Outlined.Close, contentDescription = "Usuń", modifier = Modifier.size(16.dp)) }
                        )
                    }
                }

                if (state.editingMessage != null) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                            .padding(horizontal = 12.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Edytujesz wcześniejszą wiadomość", style = MaterialTheme.typography.labelMedium)
                        TextButton(onClick = {
                            viewModel.cancelEditMessage()
                            inputText = ""
                        }) { Text("Anuluj") }
                    }
                }

                // Pasek wprowadzania wiadomości
                Surface(
                    tonalElevation = 3.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                        Row(
                            verticalAlignment = Alignment.Bottom,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    attachmentLauncher.launch(arrayOf("text/*", "application/pdf", "image/*", "*/*"))
                                }
                            ) {
                                Icon(Icons.Outlined.AttachFile, contentDescription = "Załącz plik")
                            }

                            IconButton(
                                onClick = {
                                    if (isListening) {
                                        speechManager.stopListening()
                                    } else {
                                        speechManager.startListening(
                                            onPartialOrFinal = { spoken, isFinal ->
                                                if (isFinal) {
                                                    inputText = if (inputText.isBlank()) spoken else "$inputText $spoken"
                                                }
                                            },
                                            onError = {}
                                        )
                                    }
                                }
                            ) {
                                Icon(
                                    Icons.Outlined.Mic,
                                    contentDescription = "Mowa na tekst",
                                    tint = if (isListening) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            OutlinedTextField(
                                value = inputText,
                                onValueChange = { inputText = it },
                                placeholder = { Text("Napisz wiadomość lub /kod...") },
                                maxLines = 5,
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(18.dp)
                            )

                            if (inputText.length > 10 && !state.isGenerating) {
                                IconButton(
                                    onClick = {
                                        viewModel.optimizePromptInPlace(inputText) { improved ->
                                            inputText = improved
                                        }
                                    }
                                ) {
                                    Icon(Icons.Outlined.AutoFixHigh, contentDescription = "Ulepsz prompt")
                                }
                            }

                            if (state.isGenerating) {
                                IconButton(onClick = viewModel::stopGeneration) {
                                    Icon(Icons.Outlined.Stop, contentDescription = "Zatrzymaj", tint = MaterialTheme.colorScheme.error)
                                }
                            } else {
                                IconButton(
                                    onClick = {
                                        val toSend = inputText
                                        inputText = ""
                                        viewModel.sendMessage(toSend)
                                    }
                                ) {
                                    Icon(Icons.AutoMirrored.Outlined.Send, contentDescription = "Wyślij", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ChatMessageBubble(
    message: ChatMessageEntity,
    isLastModel: Boolean,
    onCopy: () -> Unit,
    onSpeak: () -> Unit,
    onEdit: () -> Unit,
    onRegenerate: () -> Unit,
    onContinue: () -> Unit
) {
    val isUser = message.role == "user"
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = when {
                message.isError -> MaterialTheme.colorScheme.error.copy(alpha = 0.14f)
                isUser -> MaterialTheme.colorScheme.primaryContainer
                else -> MaterialTheme.colorScheme.surface
            },
            tonalElevation = if (isUser) 0.dp else 1.dp,
            modifier = Modifier.widthIn(max = 360.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                if (!isUser) {
                    Text(
                        text = message.modelUsed ?: "ULTRA AI",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }
                message.attachmentName?.let {
                    Text(
                        text = "[zal] $it",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                }

                MarkdownText(markdown = message.content)

                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isUser) {
                            "${message.inputTokens} tok."
                        } else {
                            "${message.outputTokens} tok. • ${message.latencyMs} ms • ${CostEstimator.formatUsd(message.costUsd)}"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row {
                        IconButton(onClick = onCopy, modifier = Modifier.size(28.dp)) {
                            Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopiuj", modifier = Modifier.size(16.dp))
                        }
                        if (isUser) {
                            IconButton(onClick = onEdit, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Outlined.Edit, contentDescription = "Edytuj", modifier = Modifier.size(16.dp))
                            }
                        } else {
                            IconButton(onClick = onSpeak, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Outlined.VolumeUp, contentDescription = "Czytaj na głos", modifier = Modifier.size(16.dp))
                            }
                            if (isLastModel) {
                                IconButton(onClick = onRegenerate, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Outlined.Refresh, contentDescription = "Ponów", modifier = Modifier.size(16.dp))
                                }
                                TextButton(onClick = onContinue, modifier = Modifier.height(28.dp)) {
                                    Text("Kontynuuj", style = MaterialTheme.typography.labelMedium)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
