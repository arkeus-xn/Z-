package pl.ultraai.android.ui.characters

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import pl.ultraai.android.data.local.entity.AiCharacterEntity
import pl.ultraai.android.domain.model.AiModelInfo
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharactersScreen(
    viewModel: CharactersViewModel,
    onStartChatWithCharacter: (Long) -> Unit,
    onOpenExistingSession: (Long) -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    var editingCharacter by remember { mutableStateOf<AiCharacterEntity?>(null) }

    editingCharacter?.let { char ->
        CharacterEditorDialog(
            initial = char,
            models = state.availableModels,
            onDismiss = { editingCharacter = null },
            onSave = {
                viewModel.saveCharacter(it)
                editingCharacter = null
            }
        )
    }

    state.selectedCharacterForHistory?.let { histChar ->
        AlertDialog(
            onDismissRequest = { viewModel.inspectHistory(null) },
            title = { Text("Historia i pamięć: ${histChar.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Pamięć postaci:",
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = histChar.memorySummary.ifBlank { "Brak zapisanej pamięci długoterminowej." },
                        style = MaterialTheme.typography.bodyMedium
                    )
                    OutlinedButton(
                        onClick = { viewModel.updateMemoryFromHistory(histChar) },
                        enabled = !state.isSummarizingMemory
                    ) {
                        Icon(Icons.Outlined.Psychology, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (state.isSummarizingMemory) "Aktualizuję..." else "Zaktualizuj pamięć z rozmów")
                    }
                    HorizontalDivider()
                    Text("Rozmowy z postacią (${state.characterSessions.size}):", fontWeight = FontWeight.Bold)
                    if (state.characterSessions.isEmpty()) {
                        Text("Brak zapisanych rozmów.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        state.characterSessions.take(6).forEach { s ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.inspectHistory(null)
                                        onOpenExistingSession(s.id)
                                    }
                            ) {
                                Text(s.title, modifier = Modifier.padding(10.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { viewModel.inspectHistory(null) }) { Text("Zamknij") }
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Postacie AI • Kreator") })
        },
        floatingActionButton = {
            FloatingActionButton(onClick = {
                editingCharacter = AiCharacterEntity(
                    name = "",
                    avatarEmoji = "AI",
                    avatarColorHex = 0xFF3B82F6,
                    personality = "",
                    traits = "",
                    speakingStyle = "",
                    systemPrompt = ""
                )
            }) {
                Icon(Icons.Outlined.Add, contentDescription = "Nowa postać")
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }
            items(state.characters, key = { it.id }) { character ->
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(Color(character.avatarColorHex).copy(alpha = 0.25f))
                            ) {
                                Text(character.avatarEmoji, fontSize = 24.sp)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(character.name, fontWeight = FontWeight.Bold)
                                Text(
                                    text = character.personality,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = "Temp: ${String.format(Locale.US, "%.2f", character.temperature)} • Pamięć: ${if (character.memoryEnabled) "Włączona" else "Wyłączona"}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(onClick = { onStartChatWithCharacter(character.id) }) {
                                Icon(Icons.Outlined.Chat, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Rozmawiaj")
                            }
                            Row {
                                IconButton(onClick = { viewModel.inspectHistory(character) }) {
                                    Icon(Icons.Outlined.History, contentDescription = "Historia i pamięć")
                                }
                                IconButton(onClick = { editingCharacter = character }) {
                                    Icon(Icons.Outlined.Edit, contentDescription = "Edytuj")
                                }
                                IconButton(onClick = { viewModel.duplicateCharacter(character) }) {
                                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopiuj")
                                }
                                IconButton(onClick = { viewModel.deleteCharacter(character) }) {
                                    Icon(Icons.Outlined.Delete, contentDescription = "Usuń")
                                }
                            }
                        }
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(72.dp)) }
        }
    }
}

@Composable
private fun CharacterEditorDialog(
    initial: AiCharacterEntity,
    models: List<AiModelInfo>,
    onDismiss: () -> Unit,
    onSave: (AiCharacterEntity) -> Unit
) {
    var name by remember { mutableStateOf(initial.name) }
    var emoji by remember { mutableStateOf(initial.avatarEmoji) }
    var colorHex by remember { mutableLongStateOf(initial.avatarColorHex) }
    var personality by remember { mutableStateOf(initial.personality) }
    var traits by remember { mutableStateOf(initial.traits) }
    var speakingStyle by remember { mutableStateOf(initial.speakingStyle) }
    var systemPrompt by remember { mutableStateOf(initial.systemPrompt) }
    var preferredModel by remember { mutableStateOf(initial.preferredModelId) }
    var temperature by remember { mutableFloatStateOf(initial.temperature) }
    var memoryEnabled by remember { mutableStateOf(initial.memoryEnabled) }
    var memorySummary by remember { mutableStateOf(initial.memorySummary) }
    var modelDropdown by remember { mutableStateOf(false) }

    val emojiChoices = listOf("AI", "KA", "PM", "AS", "OW", "SH", "AR", "BR")
    val colorChoices = listOf(0xFF3B82F6L, 0xFF10B981L, 0xFF8B5CF6L, 0xFFF59E0BL, 0xFFEF4444L)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial.id == 0L) "Nowa postać AI" else "Edytuj postać AI") },
        text = {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    emojiChoices.forEach { e ->
                        Text(
                            text = e,
                            fontSize = 22.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (e == emoji) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                                .clickable { emoji = e }
                                .padding(6.dp)
                        )
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    colorChoices.forEach { c ->
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(Color(c))
                                .clickable { colorHex = c }
                        )
                    }
                }
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Nazwa postaci") }, singleLine = true)
                OutlinedTextField(value = personality, onValueChange = { personality = it }, label = { Text("Osobowość") })
                OutlinedTextField(value = traits, onValueChange = { traits = it }, label = { Text("Charakter i cechy") })
                OutlinedTextField(value = speakingStyle, onValueChange = { speakingStyle = it }, label = { Text("Styl wypowiedzi") })
                OutlinedTextField(value = systemPrompt, onValueChange = { systemPrompt = it }, label = { Text("Prompt systemowy") }, minLines = 3)

                Box {
                    OutlinedButton(onClick = { modelDropdown = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Preferowany model: ${preferredModel.ifBlank { "Domyślny" }}")
                    }
                    DropdownMenu(expanded = modelDropdown, onDismissRequest = { modelDropdown = false }) {
                        DropdownMenuItem(
                            text = { Text("Domyślny z ustawień") },
                            onClick = { preferredModel = ""; modelDropdown = false }
                        )
                        models.forEach { m ->
                            DropdownMenuItem(
                                text = { Text("${m.displayName} (${m.provider.name})") },
                                onClick = { preferredModel = m.id; modelDropdown = false }
                            )
                        }
                    }
                }

                Text("Temperatura: ${String.format(Locale.US, "%.2f", temperature)}")
                Slider(value = temperature, onValueChange = { temperature = it }, valueRange = 0f..1.5f)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Pamięć długoterminowa")
                    Switch(checked = memoryEnabled, onCheckedChange = { memoryEnabled = it })
                }
                if (memoryEnabled) {
                    OutlinedTextField(
                        value = memorySummary,
                        onValueChange = { memorySummary = it },
                        label = { Text("Opcjonalna pamięć początkowa") },
                        minLines = 2
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onSave(
                            initial.copy(
                                name = name.trim(),
                                avatarEmoji = emoji,
                                avatarColorHex = colorHex,
                                personality = personality.trim(),
                                traits = traits.trim(),
                                speakingStyle = speakingStyle.trim(),
                                systemPrompt = systemPrompt.trim(),
                                preferredModelId = preferredModel,
                                temperature = temperature,
                                memoryEnabled = memoryEnabled,
                                memorySummary = memorySummary.trim()
                            )
                        )
                    }
                }
            ) { Text("Zapisz") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Anuluj") }
        }
    )
}
