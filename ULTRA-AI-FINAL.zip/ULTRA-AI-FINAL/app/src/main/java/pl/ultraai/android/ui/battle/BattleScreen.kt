package pl.ultraai.android.ui.battle

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Balance
import androidx.compose.material.icons.outlined.EmojiEvents
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.ThumbUp
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import pl.ultraai.android.core.pricing.CostEstimator
import pl.ultraai.android.ui.components.CostConfirmationDialog
import pl.ultraai.android.ui.components.EmptyApiBanner
import pl.ultraai.android.ui.components.MarkdownText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BattleScreen(
    viewModel: BattleViewModel,
    onNavigateToSettingsApi: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    state.pendingCostEstimate?.let { est ->
        CostConfirmationDialog(
            estimate = est,
            modelName = "${state.selectedContestantIds.size} modeli w AI Battle",
            onConfirm = viewModel::confirmAndExecuteBattle,
            onCancel = viewModel::dismissCostDialog
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Battle • Arena Modeli") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.availableModels.isEmpty()) {
                EmptyApiBanner(onGoToSettings = onNavigateToSettingsApi)
            }

            Text(
                text = "Wybierz od 2 do 5 modeli do jednoczesnego pojedynku (${state.selectedContestantIds.size}/5):",
                style = MaterialTheme.typography.titleMedium
            )

            Row(
                modifier = Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                state.availableModels.forEach { model ->
                    FilterChip(
                        selected = model.id in state.selectedContestantIds,
                        onClick = { viewModel.toggleContestant(model.id) },
                        label = { Text("${model.displayName} (${model.provider.name})") }
                    )
                }
            }

            OutlinedTextField(
                value = state.prompt,
                onValueChange = viewModel::updatePrompt,
                label = { Text("Jedno pytanie dla wszystkich modeli") },
                minLines = 3,
                maxLines = 6,
                modifier = Modifier.fillMaxWidth()
            )

            state.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            Button(
                onClick = viewModel::requestBattleStart,
                enabled = !state.isRunning,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Outlined.PlayArrow, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (state.isRunning) "Modele odpowiadają..." else "Uruchom AI Battle")
            }

            if (state.isRunning) {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            }

            if (state.results.isNotEmpty()) {
                // Tabela porównawcza metryk
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Porównanie parametrów", fontWeight = FontWeight.Bold)
                        HorizontalDivider()
                        state.results.forEach { res ->
                            val isWinner = res.model.id == state.winnerModelId
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = (if (isWinner) "[WIN] " else "") + res.model.displayName,
                                    fontWeight = if (isWinner) FontWeight.Bold else FontWeight.Medium,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "${res.latencyMs} ms • ${res.inputTokens + res.outputTokens} tok. • ${CostEstimator.formatUsd(res.estimatedCostUsd)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }

                // Odpowiedzi obok siebie (przewijane poziomo)
                Text("Odpowiedzi obok siebie:", style = MaterialTheme.typography.titleMedium)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    state.results.forEach { res ->
                        val isWinner = res.model.id == state.winnerModelId
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = if (isWinner) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface,
                            tonalElevation = 2.dp,
                            modifier = Modifier.width(320.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(res.model.displayName, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = "${res.latencyMs} ms • ${res.outputTokens} tok. wyj. • ${CostEstimator.formatUsd(res.estimatedCostUsd)}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    OutlinedButton(onClick = { viewModel.voteForModel(res.model.id) }) {
                                        Icon(Icons.Outlined.ThumbUp, contentDescription = "Głosuj")
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (isWinner) "Wybrany" else "Głosuj")
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                HorizontalDivider()
                                Spacer(modifier = Modifier.height(8.dp))
                                MarkdownText(markdown = res.responseText)
                            }
                        }
                    }
                }

                // Sekcja Sędzia AI
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(Icons.Outlined.Balance, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Text("Sędzia AI", style = MaterialTheme.typography.titleMedium)
                        }
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            state.availableModels.forEach { m ->
                                FilterChip(
                                    selected = m.id == state.judgeModelId,
                                    onClick = { viewModel.selectJudge(m.id) },
                                    label = { Text(m.displayName) }
                                )
                            }
                        }
                        Button(
                            onClick = viewModel::runAiJudge,
                            enabled = !state.isJudging
                        ) {
                            Icon(Icons.Outlined.EmojiEvents, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (state.isJudging) "Sędzia analizuje..." else "Poproś Sędziego AI o werdykt")
                        }
                        if (state.judgeVerdict.isNotBlank()) {
                            HorizontalDivider()
                            MarkdownText(markdown = state.judgeVerdict)
                        }
                    }
                }
            }
        }
    }
}
