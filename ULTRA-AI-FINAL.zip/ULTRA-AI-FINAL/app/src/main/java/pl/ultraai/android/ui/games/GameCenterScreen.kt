package pl.ultraai.android.ui.games

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Casino
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameCenterScreen(viewModel: GameCenterViewModel) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    if (state.activeGame != null) {
                        IconButton(onClick = { viewModel.openGame(null) }) {
                            Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Powrót")
                        }
                    }
                },
                title = {
                    Text(state.activeGame?.titlePl ?: "Game Center • 8 Gier AI")
                }
            )
        }
    ) { padding ->
        if (state.activeGame == null) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Spacer(modifier = Modifier.height(4.dp)) }
                items(UltraGameType.entries) { game ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.openGame(game) }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Casino, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(game.titlePl, fontWeight = FontWeight.Bold)
                                Text(
                                    text = game.subtitlePl,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (state.isAiThinking) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                when (state.activeGame) {
                    UltraGameType.CHESS -> ChessView(state, viewModel)
                    UltraGameType.TIC_TAC_TOE -> TicTacToeView(state, viewModel)
                    UltraGameType.CONNECT_FOUR -> ConnectFourView(state, viewModel)
                    UltraGameType.GAME_2048 -> Game2048View(state, viewModel)
                    UltraGameType.RPS -> RpsView(state, viewModel)
                    UltraGameType.QUIZ -> QuizView(state, viewModel)
                    UltraGameType.WORD_GAME -> WordGameView(state, viewModel)
                    UltraGameType.TEXT_ADVENTURE -> TextAdventureView(state, viewModel)
                    null -> Unit
                }
            }
        }
    }
}

@Composable
private fun ChessView(state: GameCenterUiState, vm: GameCenterViewModel) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(state.chessState.statusText, fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = vm::resetChess) { Text("Nowa partia") }
    }
    Column(modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.outline)) {
        for (r in 0..7) {
            Row(modifier = Modifier.fillMaxWidth()) {
                for (c in 0..7) {
                    val isDark = (r + c) % 2 == 1
                    val isSelected = state.selectedChessSquare == (r to c)
                    val piece = state.chessState.board[r][c]
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .background(
                                when {
                                    isSelected -> MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)
                                    isDark -> Color(0xFF334155)
                                    else -> Color(0xFF94A3B8)
                                }
                            )
                            .clickable { vm.onChessSquareTap(r, c) }
                    ) {
                        Text(
                            text = piece?.symbol.orEmpty(),
                            fontSize = 24.sp,
                            color = if (piece?.color == ChessColor.WHITE) Color.White else Color(0xFF0F172A)
                        )
                    }
                }
            }
        }
    }
    if (state.chessState.moveHistory.isNotEmpty()) {
        Text("Ruchy: ${state.chessState.moveHistory.joinToString(" ")}", style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun TicTacToeView(state: GameCenterUiState, vm: GameCenterViewModel) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(state.tttStatus, fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = vm::resetTicTacToe) { Text("Reset") }
    }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        for (r in 0..2) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                for (c in 0..2) {
                    val idx = r * 3 + c
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clickable { vm.playTicTacToe(idx) }
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(state.tttBoard[idx], fontSize = 36.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ConnectFourView(state: GameCenterUiState, vm: GameCenterViewModel) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(state.c4Status, fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = vm::resetConnectFour) { Text("Reset") }
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for (c in 0 until ConnectFourEngine.COLS) {
            Button(onClick = { vm.dropConnectFour(c) }, modifier = Modifier.weight(1f)) {
                Text("${c + 1}")
            }
        }
    }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFF1E3A8A))
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        for (r in 0 until ConnectFourEngine.ROWS) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                for (c in 0 until ConnectFourEngine.COLS) {
                    val v = state.c4Board[r][c]
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .aspectRatio(1f)
                            .clip(CircleShape)
                            .background(
                                when (v) {
                                    1 -> Color(0xFFEF4444)
                                    2 -> Color(0xFFFACC15)
                                    else -> Color(0xFF0F172A)
                                }
                            )
                            .clickable { vm.dropConnectFour(c) }
                    )
                }
            }
        }
    }
}

@Composable
private fun Game2048View(state: GameCenterUiState, vm: GameCenterViewModel) {
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Wynik: ${state.state2048.score}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::askAiHint2048) { Text("Podpowiedź AI") }
            OutlinedButton(onClick = vm::reset2048) { Text("Reset") }
        }
    }
    if (state.hint2048.isNotBlank()) {
        Text(state.hint2048, color = MaterialTheme.colorScheme.primary)
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        state.state2048.grid.forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                row.forEach { v ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (v == 0) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f) else MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.weight(1f).aspectRatio(1f)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(if (v == 0) "" else v.toString(), fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        }
                    }
                }
            }
        }
    }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
        Button(onClick = { vm.move2048(Direction2048.LEFT) }) { Text("◀ Lewo") }
        Button(onClick = { vm.move2048(Direction2048.UP) }) { Text("▲ Góra") }
        Button(onClick = { vm.move2048(Direction2048.DOWN) }) { Text("▼ Dół") }
        Button(onClick = { vm.move2048(Direction2048.RIGHT) }) { Text("Prawo >") }
    }
}

@Composable
private fun RpsView(state: GameCenterUiState, vm: GameCenterViewModel) {
    Text("Wynik: Ty ${state.rpsPlayerScore} : ${state.rpsAiScore} AI", fontWeight = FontWeight.Bold, fontSize = 18.sp)
    Text(state.rpsRoundResult)
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        RpsChoice.entries.forEach { ch ->
            Button(onClick = { vm.playRps(ch) }, modifier = Modifier.weight(1f)) {
                Text("${ch.emoji} ${ch.labelPl}")
            }
        }
    }
}

@Composable
private fun QuizView(state: GameCenterUiState, vm: GameCenterViewModel) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = state.quizTopic,
            onValueChange = vm::updateQuizTopic,
            label = { Text("Temat quizu AI") },
            modifier = Modifier.weight(1f)
        )
        Button(onClick = vm::generateAiQuiz) { Text("Generuj") }
    }
    val q = state.quizQuestions.getOrNull(state.quizIndex)
    if (q != null) {
        Text("Pytanie ${state.quizIndex + 1}/${state.quizQuestions.size} • Wynik: ${state.quizScore}", fontWeight = FontWeight.SemiBold)
        Text(q.question, style = MaterialTheme.typography.titleMedium)
        q.options.forEachIndexed { idx, opt ->
            val selected = state.quizSelectedOption == idx
            val isCorrect = idx == q.correctIndex
            val bg = when {
                state.quizSelectedOption == null -> MaterialTheme.colorScheme.surface
                isCorrect -> Color(0xFF10B981).copy(alpha = 0.25f)
                selected -> Color(0xFFEF4444).copy(alpha = 0.25f)
                else -> MaterialTheme.colorScheme.surface
            }
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = bg,
                tonalElevation = 1.dp,
                modifier = Modifier.fillMaxWidth().clickable { vm.answerQuiz(idx) }
            ) {
                Text(opt, modifier = Modifier.padding(14.dp))
            }
        }
        if (state.quizSelectedOption != null) {
            Text(q.explanation, color = MaterialTheme.colorScheme.primary)
            Button(onClick = vm::nextQuizQuestion) {
                Text(if (state.quizIndex + 1 < state.quizQuestions.size) "Następne pytanie" else "Zacznij od nowa")
            }
        }
    }
}

@Composable
private fun WordGameView(state: GameCenterUiState, vm: GameCenterViewModel) {
    var guessInput by remember { mutableStateOf("") }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(state.wordStatus, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        IconButton(onClick = vm::resetWordGame) { Icon(Icons.Outlined.Refresh, contentDescription = "Nowe słowo") }
    }
    state.wordGuesses.forEach { row ->
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
            row.word.forEachIndexed { idx, ch ->
                val color = when (row.matches[idx]) {
                    LetterMatch.CORRECT -> Color(0xFF16A34A)
                    LetterMatch.PRESENT -> Color(0xFFD97706)
                    LetterMatch.ABSENT -> Color(0xFF334155)
                }
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(color)
                ) {
                    Text(ch.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                }
            }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = guessInput,
            onValueChange = { if (it.length <= 5) guessInput = it.uppercase() },
            label = { Text("5 liter") },
            modifier = Modifier.weight(1f),
            singleLine = true
        )
        Button(onClick = { vm.submitWordGuess(guessInput); guessInput = "" }) { Text("Sprawdź") }
    }
    OutlinedButton(onClick = vm::askWordAiHint) { Text("Podpowiedź AI") }
    if (state.wordHint.isNotBlank()) {
        Text(state.wordHint, color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
private fun TextAdventureView(state: GameCenterUiState, vm: GameCenterViewModel) {
    var actionText by remember { mutableStateOf("") }
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text("HP: ${state.rpgHp} • ${state.rpgLocation}", fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = vm::resetAdventure) { Text("Reset RPG") }
    }
    Text("Ekwipunek: ${state.rpgInventory.joinToString(", ")}", style = MaterialTheme.typography.labelMedium)
    state.rpgLog.forEach { entry ->
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(entry, modifier = Modifier.padding(12.dp))
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = actionText,
            onValueChange = { actionText = it },
            label = { Text("Twoja akcja...") },
            modifier = Modifier.weight(1f)
        )
        Button(onClick = { vm.sendAdventureAction(actionText); actionText = "" }) { Text("Wykonaj") }
    }
}
