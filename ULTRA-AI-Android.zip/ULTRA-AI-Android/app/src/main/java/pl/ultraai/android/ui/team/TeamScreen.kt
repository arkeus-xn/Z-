package pl.ultraai.android.ui.team

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import pl.ultraai.android.core.pricing.CostEstimator
import pl.ultraai.android.ui.components.EmptyApiBanner
import pl.ultraai.android.ui.components.MarkdownText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeamScreen(
    viewModel: TeamViewModel,
    onNavigateToSettingsApi: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI Team • Współpraca Agentów") }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.availableModels.isEmpty()) {
                EmptyApiBanner(onGoToSettings = onNavigateToSettingsApi)
            }

            OutlinedTextField(
                value = state.taskBrief,
                onValueChange = viewModel::updateTaskBrief,
                label = { Text("Zadanie dla zespołu modeli (np. zaprojektuj i napisz moduł...) ") },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Text("Konfiguracja ról i modeli:", style = MaterialTheme.typography.titleMedium)

            state.members.forEach { member ->
                var expanded by remember(member.role) { mutableStateOf(false) }
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(member.role.titlePl, fontWeight = FontWeight.Bold)
                            Text(
                                text = member.role.instructionPl,
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Box {
                                OutlinedButton(onClick = { expanded = true }) {
                                    Text(member.modelId.ifBlank { "Wybierz model" })
                                }
                                DropdownMenu(
                                    expanded = expanded,
                                    onDismissRequest = { expanded = false }
                                ) {
                                    state.availableModels.forEach { m ->
                                        DropdownMenuItem(
                                            text = { Text("${m.displayName} (${m.provider.name})") },
                                            onClick = {
                                                viewModel.assignModel(member.role, m.id)
                                                expanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }
                        Switch(
                            checked = member.enabled,
                            onCheckedChange = { viewModel.toggleRole(member.role) }
                        )
                    }
                }
            }

            state.error?.let {
                Text(it, color = MaterialTheme.colorScheme.error)
            }

            if (state.isRunning) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = viewModel::stopPipeline, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Outlined.Stop, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Zatrzymaj")
                    }
                }
                Text(
                    text = "Aktywna rola: ${state.activeRole?.titlePl ?: "..."}",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            } else {
                Button(
                    onClick = viewModel::runTeamPipeline,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Outlined.Groups, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Uruchom zespół AI")
                }
            }

            if (state.outputs.isNotEmpty()) {
                Text("Wyniki współpracy zespołu:", style = MaterialTheme.typography.titleMedium)
                state.outputs.forEachIndexed { idx, step ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "${idx + 1}. ${step.role.titlePl} • ${step.modelName}",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Text(
                                    text = "${step.latencyMs} ms • ${step.tokens} tok. • ${CostEstimator.formatUsd(step.costUsd)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            HorizontalDivider()
                            Spacer(modifier = Modifier.height(8.dp))
                            MarkdownText(markdown = step.output)
                        }
                    }
                }
            }
        }
    }
}
