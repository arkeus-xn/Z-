package pl.ultraai.android.ui.settings

import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pl.ultraai.android.AppContainer
import pl.ultraai.android.core.security.PinSecurityHelper
import pl.ultraai.android.data.local.entity.ApiKeyEntity
import pl.ultraai.android.data.local.entity.DiagnosticLogEntity
import pl.ultraai.android.domain.model.AiModelInfo
import pl.ultraai.android.domain.model.AiProvider
import pl.ultraai.android.domain.model.AppSettings
import pl.ultraai.android.domain.model.MessageStyle
import pl.ultraai.android.domain.model.ProviderRateStatus
import pl.ultraai.android.domain.model.SelectionMode
import pl.ultraai.android.domain.model.ThemePreset

data class SettingsUiState(
    val settings: AppSettings = AppSettings(),
    val apiKeys: List<ApiKeyEntity> = emptyList(),
    val models: List<AiModelInfo> = emptyList(),
    val providerStatus: Map<AiProvider, ProviderRateStatus> = emptyMap(),
    val diagnostics: List<DiagnosticLogEntity> = emptyList(),
    val isTestingKey: Boolean = false,
    val bannerMessage: String? = null
)

class SettingsViewModel(private val container: AppContainer) : ViewModel() {

    private val isTestingKey = MutableStateFlow(false)
    private val bannerMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<SettingsUiState> = combine(
        listOf<Flow<Any?>>(
            container.settingsStore.settingsFlow,
            container.apiKeyAndModelRepo.observeKeys(),
            container.apiKeyAndModelRepo.discoveredModels,
            container.apiKeyAndModelRepo.providerStatus,
            container.usageRepo.observeDiagnostics(),
            isTestingKey,
            bannerMessage
        )
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        SettingsUiState(
            settings = arr[0] as AppSettings,
            apiKeys = arr[1] as List<ApiKeyEntity>,
            models = arr[2] as List<AiModelInfo>,
            providerStatus = arr[3] as Map<AiProvider, ProviderRateStatus>,
            diagnostics = arr[4] as List<DiagnosticLogEntity>,
            isTestingKey = arr[5] as Boolean,
            bannerMessage = arr[6] as String?
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SettingsUiState())

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { container.settingsStore.updateSettings(transform) }
    }

    fun setDarkTheme(enabled: Boolean) = updateSettings { it.copy(darkTheme = enabled) }
    fun setThemePreset(preset: ThemePreset) = updateSettings { it.copy(themePreset = preset) }
    fun setAccentColor(hex: Long) = updateSettings { it.copy(accentColorHex = hex) }
    fun setFontScale(scale: Float) = updateSettings { it.copy(fontScale = scale) }
    fun setAnimations(enabled: Boolean) = updateSettings { it.copy(animationsEnabled = enabled) }
    fun setMessageStyle(style: MessageStyle) = updateSettings { it.copy(messageStyle = style) }

    fun setDefaultProvider(provider: AiProvider) = updateSettings { it.copy(defaultProvider = provider) }
    fun setDefaultModel(modelId: String) = updateSettings { it.copy(defaultModelId = modelId) }
    fun setTemperature(temp: Float) = updateSettings { it.copy(defaultTemperature = temp) }
    fun setMaxOutputTokens(tokens: Int) = updateSettings { it.copy(maxOutputTokens = tokens) }
    fun setSystemPrompt(prompt: String) = updateSettings { it.copy(defaultSystemPrompt = prompt) }
    fun setSelectionMode(mode: SelectionMode) = updateSettings { it.copy(selectionMode = mode) }

    fun saveApiKey(id: Long?, provider: AiProvider, label: String, rawKey: String) {
        if (rawKey.isBlank()) {
            bannerMessage.value = "Klucz API nie może być pusty."
            return
        }
        viewModelScope.launch {
            container.apiKeyAndModelRepo.addOrUpdateKey(id = id, provider = provider, label = label, rawKey = rawKey, setActive = true)
            bannerMessage.value = "Zaszyfrowano i zapisano klucz w Android Keystore."
            container.apiKeyAndModelRepo.refreshProviderModels(provider)
        }
    }

    fun activateKey(entity: ApiKeyEntity) {
        viewModelScope.launch { container.apiKeyAndModelRepo.activateKey(entity) }
    }

    fun deleteKey(entity: ApiKeyEntity) {
        viewModelScope.launch {
            container.apiKeyAndModelRepo.deleteKey(entity)
            bannerMessage.value = "Usunięto klucz ${entity.label}."
        }
    }

    fun testKey(entity: ApiKeyEntity) {
        viewModelScope.launch {
            isTestingKey.value = true
            val res = container.apiKeyAndModelRepo.testKeyAndRefresh(entity)
            bannerMessage.value = res.message
            isTestingKey.value = false
        }
    }

    fun setPin(newPin: String) {
        if (newPin.length < 4) {
            bannerMessage.value = "PIN musi mieć co najmniej 4 cyfry."
            return
        }
        val hash = PinSecurityHelper.hashPin(newPin)
        updateSettings { it.copy(pinEnabled = true, pinHash = hash) }
        bannerMessage.value = "Ustawiono blokadę PIN."
    }

    fun disablePin() {
        updateSettings { it.copy(pinEnabled = false, pinHash = "", biometricEnabled = false) }
        bannerMessage.value = "Wyłączono blokadę PIN."
    }

    fun setBiometricEnabled(enabled: Boolean) {
        updateSettings { it.copy(biometricEnabled = enabled) }
    }

    fun setCostLimits(dailyCost: Double, monthlyCost: Double, dailyReqs: Int) {
        updateSettings {
            it.copy(
                dailyCostLimitUsd = dailyCost,
                monthlyCostLimitUsd = monthlyCost,
                dailyRequestLimit = dailyReqs
            )
        }
        bannerMessage.value = "Zaktualizowano limity kosztów i użycia."
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            container.chatRepo.clearAllHistory()
            bannerMessage.value = "Wyczyszczono całą historię rozmów."
        }
    }

    fun clearCharacterMemories() {
        viewModelScope.launch {
            container.characterAndPromptRepo.clearAllMemories()
            bannerMessage.value = "Wyczyszczono pamięć długoterminową wszystkich postaci."
        }
    }

    fun clearCache() {
        viewModelScope.launch {
            container.usageRepo.clearCache()
            bannerMessage.value = "Wyczyszczono lokalną pamięć podręczną odpowiedzi."
        }
    }

    fun clearDiagnostics() {
        viewModelScope.launch {
            container.usageRepo.clearDiagnostics()
            bannerMessage.value = "Wyczyszczono logi diagnostyczne."
        }
    }

    fun exportData(uri: Uri) {
        viewModelScope.launch {
            container.backupManager.exportToUri(uri)
                .onSuccess { bannerMessage.value = it }
                .onFailure { bannerMessage.value = "Błąd eksportu: ${it.localizedMessage}" }
        }
    }

    fun resetAllSettings() {
        viewModelScope.launch {
            container.settingsStore.resetDefaults()
            bannerMessage.value = "Przywrócono domyślne ustawienia aplikacji."
        }
    }

    fun dismissBanner() {
        bannerMessage.value = null
    }
}
