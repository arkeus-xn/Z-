package pl.ultraai.android.ui.games

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pl.ultraai.android.AppContainer
import pl.ultraai.android.data.remote.AiTurnMessage
import pl.ultraai.android.domain.model.AiModelInfo

enum class UltraGameType(val titlePl: String, val subtitlePl: String) {
    CHESS("Szachy", "Pełna logika szachowa + legalne ruchy AI"),
    TIC_TAC_TOE("Kółko i krzyżyk", "Klasyczna gra 3x3 z algorytmem AI"),
    CONNECT_FOUR("Connect Four", "Cztery w rzędzie 7x6 z grawitacją"),
    GAME_2048("2048", "Łączenie potęg dwójki + podpowiedzi AI"),
    RPS("Papier, kamień, nożyce", "Pojedynek z predykcją wzorców AI"),
    QUIZ("Quizy AI", "Pytania wielokrotnego wyboru na dowolny temat"),
    WORD_GAME("Gra słowna (5 liter)", "Polskie słowo dnia + podpowiedzi AI"),
    TEXT_ADVENTURE("Przygoda tekstowa", "Interaktywna gra RPG prowadzona przez AI")
}

data class GameCenterUiState(
    val activeGame: UltraGameType? = null,
    val availableModels: List<AiModelInfo> = emptyList(),
    val isAiThinking: Boolean = false,
    // Szachy
    val chessState: ChessGameState = ChessEngine.initialState(),
    val selectedChessSquare: Pair<Int, Int>? = null,
    // Kółko i krzyżyk
    val tttBoard: List<String> = List(9) { "" },
    val tttStatus: String = "Twój ruch (X)",
    // Connect Four
    val c4Board: List<List<Int>> = ConnectFourEngine.emptyBoard(),
    val c4Status: String = "Twój ruch (Czerwone)",
    // 2048
    val state2048: Game2048State = Game2048Engine.initialState(),
    val hint2048: String = "",
    // RPS
    val rpsPlayerScore: Int = 0,
    val rpsAiScore: Int = 0,
    val rpsRoundResult: String = "Wybierz kamień, papier lub nożyce",
    val rpsHistory: List<RpsChoice> = emptyList(),
    // Quiz
    val quizTopic: String = "Technologia i Nauka",
    val quizQuestions: List<QuizQuestion> = QuizParser.fallbackQuestions,
    val quizIndex: Int = 0,
    val quizScore: Int = 0,
    val quizSelectedOption: Int? = null,
    // Gra słowna
    val wordSecret: String = PolishWordGameEngine.pickSecretWord(),
    val wordGuesses: List<WordGuessRow> = emptyList(),
    val wordStatus: String = "Zgadnij 5-literowe polskie słowo (6 prób)",
    val wordHint: String = "",
    // Przygoda tekstowa
    val rpgHp: Int = 100,
    val rpgInventory: List<String> = listOf("Latarka", "Kompas"),
    val rpgLocation: String = "Stacja Badawcza Polaris",
    val rpgLog: List<String> = listOf("Budzisz się w opuszczonej stacji Polaris na orbicie. Na terminalu miga nieznany sygnał. Co robisz?")
)

class GameCenterViewModel(private val container: AppContainer) : ViewModel() {

    private val activeGame = MutableStateFlow<UltraGameType?>(null)
    private val isAiThinking = MutableStateFlow(false)

    private val chessState = MutableStateFlow(ChessEngine.initialState())
    private val selectedChessSquare = MutableStateFlow<Pair<Int, Int>?>(null)

    private val tttBoard = MutableStateFlow(List(9) { "" })
    private val tttStatus = MutableStateFlow("Twój ruch (X)")

    private val c4Board = MutableStateFlow(ConnectFourEngine.emptyBoard())
    private val c4Status = MutableStateFlow("Twój ruch (Czerwone)")

    private val state2048 = MutableStateFlow(Game2048Engine.initialState())
    private val hint2048 = MutableStateFlow("")

    private val rpsPlayerScore = MutableStateFlow(0)
    private val rpsAiScore = MutableStateFlow(0)
    private val rpsRoundResult = MutableStateFlow("Wybierz kamień, papier lub nożyce")
    private val rpsHistory = MutableStateFlow<List<RpsChoice>>(emptyList())

    private val quizTopic = MutableStateFlow("Technologia i Nauka")
    private val quizQuestions = MutableStateFlow(QuizParser.fallbackQuestions)
    private val quizIndex = MutableStateFlow(0)
    private val quizScore = MutableStateFlow(0)
    private val quizSelectedOption = MutableStateFlow<Int?>(null)

    private val wordSecret = MutableStateFlow(PolishWordGameEngine.pickSecretWord())
    private val wordGuesses = MutableStateFlow<List<WordGuessRow>>(emptyList())
    private val wordStatus = MutableStateFlow("Zgadnij 5-literowe polskie słowo (6 prób)")
    private val wordHint = MutableStateFlow("")

    private val rpgHp = MutableStateFlow(100)
    private val rpgInventory = MutableStateFlow(listOf("Latarka", "Kompas"))
    private val rpgLocation = MutableStateFlow("Stacja Badawcza Polaris")
    private val rpgLog = MutableStateFlow(
        listOf("Budzisz się w opuszczonej stacji Polaris na orbicie. Na terminalu miga nieznany sygnał. Co robisz?")
    )

    val uiState: StateFlow<GameCenterUiState> = combine(
        listOf<Flow<Any?>>(
            container.apiKeyAndModelRepo.discoveredModels,
            activeGame,
            isAiThinking,
            chessState,
            selectedChessSquare,
            tttBoard,
            tttStatus,
            c4Board,
            c4Status,
            state2048,
            hint2048,
            rpsPlayerScore,
            rpsAiScore,
            rpsRoundResult,
            rpsHistory,
            quizTopic,
            quizQuestions,
            quizIndex,
            quizScore,
            quizSelectedOption,
            wordSecret,
            wordGuesses,
            wordStatus,
            wordHint,
            rpgHp,
            rpgInventory,
            rpgLocation,
            rpgLog
        )
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        GameCenterUiState(
            availableModels = arr[0] as List<AiModelInfo>,
            activeGame = arr[1] as UltraGameType?,
            isAiThinking = arr[2] as Boolean,
            chessState = arr[3] as ChessGameState,
            selectedChessSquare = arr[4] as Pair<Int, Int>?,
            tttBoard = arr[5] as List<String>,
            tttStatus = arr[6] as String,
            c4Board = arr[7] as List<List<Int>>,
            c4Status = arr[8] as String,
            state2048 = arr[9] as Game2048State,
            hint2048 = arr[10] as String,
            rpsPlayerScore = arr[11] as Int,
            rpsAiScore = arr[12] as Int,
            rpsRoundResult = arr[13] as String,
            rpsHistory = arr[14] as List<RpsChoice>,
            quizTopic = arr[15] as String,
            quizQuestions = arr[16] as List<QuizQuestion>,
            quizIndex = arr[17] as Int,
            quizScore = arr[18] as Int,
            quizSelectedOption = arr[19] as Int?,
            wordSecret = arr[20] as String,
            wordGuesses = arr[21] as List<WordGuessRow>,
            wordStatus = arr[22] as String,
            wordHint = arr[23] as String,
            rpgHp = arr[24] as Int,
            rpgInventory = arr[25] as List<String>,
            rpgLocation = arr[26] as String,
            rpgLog = arr[27] as List<String>
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), GameCenterUiState())

    fun openGame(game: UltraGameType?) {
        activeGame.value = game
    }

    // --- SZACHY ---
    fun resetChess() {
        chessState.value = ChessEngine.initialState()
        selectedChessSquare.value = null
    }

    fun onChessSquareTap(row: Int, col: Int) {
        val current = chessState.value
        if (current.isGameOver || current.turn != ChessColor.WHITE || isAiThinking.value) return
        val selected = selectedChessSquare.value
        val tappedPiece = current.board[row][col]

        if (selected == null) {
            if (tappedPiece?.color == ChessColor.WHITE) {
                selectedChessSquare.value = row to col
            }
            return
        }

        if (selected == (row to col)) {
            selectedChessSquare.value = null
            return
        }

        val legal = ChessEngine.legalMoves(current)
        val candidate = legal.firstOrNull {
            it.fromRow == selected.first && it.fromCol == selected.second && it.toRow == row && it.toCol == col
        }
        if (candidate != null) {
            val afterWhite = ChessEngine.applyMove(current, candidate)
            chessState.value = afterWhite
            selectedChessSquare.value = null
            if (!afterWhite.isGameOver) {
                triggerAiChessMove(afterWhite)
            }
        } else if (tappedPiece?.color == ChessColor.WHITE) {
            selectedChessSquare.value = row to col
        } else {
            selectedChessSquare.value = null
        }
    }

    private fun triggerAiChessMove(state: ChessGameState) {
        val legal = ChessEngine.legalMoves(state)
        if (legal.isEmpty()) return
        viewModelScope.launch {
            isAiThinking.value = true
            val model = uiState.value.availableModels.firstOrNull()
            var chosenMove: ChessMove? = null

            if (model != null) {
                val key = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider).orEmpty()
                if (key.isNotBlank()) {
                    val uciList = legal.joinToString(", ") { it.toUci() }
                    val res = container.aiGateway.completeOnce(
                        model = model,
                        apiKey = key,
                        systemPrompt = "Grasz czarnymi w szachy. Wybierz JEDEN najlepszy ruch wyłącznie z podanej listy legalnych ruchów UCI. Zwróć tylko 4-5 znakowy kod ruchu (np. e7e5).",
                        messages = listOf(AiTurnMessage("user", "Historia ruchów: ${state.moveHistory.joinToString(" ")}\nLegalne ruchy: $uciList")),
                        temperature = 0.2f,
                        maxOutputTokens = 20
                    )
                    if (!res.isError) {
                        val token = res.text.trim().lowercase()
                        chosenMove = legal.firstOrNull { token.contains(it.toUci()) }
                    }
                }
            }

            val finalMove = chosenMove ?: ChessEngine.pickBestHeuristicMove(state)
            if (finalMove != null) {
                chessState.value = ChessEngine.applyMove(state, finalMove)
            }
            isAiThinking.value = false
        }
    }

    // --- KÓŁKO I KRZYŻYK ---
    fun resetTicTacToe() {
        tttBoard.value = List(9) { "" }
        tttStatus.value = "Twój ruch (X)"
    }

    fun playTicTacToe(index: Int) {
        val b = tttBoard.value
        if (b[index].isNotEmpty() || TicTacToeEngine.checkWinner(b) != null || TicTacToeEngine.isDraw(b)) return
        val afterPlayer = b.toMutableList().apply { this[index] = "X" }
        tttBoard.value = afterPlayer

        when {
            TicTacToeEngine.checkWinner(afterPlayer) == "X" -> { tttStatus.value = "Wygrałeś!"; return }
            TicTacToeEngine.isDraw(afterPlayer) -> { tttStatus.value = "Remis!"; return }
        }

        val aiIdx = TicTacToeEngine.bestMinimaxMove(afterPlayer) ?: return
        val afterAi = afterPlayer.toMutableList().apply { this[aiIdx] = "O" }
        tttBoard.value = afterAi
        tttStatus.value = when {
            TicTacToeEngine.checkWinner(afterAi) == "O" -> "Wygrało AI (O)!"
            TicTacToeEngine.isDraw(afterAi) -> "Remis!"
            else -> "Twój ruch (X)"
        }
    }

    // --- CONNECT FOUR ---
    fun resetConnectFour() {
        c4Board.value = ConnectFourEngine.emptyBoard()
        c4Status.value = "Twój ruch (Czerwone)"
    }

    fun dropConnectFour(col: Int) {
        val current = c4Board.value
        if (ConnectFourEngine.checkWinner(current) != null) return
        val afterPlayer = ConnectFourEngine.dropDisc(current, col, 1) ?: return
        c4Board.value = afterPlayer
        if (ConnectFourEngine.checkWinner(afterPlayer) == 1) {
            c4Status.value = "Wygrałeś! (4 w rzędzie)"
            return
        }
        val aiCol = ConnectFourEngine.pickSmartColumn(afterPlayer)
        if (aiCol == null) {
            c4Status.value = "Remis — pełna plansza!"
            return
        }
        val afterAi = ConnectFourEngine.dropDisc(afterPlayer, aiCol, 2)!!
        c4Board.value = afterAi
        c4Status.value = when {
            ConnectFourEngine.checkWinner(afterAi) == 2 -> "Wygrało AI (Żółte)!"
            ConnectFourEngine.legalColumns(afterAi).isEmpty() -> "Remis!"
            else -> "Twój ruch (Czerwone)"
        }
    }

    // --- 2048 ---
    fun reset2048() {
        state2048.value = Game2048Engine.initialState()
        hint2048.value = ""
    }

    fun move2048(dir: Direction2048) {
        state2048.value = Game2048Engine.move(state2048.value, dir)
    }

    fun askAiHint2048() {
        val model = uiState.value.availableModels.firstOrNull() ?: run {
            hint2048.value = "Podpowiedź lokalna: trzymaj najwyższy kafelek w jednym rogu i łącz sąsiednie wartości."
            return
        }
        viewModelScope.launch {
            isAiThinking.value = true
            val key = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider).orEmpty()
            val boardStr = state2048.value.grid.joinToString("\n") { row -> row.joinToString("\t") }
            val res = container.aiGateway.completeOnce(
                model = model,
                apiKey = key,
                systemPrompt = "Jesteś ekspertem gry 2048. Wskaż najlepszy kierunek (GÓRA, DÓŁ, LEWO, PRAWO) i uzasadnij w 1 zdaniu po polsku.",
                messages = listOf(AiTurnMessage("user", "Plansza:\n$boardStr")),
                temperature = 0.2f,
                maxOutputTokens = 120
            )
            hint2048.value = if (res.isError) "Brak połączenia — trzymaj największą liczbę w rogu." else res.text
            isAiThinking.value = false
        }
    }

    // --- PAPIER KAMIEŃ NOŻYCE ---
    fun playRps(choice: RpsChoice) {
        val hist = rpsHistory.value
        val predictedPlayerNext = if (hist.size >= 2) {
            hist.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
        } else null

        val aiChoice = when (predictedPlayerNext) {
            RpsChoice.ROCK -> RpsChoice.PAPER
            RpsChoice.PAPER -> RpsChoice.SCISSORS
            RpsChoice.SCISSORS -> RpsChoice.ROCK
            null -> RpsChoice.entries.random()
        }
        rpsHistory.value = (hist + choice).takeLast(12)

        when {
            choice == aiChoice -> rpsRoundResult.value = "Remis! Oboje wybraliście ${choice.labelPl} ${choice.emoji}"
            choice.beats(aiChoice) -> {
                rpsPlayerScore.value += 1
                rpsRoundResult.value = "Wygrałeś rundę! ${choice.emoji} pokonuje ${aiChoice.emoji}"
            }
            else -> {
                rpsAiScore.value += 1
                rpsRoundResult.value = "AI wygrywa rundę! ${aiChoice.emoji} pokonuje ${choice.emoji}"
            }
        }
    }

    // --- QUIZ ---
    fun updateQuizTopic(topic: String) {
        quizTopic.value = topic
    }

    fun generateAiQuiz() {
        val model = uiState.value.availableModels.firstOrNull() ?: return
        viewModelScope.launch {
            isAiThinking.value = true
            val key = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider).orEmpty()
            val prompt = "Wygeneruj 5 pytań quizowych po polsku na temat: ${quizTopic.value}. " +
                "Zwróć wyłącznie czysty JSON: [{\"question\":\"...\",\"options\":[\"A\",\"B\",\"C\",\"D\"],\"correctIndex\":0,\"explanation\":\"...\"}]"
            val res = container.aiGateway.completeOnce(
                model = model,
                apiKey = key,
                systemPrompt = "Zwracasz wyłącznie poprawną tablicę JSON bez markdownu.",
                messages = listOf(AiTurnMessage("user", prompt)),
                temperature = 0.6f,
                maxOutputTokens = 1600
            )
            val parsed = QuizParser.parseAiQuizJson(res.text)
            if (parsed.isNotEmpty()) {
                quizQuestions.value = parsed
                quizIndex.value = 0
                quizScore.value = 0
                quizSelectedOption.value = null
            }
            isAiThinking.value = false
        }
    }

    fun answerQuiz(optionIdx: Int) {
        if (quizSelectedOption.value != null) return
        quizSelectedOption.value = optionIdx
        val q = quizQuestions.value.getOrNull(quizIndex.value) ?: return
        if (optionIdx == q.correctIndex) quizScore.value += 1
    }

    fun nextQuizQuestion() {
        if (quizIndex.value + 1 < quizQuestions.value.size) {
            quizIndex.value += 1
            quizSelectedOption.value = null
        } else {
            quizIndex.value = 0
            quizScore.value = 0
            quizSelectedOption.value = null
        }
    }

    // --- GRA SŁOWNA ---
    fun resetWordGame() {
        wordSecret.value = PolishWordGameEngine.pickSecretWord()
        wordGuesses.value = emptyList()
        wordStatus.value = "Zgadnij 5-literowe polskie słowo (6 prób)"
        wordHint.value = ""
    }

    fun submitWordGuess(raw: String) {
        val clean = raw.trim().uppercase()
        if (clean.length != 5) {
            wordStatus.value = "Słowo musi mieć dokładnie 5 liter!"
            return
        }
        val current = wordGuesses.value
        if (current.size >= 6) return
        val secret = wordSecret.value
        val matches = PolishWordGameEngine.evaluateGuess(clean, secret)
        val updated = current + WordGuessRow(clean, matches)
        wordGuesses.value = updated
        wordStatus.value = when {
            clean == secret -> "Brawo! Odgadłeś słowo $secret!"
            updated.size >= 6 -> "Koniec prób! Szukane słowo to: $secret"
            else -> "Pozostało prób: ${6 - updated.size}"
        }
    }

    fun askWordAiHint() {
        val model = uiState.value.availableModels.firstOrNull() ?: return
        viewModelScope.launch {
            isAiThinking.value = true
            val key = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider).orEmpty()
            val res = container.aiGateway.completeOnce(
                model = model,
                apiKey = key,
                systemPrompt = "Podaj 1 krótką zagadkę-podpowiedź dla słowa '${wordSecret.value}' bez wypisywania samego słowa ani jego liter.",
                messages = listOf(AiTurnMessage("user", "Daj podpowiedź po polsku.")),
                temperature = 0.7f,
                maxOutputTokens = 100
            )
            if (!res.isError) wordHint.value = res.text.trim()
            isAiThinking.value = false
        }
    }

    // --- PRZYGODA TEKSTOWA ---
    fun sendAdventureAction(action: String) {
        if (action.isBlank()) return
        rpgLog.value = rpgLog.value + "> $action"
        val model = uiState.value.availableModels.firstOrNull()
        if (model == null) {
            rpgLog.value = rpgLog.value + "Skonfiguruj klucz API w Ustawieniach, aby Mistrz Gry AI kontynuował przygodę."
            return
        }
        viewModelScope.launch {
            isAiThinking.value = true
            val key = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider).orEmpty()
            val contextPrompt = "HP: ${rpgHp.value}/100 | Ekwipunek: ${rpgInventory.value.joinToString()} | Lokacja: ${rpgLocation.value}\n" +
                "Ostatnie wydarzenia:\n${rpgLog.value.takeLast(6).joinToString("\n")}"
            val res = container.aiGateway.completeOnce(
                model = model,
                apiKey = key,
                systemPrompt = "Jesteś Mistrzem Gry tekstowej RPG sci-fi/fantasy po polsku. Opisz konsekwencje akcji gracza w 3-4 zdaniach i zaproponuj 3 możliwe dalsze kroki.",
                messages = listOf(AiTurnMessage("user", contextPrompt)),
                temperature = 0.85f,
                maxOutputTokens = 450
            )
            rpgLog.value = rpgLog.value + (if (res.isError) (res.errorMessage ?: "Błąd AI") else res.text.trim())
            isAiThinking.value = false
        }
    }

    fun resetAdventure() {
        rpgHp.value = 100
        rpgInventory.value = listOf("Latarka", "Kompas")
        rpgLocation.value = "Stacja Badawcza Polaris"
        rpgLog.value = listOf("Budzisz się w opuszczonej stacji Polaris na orbicie. Na terminalu miga nieznany sygnał. Co robisz?")
    }
}
