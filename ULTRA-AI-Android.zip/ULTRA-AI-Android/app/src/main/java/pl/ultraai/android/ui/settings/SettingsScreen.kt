package pl.ultraai.android.ui.settings

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import pl.ultraai.android.BuildConfig
import pl.ultraai.android.core.pricing.ModelPricingRegistry
import pl.ultraai.android.core.security.SecurityNotices
import pl.ultraai.android.data.local.entity.ApiKeyEntity
import pl.ultraai.android.domain.model.AiProvider
import pl.ultraai.android.domain.model.MessageStyle
import pl.ultraai.android.domain.model.SelectionMode
import pl.ultraai.android.domain.model.ThemePreset
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    initialTab: Int = 0
) {
    val state by viewModel.uiState.collectAsState()
    var activeTab by remember(initialTab) { mutableIntStateOf(initialTab) }
    val tabs = listOf("Wygląd", "AI", "API", "Prywatność", "Zaawansowane")

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) viewModel.exportData(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Ustawienia ULTRA AI") })
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            TabRow(selectedTabIndex = activeTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = activeTab == index,
                        onClick = { activeTab = index },
                        text = { Text(title, maxLines = 1) }
                    )
                }
            }

            state.bannerMessage?.let { msg ->
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(msg, modifier = Modifier.weight(1f))
                        TextButton(onClick = viewModel::dismissBanner) { Text("OK") }
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                when (activeTab) {
                    0 -> AppearanceSettingsTab(state, viewModel)
                    1 -> AiDefaultsSettingsTab(state, viewModel)
                    2 -> ApiSettingsTab(state, viewModel)
                    3 -> PrivacySettingsTab(state, viewModel) {
                        exportLauncher.launch("ultra_ai_eksport_${System.currentTimeMillis()}.json")
                    }
                    4 -> AdvancedSettingsTab(state, viewModel)
                }
            }
        }
    }
}

@Composable
private fun AppearanceSettingsTab(state: SettingsUiState, vm: SettingsViewModel) {
    val s = state.settings
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Ciemny motyw (domyślny)")
        Switch(checked = s.darkTheme, onCheckedChange = vm::setDarkTheme)
    }

    Text("Motyw kolorystyczny", fontWeight = FontWeight.Bold)
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        ThemePreset.entries.forEach { preset ->
            FilterChip(
                selected = s.themePreset == preset,
                onClick = { vm.setThemePreset(preset) },
                label = { Text(preset.labelPl) }
            )
        }
    }

    Text("Kolor akcentu", fontWeight = FontWeight.Bold)
    val accents = listOf(0xFF3B82F6L, 0xFF10B981L, 0xFF8B5CF6L, 0xFFF59E0BL, 0xFFEC4899L)
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        accents.forEach { hex ->
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(hex))
                    .clickable { vm.setAccentColor(hex) }
            ) {
                if (s.accentColorHex == hex) {
                    Icon(Icons.Outlined.CheckCircle, contentDescription = null, tint = Color.White, modifier = Modifier.align(Alignment.Center))
                }
            }
        }
    }

    Text("Rozmiar tekstu: ${String.format(Locale.US, "%.2fx", s.fontScale)}")
    Slider(value = s.fontScale, onValueChange = vm::setFontScale, valueRange = 0.85f..1.30f)

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Animacje interfejsu")
        Switch(checked = s.animationsEnabled, onCheckedChange = vm::setAnimations)
    }

    Text("Wygląd wiadomości", fontWeight = FontWeight.Bold)
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        MessageStyle.entries.forEach { st ->
            FilterChip(selected = s.messageStyle == st, onClick = { vm.setMessageStyle(st) }, label = { Text(st.labelPl) })
        }
    }
}

@Composable
private fun AiDefaultsSettingsTab(state: SettingsUiState, vm: SettingsViewModel) {
    val s = state.settings
    Text("Domyślny dostawca AI", fontWeight = FontWeight.Bold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        AiProvider.entries.forEach { p ->
            FilterChip(selected = s.defaultProvider == p, onClick = { vm.setDefaultProvider(p) }, label = { Text(p.displayName) })
        }
    }

    Text("Tryb wyboru modeli", fontWeight = FontWeight.Bold)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SelectionMode.entries.forEach { mode ->
            FilterChip(
                selected = s.selectionMode == mode,
                onClick = { vm.setSelectionMode(mode) },
                label = { Text(mode.labelPl) }
            )
        }
    }

    Text("Domyślny model", fontWeight = FontWeight.Bold)
    if (state.models.isEmpty()) {
        Text("Brak pobranych modeli — skonfiguruj API w zakładce API.", color = MaterialTheme.colorScheme.onSurfaceVariant)
    } else {
        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            state.models.forEach { m ->
                FilterChip(selected = s.defaultModelId == m.id, onClick = { vm.setDefaultModel(m.id) }, label = { Text(m.displayName) })
            }
        }
    }

    Text("Temperatura: ${String.format(Locale.US, "%.2f", s.defaultTemperature)}")
    Slider(value = s.defaultTemperature, onValueChange = vm::setTemperature, valueRange = 0f..1.5f)

    Text("Maksymalna długość odpowiedzi: ${s.maxOutputTokens} tokenów")
    Slider(value = s.maxOutputTokens.toFloat(), onValueChange = { vm.setMaxOutputTokens(it.toInt()) }, valueRange = 256f..8192f)

    var sysPrompt by remember(s.defaultSystemPrompt) { mutableStateOf(s.defaultSystemPrompt) }
    OutlinedTextField(
        value = sysPrompt,
        onValueChange = { sysPrompt = it },
        label = { Text("Domyślny prompt systemowy") },
        minLines = 3,
        modifier = Modifier.fillMaxWidth()
    )
    Button(onClick = { vm.setSystemPrompt(sysPrompt) }) { Text("Zapisz prompt systemowy") }
}

@Composable
private fun ApiSettingsTab(state: SettingsUiState, vm: SettingsViewModel) {
    var editingKey by remember { mutableStateOf<ApiKeyEntity?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(Icons.Outlined.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(SecurityNotices.KEYSTORE_LIMITATIONS_PL, style = MaterialTheme.typography.bodyMedium)
        }
    }

    Button(onClick = { showAddDialog = true }, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Outlined.Add, contentDescription = null)
        Spacer(modifier = Modifier.width(6.dp))
        Text("Dodaj klucz Gemini lub Groq")
    }

    if (state.isTestingKey) LinearProgressIndicator(modifier = Modifier.fillMaxWidth())

    Text("Zapisane klucze (${state.apiKeys.size}):", fontWeight = FontWeight.Bold)
    state.apiKeys.forEach { key ->
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("${key.label} (${key.provider})", fontWeight = FontWeight.Bold)
                    if (key.isActive) {
                        Text("AKTYWNY", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    }
                }
                Text("Klucz: ${key.maskedKey}", style = MaterialTheme.typography.labelMedium)
                Text("Status: ${key.lastStatus}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Limity: ${key.rateLimitSummary}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.testKey(key) }) { Text("Testuj") }
                    if (!key.isActive) {
                        OutlinedButton(onClick = { vm.activateKey(key) }) { Text("Aktywuj") }
                    }
                    IconButton(onClick = { editingKey = key }) { Icon(Icons.Outlined.Edit, contentDescription = "Edytuj") }
                    IconButton(onClick = { vm.deleteKey(key) }) { Icon(Icons.Outlined.Delete, contentDescription = "Usuń") }
                }
            }
        }
    }

    HorizontalDivider()
    Text("Modele pobrane z API (${state.models.size}):", fontWeight = FontWeight.Bold)
    state.models.forEach { m ->
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 1.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text("${m.displayName} • ${m.provider.displayName}", fontWeight = FontWeight.SemiBold)
                Text(
                    text = "Wejście: ${ModelPricingRegistry.formatPricePer1M(m.inputPricePer1MUsd)} • Wyjście: ${ModelPricingRegistry.formatPricePer1M(m.outputPricePer1MUsd)}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "Kontekst: ${m.inputContextLimit?.toString() ?: "Brak danych"} • ${m.freeTierInfo}",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }

    if (showAddDialog || editingKey != null) {
        ApiKeyEditorDialog(
            existing = editingKey,
            onDismiss = { showAddDialog = false; editingKey = null },
            onSave = { id, provider, label, rawKey ->
                vm.saveApiKey(id, provider, label, rawKey)
                showAddDialog = false
                editingKey = null
            }
        )
    }
}

@Composable
private fun ApiKeyEditorDialog(
    existing: ApiKeyEntity?,
    onDismiss: () -> Unit,
    onSave: (Long?, AiProvider, String, String) -> Unit
) {
    var provider by remember { mutableStateOf(existing?.let { AiProvider.valueOf(it.provider) } ?: AiProvider.GEMINI) }
    var label by remember { mutableStateOf(existing?.label.orEmpty()) }
    var rawKey by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Dodaj klucz API" else "Edytuj klucz API") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    AiProvider.entries.forEach { p ->
                        FilterChip(selected = provider == p, onClick = { provider = p }, label = { Text(p.displayName) })
                    }
                }
                OutlinedTextField(value = label, onValueChange = { label = it }, label = { Text("Nazwa klucza (np. Główny)") }, singleLine = true)
                OutlinedTextField(
                    value = rawKey,
                    onValueChange = { rawKey = it },
                    label = { Text("Wklej klucz API") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(onClick = { onSave(existing?.id, provider, label, rawKey) }) { Text("Zapisz i szyfruj") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Anuluj") }
        }
    )
}

@Composable
private fun PrivacySettingsTab(state: SettingsUiState, vm: SettingsViewModel, onExportClick: () -> Unit) {
    var pinInput by remember { mutableStateOf("") }

    Text("Blokada PIN", fontWeight = FontWeight.Bold)
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = pinInput,
            onValueChange = { if (it.length <= 8 && it.all(Char::isDigit)) pinInput = it },
            label = { Text("Nowy PIN (4-8 cyfr)") },
            modifier = Modifier.weight(1f),
            singleLine = true
        )
        Button(onClick = { vm.setPin(pinInput); pinInput = "" }) { Text("Ustaw PIN") }
    }
    if (state.settings.pinEnabled) {
        OutlinedButton(onClick = vm::disablePin) { Text("Wyłącz blokadę PIN") }
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Odblokowanie biometrią (odcisk palca / twarz)")
        Switch(
            checked = state.settings.biometricEnabled,
            enabled = state.settings.pinEnabled,
            onCheckedChange = vm::setBiometricEnabled
        )
    }

    HorizontalDivider()
    Button(onClick = onExportClick, modifier = Modifier.fillMaxWidth()) { Text("Eksportuj wszystkie dane (JSON)") }
    OutlinedButton(onClick = vm::clearCharacterMemories, modifier = Modifier.fillMaxWidth()) { Text("Wyczyść pamięć postaci AI") }
    OutlinedButton(onClick = vm::clearChatHistory, modifier = Modifier.fillMaxWidth()) { Text("Wyczyść całą historię rozmów") }
}

@Composable
private fun AdvancedSettingsTab(state: SettingsUiState, vm: SettingsViewModel) {
    var dailyCost by remember(state.settings.dailyCostLimitUsd) { mutableStateOf(state.settings.dailyCostLimitUsd.toString()) }
    var monthlyCost by remember(state.settings.monthlyCostLimitUsd) { mutableStateOf(state.settings.monthlyCostLimitUsd.toString()) }
    var dailyReqs by remember(state.settings.dailyRequestLimit) { mutableStateOf(state.settings.dailyRequestLimit.toString()) }

    Text("Limity kosztów i użycia", fontWeight = FontWeight.Bold)
    OutlinedTextField(value = dailyCost, onValueChange = { dailyCost = it }, label = { Text("Dzienny limit kosztów (USD)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(value = monthlyCost, onValueChange = { monthlyCost = it }, label = { Text("Miesięczny limit kosztów (USD)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    OutlinedTextField(value = dailyReqs, onValueChange = { dailyReqs = it }, label = { Text("Dzienny limit zapytań") }, singleLine = true, modifier = Modifier.fillMaxWidth())
    Button(onClick = {
        vm.setCostLimits(
            dailyCost.toDoubleOrNull() ?: 2.0,
            monthlyCost.toDoubleOrNull() ?: 25.0,
            dailyReqs.toIntOrNull() ?: 250
        )
    }) { Text("Zapisz limity") }

    HorizontalDivider()
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedButton(onClick = vm::clearCache, modifier = Modifier.weight(1f)) { Text("Wyczyść cache") }
        OutlinedButton(onClick = vm::resetAllSettings, modifier = Modifier.weight(1f)) { Text("Reset ustawień") }
    }

    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text("Logi diagnostyczne (bez kluczy API)", fontWeight = FontWeight.Bold)
        TextButton(onClick = vm::clearDiagnostics) { Text("Wyczyść") }
    }
    state.diagnostics.take(20).forEach { log ->
        Text(
            text = "[${log.level}] ${log.tag}: ${log.message}",
            style = MaterialTheme.typography.labelMedium,
            color = if (log.level == "ERROR") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }

    HorizontalDivider()
    Text("Wersja aplikacji: ULTRA AI ${BuildConfig.VERSION_NAME} (Android 9+ / Natywny Kotlin + Jetpack Compose)", style = MaterialTheme.typography.labelMedium)
}
