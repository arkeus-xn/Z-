package pl.ultraai.android.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import pl.ultraai.android.data.local.dao.ApiKeyDao
import pl.ultraai.android.data.local.dao.CharacterDao
import pl.ultraai.android.data.local.dao.ChatDao
import pl.ultraai.android.data.local.dao.FolderDao
import pl.ultraai.android.data.local.dao.PromptDao
import pl.ultraai.android.data.local.dao.UsageAndDiagnosticDao
import pl.ultraai.android.data.local.entity.AiCharacterEntity
import pl.ultraai.android.data.local.entity.ApiKeyEntity
import pl.ultraai.android.data.local.entity.CachedResponseEntity
import pl.ultraai.android.data.local.entity.ChatMessageEntity
import pl.ultraai.android.data.local.entity.ChatSessionEntity
import pl.ultraai.android.data.local.entity.DiagnosticLogEntity
import pl.ultraai.android.data.local.entity.FolderEntity
import pl.ultraai.android.data.local.entity.PromptTemplateEntity
import pl.ultraai.android.data.local.entity.UsageLogEntity

@Database(
    entities = [
        ApiKeyEntity::class,
        FolderEntity::class,
        ChatSessionEntity::class,
        ChatMessageEntity::class,
        AiCharacterEntity::class,
        PromptTemplateEntity::class,
        UsageLogEntity::class,
        DiagnosticLogEntity::class,
        CachedResponseEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class UltraAiDatabase : RoomDatabase() {
    abstract fun apiKeyDao(): ApiKeyDao
    abstract fun folderDao(): FolderDao
    abstract fun chatDao(): ChatDao
    abstract fun characterDao(): CharacterDao
    abstract fun promptDao(): PromptDao
    abstract fun usageAndDiagnosticDao(): UsageAndDiagnosticDao

    companion object {
        @Volatile
        private var INSTANCE: UltraAiDatabase? = null

        fun getInstance(context: Context): UltraAiDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    UltraAiDatabase::class.java,
                    "ultra_ai_database.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
