package pl.ultraai.android.core.files

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets
import java.util.zip.ZipInputStream

data class ExtractedAttachment(
    val uriString: String,
    val displayName: String,
    val mimeType: String,
    val extractedText: String? = null,
    val imageBase64: String? = null,
    val sizeBytes: Long = 0L
)

/**
 * Ekstrahuje treść plików TXT, Markdown, JSON, CSV, kodu oraz podstawową warstwę tekstową PDF/DOCX
 * i bezpiecznie skaluje obrazy do Base64 na potrzeby modeli multimodalnych.
 */
object DocumentExtractor {

    fun extractFromUri(context: Context, uri: Uri): Result<ExtractedAttachment> = runCatching {
        val resolver = context.contentResolver
        val mime = resolver.getType(uri) ?: "application/octet-stream"
        var fileName = "zalacznik"
        var fileSize = 0L

        resolver.query(uri, null, null, null, null)?.use { cursor ->
            val nameIdx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val sizeIdx = cursor.getColumnIndex(OpenableColumns.SIZE)
            if (cursor.moveToFirst()) {
                if (nameIdx >= 0) fileName = cursor.getString(nameIdx) ?: fileName
                if (sizeIdx >= 0) fileSize = cursor.getLong(sizeIdx)
            }
        }

        when {
            mime.startsWith("image/") -> {
                val base64 = encodeImageToBase64(context, uri)
                ExtractedAttachment(
                    uriString = uri.toString(),
                    displayName = fileName,
                    mimeType = mime,
                    imageBase64 = base64,
                    sizeBytes = fileSize
                )
            }

            mime == "application/pdf" || fileName.endsWith(".pdf", ignoreCase = true) -> {
                val rawBytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                    ?: error("Nie można odczytać pliku PDF")
                val text = extractReadablePdfStrings(rawBytes)
                ExtractedAttachment(
                    uriString = uri.toString(),
                    displayName = fileName,
                    mimeType = "application/pdf",
                    extractedText = text.ifBlank {
                        "[Plik PDF nie zawiera nieskompresowanej warstwy tekstowej lub jest skanem — użyj analizy obrazu strony lub innego dokumentu tekstowego.]"
                    },
                    sizeBytes = fileSize
                )
            }

            fileName.endsWith(".docx", ignoreCase = true) -> {
                val text = extractDocxText(context, uri)
                ExtractedAttachment(
                    uriString = uri.toString(),
                    displayName = fileName,
                    mimeType = mime,
                    extractedText = text,
                    sizeBytes = fileSize
                )
            }

            else -> {
                val text = resolver.openInputStream(uri)?.bufferedReader(StandardCharsets.UTF_8)?.use {
                    it.readText()
                } ?: error("Nie można odczytać pliku tekstowego")
                ExtractedAttachment(
                    uriString = uri.toString(),
                    displayName = fileName,
                    mimeType = mime,
                    extractedText = text,
                    sizeBytes = fileSize
                )
            }
        }
    }

    private fun encodeImageToBase64(context: Context, uri: Uri): String {
        val stream = context.contentResolver.openInputStream(uri)
            ?: error("Brak dostępu do obrazu")
        val original = stream.use { BitmapFactory.decodeStream(it) }
            ?: error("Nieprawidłowy format obrazu")
        val maxDim = 1280
        val ratio = minOf(maxDim.toFloat() / original.width, maxDim.toFloat() / original.height, 1f)
        val scaled = if (ratio < 1f) {
            Bitmap.createScaledBitmap(
                original,
                (original.width * ratio).toInt().coerceAtLeast(1),
                (original.height * ratio).toInt().coerceAtLeast(1),
                true
            )
        } else original

        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /**
     * Lekki ekstraktor tekstu ze strumieni PDF BT..ET bez ciężkich zewnętrznych bibliotek natywnych.
     */
    private fun extractReadablePdfStrings(bytes: ByteArray): String {
        val raw = String(bytes, Charsets.ISO_8859_1)
        val sb = StringBuilder()
        val parenRegex = Regex("\\(([^()\\\\]{2,})\\)")
        parenRegex.findAll(raw).forEach { match ->
            val candidate = match.groupValues[1]
                .replace("\\n", "\n")
                .replace("\\r", " ")
                .trim()
            if (candidate.any { it.isLetterOrDigit() }) {
                sb.append(candidate).append(' ')
            }
        }
        return sb.toString().replace(Regex("\\s{2,}"), " ").trim().take(60_000)
    }

    private fun extractDocxText(context: Context, uri: Uri): String {
        val sb = StringBuilder()
        context.contentResolver.openInputStream(uri)?.use { input ->
            ZipInputStream(input).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (entry.name == "word/document.xml") {
                        val xml = zip.bufferedReader().readText()
                        val cleaned = xml.replace(Regex("<[^>]+>"), " ")
                            .replace(Regex("\\s+"), " ")
                            .trim()
                        sb.append(cleaned)
                        break
                    }
                    entry = zip.nextEntry
                }
            }
        }
        return sb.toString().take(60_000)
    }

    /**
     * Funkcja autorska: Smart Chunker — dzieli długi dokument na fragmenty dopasowane do okna kontekstowego modelu.
     */
    fun chunkText(text: String, maxCharsPerChunk: Int = 12_000): List<String> {
        if (text.length <= maxCharsPerChunk) return listOf(text)
        val chunks = mutableListOf<String>()
        var start = 0
        while (start < text.length) {
            val end = (start + maxCharsPerChunk).coerceAtMost(text.length)
            chunks.add(text.substring(start, end))
            start = end
        }
        return chunks
    }
}
