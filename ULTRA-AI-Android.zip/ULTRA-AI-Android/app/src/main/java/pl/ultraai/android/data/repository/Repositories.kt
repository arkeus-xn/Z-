package pl.ultraai.android.data.repository

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import pl.ultraai.android.core.security.KeystoreManager
import pl.ultraai.android.data.local.UltraAiDatabase
import pl.ultraai.android.data.local.entity.AiCharacterEntity
import pl.ultraai.android.data.local.entity.ApiKeyEntity
import pl.ultraai.android.data.local.entity.CachedResponseEntity
import pl.ultraai.android.data.local.entity.ChatMessageEntity
import pl.ultraai.android.data.local.entity.ChatSessionEntity
import pl.ultraai.android.data.local.entity.DiagnosticLogEntity
import pl.ultraai.android.data.local.entity.FolderEntity
import pl.ultraai.android.data.local.entity.PromptTemplateEntity
import pl.ultraai.android.data.local.entity.UsageLogEntity
import pl.ultraai.android.data.remote.ConnectionTestResult
import pl.ultraai.android.data.remote.UnifiedAiGateway
import pl.ultraai.android.domain.model.AiModelInfo
import pl.ultraai.android.domain.model.AiProvider
import pl.ultraai.android.domain.model.ProviderRateStatus
import java.security.MessageDigest
import java.util.Calendar

class ApiKeyAndModelRepository(
    private val db: UltraAiDatabase,
    private val keystore: KeystoreManager,
    private val gateway: UnifiedAiGateway
) {
    private val dao = db.apiKeyDao()
    private val diagDao = db.usageAndDiagnosticDao()

    private val _discoveredModels = MutableStateFlow<List<AiModelInfo>>(emptyList())
    val discoveredModels: StateFlow<List<AiModelInfo>> = _discoveredModels.asStateFlow()

    private val _providerStatus = MutableStateFlow<Map<AiProvider, ProviderRateStatus>>(emptyMap())
    val providerStatus: StateFlow<Map<AiProvider, ProviderRateStatus>> = _providerStatus.asStateFlow()

    fun observeKeys(): Flow<List<ApiKeyEntity>> = dao.observeAll()

    suspend fun addOrUpdateKey(
        id: Long? = null,
        provider: AiProvider,
        label: String,
        rawKey: String,
        setActive: Boolean = true
    ): Long {
        val trimmed = rawKey.trim()
        val encrypted = keystore.encrypt(trimmed)
        val masked = keystore.maskKey(trimmed)
        if (setActive) {
            dao.deactivateAllForProvider(provider.name)
        }
        val entity = ApiKeyEntity(
            id = id ?: 0L,
            provider = provider.name,
            label = label.ifBlank { "${provider.displayName} Klucz" },
            encryptedKey = encrypted.cipherTextBase64,
            iv = encrypted.ivBase64,
            maskedKey = masked,
            isActive = setActive
        )
        val savedId = if (id == null || id == 0L) {
            dao.insert(entity)
        } else {
            dao.update(entity)
            id
        }
        diagDao.insertDiagnostic(
            DiagnosticLogEntity(
                level = "INFO",
                tag = "Keystore",
                message = "Zapisano zaszyfrowany klucz dla ${provider.displayName} (${entity.label}, $masked)."
            )
        )
        return savedId
    }

    suspend fun activateKey(entity: ApiKeyEntity) {
        dao.deactivateAllForProvider(entity.provider)
        dao.activateKey(entity.id)
        refreshProviderModels(AiProvider.valueOf(entity.provider))
    }

    suspend fun deleteKey(entity: ApiKeyEntity) {
        dao.delete(entity)
        val provider = AiProvider.valueOf(entity.provider)
        _discoveredModels.value = _discoveredModels.value.filterNot { it.provider == provider }
    }

    suspend fun getDecryptedActiveKey(provider: AiProvider): String? {
        val entity = dao.getActiveForProvider(provider.name) ?: return null
        return runCatching { keystore.decrypt(entity.encryptedKey, entity.iv) }.getOrNull()
    }

    suspend fun testKeyAndRefresh(entity: ApiKeyEntity): ConnectionTestResult {
        val rawKey = runCatching { keystore.decrypt(entity.encryptedKey, entity.iv) }.getOrNull()
            ?: return ConnectionTestResult(false, "Nie udało się odszyfrować klucza z Android Keystore.")
        val provider = AiProvider.valueOf(entity.provider)
        val result = gateway.testAndFetchModels(provider, rawKey)

        dao.update(
            entity.copy(
                lastTestedAt = System.currentTimeMillis(),
                lastStatus = if (result.success) "Połączono (${result.models.size} modeli)" else result.message.take(120),
                rateLimitSummary = result.rateLimitSummary
            )
        )

        if (result.success) {
            val others = _discoveredModels.value.filterNot { it.provider == provider }
            _discoveredModels.value = others + result.models
            _providerStatus.value = _providerStatus.value + (
                provider to ProviderRateStatus(
                    provider = provider,
                    isConnected = true,
                    activeKeyLabel = entity.label,
                    modelsCount = result.models.size,
                    remainingRequests = result.rateLimitSummary,
                    lastCheckedAt = System.currentTimeMillis()
                )
            )
        } else {
            _providerStatus.value = _providerStatus.value + (
                provider to ProviderRateStatus(
                    provider = provider,
                    isConnected = false,
                    activeKeyLabel = entity.label,
                    modelsCount = 0,
                    lastError = result.message,
                    lastCheckedAt = System.currentTimeMillis()
                )
            )
        }
        diagDao.insertDiagnostic(
            DiagnosticLogEntity(
                level = if (result.success) "INFO" else "ERROR",
                tag = provider.name,
                message = result.message
            )
        )
        return result
    }

    suspend fun refreshAllActiveProviders() {
        AiProvider.entries.forEach { refreshProviderModels(it) }
    }

    suspend fun refreshProviderModels(provider: AiProvider) {
        val active = dao.getActiveForProvider(provider.name) ?: return
        testKeyAndRefresh(active)
    }
}

class ChatRepository(private val db: UltraAiDatabase) {
    private val chatDao = db.chatDao()
    private val folderDao = db.folderDao()
    private val diagDao = db.usageAndDiagnosticDao()

    fun observeSessions(): Flow<List<ChatSessionEntity>> = chatDao.observeSessions()
    fun observeMessages(sessionId: Long): Flow<List<ChatMessageEntity>> = chatDao.observeMessages(sessionId)
    fun observeFolders(): Flow<List<FolderEntity>> = folderDao.observeAll()
    fun observeCharacterSessions(characterId: Long): Flow<List<ChatSessionEntity>> =
        chatDao.observeSessionsByCharacter(characterId)

    suspend fun createFolder(name: String, colorHex: Long = 0xFF3B82F6): Long =
        folderDao.insert(FolderEntity(name = name.trim(), colorHex = colorHex))

    suspend fun deleteFolder(folder: FolderEntity) = folderDao.delete(folder)

    suspend fun createSession(
        title: String,
        provider: AiProvider,
        modelId: String,
        folderId: Long? = null,
        characterId: Long? = null,
        isIncognito: Boolean = false
    ): Long {
        return chatDao.insertSession(
            ChatSessionEntity(
                title = title,
                folderId = folderId,
                characterId = characterId,
                provider = provider.name,
                modelId = modelId,
                isIncognito = isIncognito
            )
        )
    }

    suspend fun getSession(id: Long): ChatSessionEntity? = chatDao.getSessionById(id)
    suspend fun updateSession(session: ChatSessionEntity) = chatDao.updateSession(session)
    suspend fun deleteSession(session: ChatSessionEntity) = chatDao.deleteSession(session)

    suspend fun addMessage(message: ChatMessageEntity): Long {
        val id = chatDao.insertMessage(message)
        val session = chatDao.getSessionById(message.sessionId)
        if (session != null) {
            chatDao.updateSession(
                session.copy(
                    totalInputTokens = session.totalInputTokens + message.inputTokens,
                    totalOutputTokens = session.totalOutputTokens + message.outputTokens,
                    totalCostUsd = session.totalCostUsd + (message.costUsd ?: 0.0),
                    updatedAt = System.currentTimeMillis()
                )
            )
        }
        return id
    }

    suspend fun getMessagesOnce(sessionId: Long): List<ChatMessageEntity> =
        chatDao.getMessagesOnce(sessionId)

    suspend fun updateMessage(message: ChatMessageEntity) = chatDao.updateMessage(message)
    suspend fun deleteMessagesFrom(sessionId: Long, fromId: Long) =
        chatDao.deleteMessagesFrom(sessionId, fromId)

    suspend fun searchSessionIds(query: String): Set<Long> {
        if (query.isBlank()) return emptySet()
        return chatDao.searchSessionIdsByContent(query).toSet()
    }

    suspend fun clearAllHistory() {
        chatDao.deleteAllSessions()
    }

    suspend fun cacheResponse(prompt: String, modelId: String, response: String) {
        val hash = sha256("$modelId::$prompt")
        diagDao.putCachedResponse(CachedResponseEntity(hash, modelId, response))
    }

    suspend fun getCachedResponse(prompt: String, modelId: String): String? {
        val hash = sha256("$modelId::$prompt")
        return diagDao.getCachedResponse(hash)?.responseText
    }

    private fun sha256(input: String): String {
        return MessageDigest.getInstance("SHA-256")
            .digest(input.toByteArray())
            .joinToString("") { "%02x".format(it) }
    }
}

class CharacterAndPromptRepository(private val db: UltraAiDatabase) {
    private val charDao = db.characterDao()
    private val promptDao = db.promptDao()

    fun observeCharacters(): Flow<List<AiCharacterEntity>> = charDao.observeAll()
    fun observePrompts(): Flow<List<PromptTemplateEntity>> = promptDao.observeAll()

    suspend fun seedInitialDataIfEmpty() {
        if (charDao.getAllOnce().isEmpty()) {
            val starters = listOf(
                AiCharacterEntity(
                    name = "Klara – Architekt Kodu",
                    avatarEmoji = "⚡",
                    avatarColorHex = 0xFF3B82F6,
                    personality = "Konkretna, analityczna, skupiona na czystej architekturze",
                    traits = "Logiczna, bezkompromisowa w kwestii jakości i bezpieczeństwa",
                    speakingStyle = "Techniczny, zwięzły, z przykładami kodu i diagramami krok po kroku",
                    systemPrompt = "Jesteś Klarą, doświadczoną architektką oprogramowania Android i Kotlin. Analizujesz przypadki brzegowe, unikasz długu technologicznego i dajesz gotowe wzorce.",
                    temperature = 0.35f,
                    memoryEnabled = true,
                    isBuiltIn = true
                ),
                AiCharacterEntity(
                    name = "Profesor Marek – Mentor",
                    avatarEmoji = "🎓",
                    avatarColorHex = 0xFF10B981,
                    personality = "Cierpliwy, ciekawy świata, stosuje metodę sokratejską",
                    traits = "Empatyczny, uporządkowany, potrafi tłumaczyć trudne pojęcia prosto",
                    speakingStyle = "Dydaktyczny, przejrzysty, z analogiami i krótkimi pytaniami sprawdzającymi",
                    systemPrompt = "Jesteś Profesorem Markiem. Uczysz krok po kroku, sprawdzasz zrozumienie i dostosowujesz poziom trudności do ucznia.",
                    temperature = 0.6f,
                    memoryEnabled = true,
                    isBuiltIn = true
                ),
                AiCharacterEntity(
                    name = "Astra – Strateg Produktu",
                    avatarEmoji = "🧭",
                    avatarColorHex = 0xFF8B5CF6,
                    personality = "Kreatywna, pragmatyczna, nastawiona na użytkownika",
                    traits = "Pomysłowa, syntetyczna, dostrzega ryzyka biznesowe",
                    speakingStyle = "Dynamiczny, uporządkowany w punktach, nastawiony na działanie",
                    systemPrompt = "Jesteś Astrą, dyrektorką strategii produktu. Pomagasz tworzyć koncepcje, analizować rynek i pisać przekonujące treści.",
                    temperature = 0.85f,
                    memoryEnabled = true,
                    isBuiltIn = true
                )
            )
            starters.forEach { charDao.insert(it) }
        }

        if (promptDao.getAllOnce().isEmpty()) {
            val templates = listOf(
                PromptTemplateEntity(
                    title = "Przegląd kodu Kotlin / Compose",
                    category = "Programowanie",
                    content = "Przeanalizuj poniższy kod Kotlin/Jetpack Compose pod kątem wycieków pamięci, rekompozycji, obsługi błędów i czytelności. Wypisz konkretne poprawki:\n\n[WKLEJ KOD]",
                    isFavorite = true
                ),
                PromptTemplateEntity(
                    title = "Streszczenie dokumentu w 5 punktach",
                    category = "Produktywność",
                    content = "Streść poniższy tekst w 5 konkretnych punktach, podaj kluczowe liczby oraz listę działań do wykonania:\n\n[WKLEJ TEKST]"
                ),
                PromptTemplateEntity(
                    title = "Tłumaczenie biznesowe PL ↔ EN",
                    category = "Języki",
                    content = "Przetłumacz poniższą wiadomość na naturalny, profesjonalny język angielski (styl biznesowy, bez kalk językowych):\n\n[TREŚĆ]"
                ),
                PromptTemplateEntity(
                    title = "Plan nauki na 14 dni",
                    category = "Edukacja",
                    content = "Ułóż intensywny, realistyczny plan nauki tematu: [TEMAT] na 14 dni (po 45 minut dziennie), z zadaniami praktycznymi i sposobem weryfikacji wiedzy."
                )
            )
            templates.forEach { promptDao.insert(it) }
        }
    }

    suspend fun saveCharacter(character: AiCharacterEntity): Long {
        return if (character.id == 0L) charDao.insert(character)
        else {
            charDao.update(character)
            character.id
        }
    }

    suspend fun duplicateCharacter(character: AiCharacterEntity): Long {
        return charDao.insert(
            character.copy(
                id = 0L,
                name = "${character.name} (Kopia)",
                isBuiltIn = false,
                createdAt = System.currentTimeMillis()
            )
        )
    }

    suspend fun deleteCharacter(character: AiCharacterEntity) = charDao.delete(character)
    suspend fun getCharacter(id: Long): AiCharacterEntity? = charDao.getById(id)
    suspend fun clearAllMemories() = charDao.clearAllMemories()

    suspend fun savePrompt(template: PromptTemplateEntity): Long {
        return if (template.id == 0L) promptDao.insert(template)
        else {
            promptDao.update(template)
            template.id
        }
    }

    suspend fun deletePrompt(template: PromptTemplateEntity) = promptDao.delete(template)
}

class UsageRepository(private val db: UltraAiDatabase) {
    private val dao = db.usageAndDiagnosticDao()

    fun observeUsage(): Flow<List<UsageLogEntity>> = dao.observeUsageLogs()
    fun observeDiagnostics(): Flow<List<DiagnosticLogEntity>> = dao.observeDiagnostics()

    suspend fun logUsage(
        featureName: String,
        provider: AiProvider,
        modelId: String,
        inputTokens: Int,
        outputTokens: Int,
        estimatedCostUsd: Double?,
        latencyMs: Long
    ) {
        dao.insertUsage(
            UsageLogEntity(
                featureName = featureName,
                provider = provider.name,
                modelId = modelId,
                inputTokens = inputTokens,
                outputTokens = outputTokens,
                estimatedCostUsd = estimatedCostUsd,
                latencyMs = latencyMs
            )
        )
    }

    suspend fun logDiagnostic(level: String, tag: String, message: String) {
        dao.insertDiagnostic(DiagnosticLogEntity(level = level, tag = tag, message = message))
    }

    suspend fun getTodaySpentUsd(): Double = dao.sumCostSince(startOfDayMillis())
    suspend fun getTodayRequestCount(): Int = dao.countRequestsSince(startOfDayMillis())
    suspend fun getMonthSpentUsd(): Double = dao.sumCostSince(startOfMonthMillis())

    suspend fun clearUsage() = dao.clearUsage()
    suspend fun clearDiagnostics() = dao.clearDiagnostics()
    suspend fun clearCache() = dao.clearCache()

    private fun startOfDayMillis(): Long {
        return Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    private fun startOfMonthMillis(): Long {
        return Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
}
