package pl.ultraai.android.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable

@Entity(tableName = "api_keys")
data class ApiKeyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val provider: String, // "GEMINI" | "GROQ"
    val label: String,
    val encryptedKey: String,
    val iv: String,
    val maskedKey: String,
    val isActive: Boolean = false,
    val lastTestedAt: Long? = null,
    val lastStatus: String = "Nieprzetestowany",
    val rateLimitSummary: String = "Brak danych",
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "folders")
data class FolderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val colorHex: Long = 0xFF3B82F6,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val folderId: Long? = null,
    val characterId: Long? = null,
    val provider: String,
    val modelId: String,
    val isPinned: Boolean = false,
    val isArchived: Boolean = false,
    val isIncognito: Boolean = false,
    val totalInputTokens: Int = 0,
    val totalOutputTokens: Int = 0,
    val totalCostUsd: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(
    tableName = "chat_messages",
    foreignKeys = [
        ForeignKey(
            entity = ChatSessionEntity::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sessionId")]
)
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sessionId: Long,
    val role: String, // "user" | "model" | "system"
    val content: String,
    val attachmentName: String? = null,
    val attachmentMime: String? = null,
    val attachmentPreviewText: String? = null,
    val imageBase64: String? = null,
    val modelUsed: String? = null,
    val inputTokens: Int = 0,
    val outputTokens: Int = 0,
    val costUsd: Double? = null,
    val latencyMs: Long = 0L,
    val isError: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "ai_characters")
data class AiCharacterEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val avatarEmoji: String = "🤖",
    val avatarColorHex: Long = 0xFF3B82F6,
    val personality: String,
    val traits: String,
    val speakingStyle: String,
    val systemPrompt: String,
    val preferredProvider: String = "GEMINI",
    val preferredModelId: String = "",
    val temperature: Float = 0.7f,
    val memoryEnabled: Boolean = true,
    val memorySummary: String = "",
    val isBuiltIn: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "prompt_templates")
data class PromptTemplateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val category: String,
    val content: String,
    val isFavorite: Boolean = false,
    val usageCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
@Entity(tableName = "usage_logs")
data class UsageLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val featureName: String,
    val provider: String,
    val modelId: String,
    val inputTokens: Int,
    val outputTokens: Int,
    val estimatedCostUsd: Double?,
    val latencyMs: Long,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "diagnostic_logs")
data class DiagnosticLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val level: String, // INFO, WARN, ERROR
    val tag: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "cached_responses")
data class CachedResponseEntity(
    @PrimaryKey val promptHash: String,
    val modelId: String,
    val responseText: String,
    val createdAt: Long = System.currentTimeMillis()
)
