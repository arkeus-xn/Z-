package pl.ultraai.android.ui.games

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

enum class LetterMatch { CORRECT, PRESENT, ABSENT }

data class WordGuessRow(
    val word: String,
    val matches: List<LetterMatch>
)

object PolishWordGameEngine {
    val dictionary = listOf(
        "KODER", "EKRAN", "CHMUR", "SILNY", "PISMO", "OBRAZ", "DANEK", "WYNIK",
        "LOGIK", "MOTOR", "KLUCZ", "PAMIĘ", "LASER", "SONAR", "RADAR", "ZEGAR",
        "ROBOT", "MODEL", "TEKST", "LINIA", "PUNKT", "WĘZEŁ", "DYSKI", "ALARM",
        "ATLAS", "BARKA", "BIURO", "BRAMA", "BURZA", "CUKIER".take(5)
    ).map { it.take(5).uppercase() }.filter { it.length == 5 }.distinct()

    fun pickSecretWord(): String = dictionary.random()

    fun evaluateGuess(guess: String, secret: String): List<LetterMatch> {
        val g = guess.uppercase().take(5).padEnd(5, ' ')
        val s = secret.uppercase()
        val result = MutableList(5) { LetterMatch.ABSENT }
        val remaining = s.toMutableList()

        // 1. Dokładne trafienia
        for (i in 0..4) {
            if (g[i] == s[i]) {
                result[i] = LetterMatch.CORRECT
                remaining[i] = '*'
            }
        }
        // 2. Litery obecne na złej pozycji
        for (i in 0..4) {
            if (result[i] == LetterMatch.CORRECT) continue
            val idx = remaining.indexOf(g[i])
            if (idx != -1) {
                result[i] = LetterMatch.PRESENT
                remaining[idx] = '*'
            }
        }
        return result
    }
}

@Serializable
data class QuizQuestion(
    val question: String,
    val options: List<String>,
    val correctIndex: Int,
    val explanation: String
)

object QuizParser {
    private val json = Json { ignoreUnknownKeys = true }

    val fallbackQuestions = listOf(
        QuizQuestion(
            question = "Który algorytm szyfrowania symetrycznego wykorzystuje Android Keystore w ULTRA AI do ochrony kluczy API?",
            options = listOf("AES-256-GCM", "DES-56", "ROT13", "MD5"),
            correctIndex = 0,
            explanation = "AES-256-GCM zapewnia zarówno poufność, jak i uwierzytelnianie integralności danych."
        ),
        QuizQuestion(
            question = "Jaki protokół służy do strumieniowego przesyłania tokenów odpowiedzi z API w czasie rzeczywistym?",
            options = listOf("FTP", "Server-Sent Events (SSE)", "SMTP", "SNMP"),
            correctIndex = 1,
            explanation = "Zarówno Gemini API (?alt=sse), jak i Groq API (stream=true) używają SSE po HTTPS."
        ),
        QuizQuestion(
            question = "Co oznacza skrót MVVM w architekturze aplikacji Android?",
            options = listOf(
                "Model-View-ViewModel",
                "Module-Variable-View-Manager",
                "Memory-Virtual-Vector-Map",
                "Multi-View-Validation-Mode"
            ),
            correctIndex = 0,
            explanation = "MVVM rozdziela logikę prezentacji (ViewModel + StateFlow) od warstwy UI w Compose."
        )
    )

    fun parseAiQuizJson(raw: String): List<QuizQuestion> {
        val cleaned = raw.substringAfter("[").let { "[$it" }.substringBeforeLast("]") + "]"
        return runCatching { json.decodeFromString<List<QuizQuestion>>(cleaned) }
            .getOrDefault(emptyList())
            .filter { it.options.size >= 2 && it.correctIndex in it.options.indices }
    }
}
