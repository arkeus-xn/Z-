package pl.ultraai.android

import android.app.Application
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import pl.ultraai.android.core.files.BackupManager
import pl.ultraai.android.core.security.KeystoreManager
import pl.ultraai.android.core.speech.SpeechAndTtsManager
import pl.ultraai.android.data.local.SettingsDataStore
import pl.ultraai.android.data.local.UltraAiDatabase
import pl.ultraai.android.data.remote.GeminiApiClient
import pl.ultraai.android.data.remote.GroqApiClient
import pl.ultraai.android.data.remote.UnifiedAiGateway
import pl.ultraai.android.data.repository.ApiKeyAndModelRepository
import pl.ultraai.android.data.repository.CharacterAndPromptRepository
import pl.ultraai.android.data.repository.ChatRepository
import pl.ultraai.android.data.repository.UsageRepository

class AppContainer(application: Application) {
    val database: UltraAiDatabase = UltraAiDatabase.getInstance(application)
    val settingsStore: SettingsDataStore = SettingsDataStore(application)
    val keystoreManager: KeystoreManager = KeystoreManager()
    val geminiClient: GeminiApiClient = GeminiApiClient()
    val groqClient: GroqApiClient = GroqApiClient()
    val aiGateway: UnifiedAiGateway = UnifiedAiGateway(geminiClient, groqClient)
    val apiKeyAndModelRepo: ApiKeyAndModelRepository = ApiKeyAndModelRepository(database, keystoreManager, aiGateway)
    val chatRepo: ChatRepository = ChatRepository(database)
    val characterAndPromptRepo: CharacterAndPromptRepository = CharacterAndPromptRepository(database)
    val usageRepo: UsageRepository = UsageRepository(database)
    val backupManager: BackupManager = BackupManager(application, database)
    val speechAndTtsManager: SpeechAndTtsManager = SpeechAndTtsManager(application)
}

class UltraAiApplication : Application() {
    lateinit var container: AppContainer
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
        appScope.launch {
            container.characterAndPromptRepo.seedInitialDataIfEmpty()
            container.apiKeyAndModelRepo.refreshAllActiveProviders()
        }
    }
}
