package pl.ultraai.android.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okio.BufferedSource
import pl.ultraai.android.core.pricing.ModelPricingRegistry
import pl.ultraai.android.domain.model.AiModelInfo
import pl.ultraai.android.domain.model.AiProvider
import pl.ultraai.android.domain.model.ModelCapability
import java.io.IOException
import java.util.concurrent.TimeUnit

class GroqApiClient(
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val mediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchModels(apiKey: String): ConnectionTestResult = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext ConnectionTestResult(false, "Klucz Groq API jest pusty.")
        }
        val request = Request.Builder()
            .url("${AiProvider.GROQ.baseUrl}/models")
            .addHeader("Authorization", "Bearer $cleanKey")
            .get()
            .build()

        runCatching {
            okHttpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                val rateSummary = extractRateLimitHeaders(response)
                if (!response.isSuccessful) {
                    val err = parseGroqError(bodyStr, response.code)
                    return@withContext ConnectionTestResult(false, err, rateLimitSummary = rateSummary)
                }

                val root = json.parseToJsonElement(bodyStr).jsonObject
                val dataArr = root["data"]?.jsonArray ?: JsonArray(emptyList())
                val parsed = dataArr.mapNotNull { elem ->
                    val obj = elem.jsonObject
                    val id = obj["id"]?.jsonPrimitive?.content ?: return@mapNotNull null
                    val active = obj["active"]?.jsonPrimitive?.content?.toBooleanStrictOrNull() ?: true
                    val contextWindow = obj["context_window"]?.jsonPrimitive?.intOrNull
                    val ownedBy = obj["owned_by"]?.jsonPrimitive?.content.orEmpty()
                    // Pomijamy modele typowo audio/whisper w liście modeli czatu
                    if (id.contains("whisper", ignoreCase = true)) return@mapNotNull null

                    val verified = ModelPricingRegistry.lookupMetadata(AiProvider.GROQ, id)
                    val caps = mutableSetOf(ModelCapability.TEXT, ModelCapability.STREAMING)
                    if (verified != null) caps.addAll(verified.extraCapabilities)
                    if (id.contains("vision", ignoreCase = true)) caps.add(ModelCapability.VISION)
                    if ((contextWindow ?: 0) >= 128_000) caps.add(ModelCapability.LONG_CONTEXT)

                    AiModelInfo(
                        id = id,
                        displayName = id,
                        provider = AiProvider.GROQ,
                        description = if (ownedBy.isNotBlank()) "Dostawca modelu: $ownedBy" else "Model Groq LPU",
                        inputContextLimit = contextWindow,
                        outputTokenLimit = null,
                        inputPricePer1MUsd = verified?.inputPricePer1MUsd,
                        outputPricePer1MUsd = verified?.outputPricePer1MUsd,
                        freeTierInfo = verified?.freeTierInfo ?: "Brak danych",
                        capabilities = caps,
                        isAvailable = active,
                        speedTier = verified?.speedTier ?: 3,
                        qualityTier = verified?.qualityTier ?: 2
                    )
                }.sortedByDescending { it.qualityTier }

                ConnectionTestResult(
                    success = true,
                    message = "Połączono z Groq API. Pobrano ${parsed.size} modeli.",
                    models = parsed,
                    rateLimitSummary = rateSummary
                )
            }
        }.getOrElse { ex ->
            ConnectionTestResult(false, "Błąd sieci Groq: ${ex.localizedMessage ?: "nieznany błąd"}")
        }
    }

    fun streamChatCompletion(
        apiKey: String,
        modelId: String,
        systemPrompt: String,
        messages: List<AiTurnMessage>,
        temperature: Float,
        maxTokens: Int
    ): Flow<AiStreamEvent> = callbackFlow {
        val startTime = System.currentTimeMillis()
        val payload = buildRequestJson(modelId, systemPrompt, messages, temperature, maxTokens)
        val request = Request.Builder()
            .url("${AiProvider.GROQ.baseUrl}/chat/completions")
            .addHeader("Authorization", "Bearer ${apiKey.trim()}")
            .post(payload.toRequestBody(mediaType))
            .build()

        val call = okHttpClient.newCall(request)
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!call.isCanceled()) {
                    trySend(AiStreamEvent.Error("Błąd połączenia z Groq: ${e.localizedMessage}"))
                }
                close()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { res ->
                    val rateSummary = extractRateLimitHeaders(res)
                    if (!res.isSuccessful) {
                        val errBody = res.body?.string().orEmpty()
                        trySend(AiStreamEvent.Error(parseGroqError(errBody, res.code), res.code))
                        close()
                        return
                    }

                    val source: BufferedSource = res.body?.source() ?: run {
                        trySend(AiStreamEvent.Error("Pusta odpowiedź z Groq API."))
                        close()
                        return
                    }

                    val fullText = StringBuilder()
                    var inputTokens = 0
                    var outputTokens = 0

                    try {
                        while (!source.exhausted() && !call.isCanceled()) {
                            val line = source.readUtf8Line() ?: break
                            if (!line.startsWith("data:")) continue
                            val dataJson = line.removePrefix("data:").trim()
                            if (dataJson.isBlank()) continue
                            if (dataJson == "[DONE]") break

                            val obj = runCatching { json.parseToJsonElement(dataJson).jsonObject }.getOrNull()
                                ?: continue

                            obj["x_groq"]?.jsonObject?.get("usage")?.jsonObject?.let { usage ->
                                inputTokens = usage["prompt_tokens"]?.jsonPrimitive?.intOrNull ?: inputTokens
                                outputTokens = usage["completion_tokens"]?.jsonPrimitive?.intOrNull ?: outputTokens
                            }
                            obj["usage"]?.jsonObject?.let { usage ->
                                inputTokens = usage["prompt_tokens"]?.jsonPrimitive?.intOrNull ?: inputTokens
                                outputTokens = usage["completion_tokens"]?.jsonPrimitive?.intOrNull ?: outputTokens
                            }

                            val choices = obj["choices"]?.jsonArray ?: continue
                            val firstChoice = choices.firstOrNull()?.jsonObject ?: continue
                            val delta = firstChoice["delta"]?.jsonObject ?: continue
                            val content = delta["content"]?.jsonPrimitive?.content
                            if (!content.isNullOrEmpty()) {
                                fullText.append(content)
                                trySend(AiStreamEvent.Delta(content))
                            }
                        }

                        if (!call.isCanceled()) {
                            val latency = System.currentTimeMillis() - startTime
                            trySend(
                                AiStreamEvent.Completed(
                                    fullText = fullText.toString(),
                                    inputTokens = inputTokens,
                                    outputTokens = outputTokens,
                                    latencyMs = latency,
                                    rateLimitInfo = rateSummary
                                )
                            )
                        }
                    } catch (e: Exception) {
                        if (!call.isCanceled()) {
                            trySend(AiStreamEvent.Error("Błąd strumienia Groq: ${e.localizedMessage}"))
                        }
                    } finally {
                        close()
                    }
                }
            }
        })

        awaitClose { call.cancel() }
    }

    private fun buildRequestJson(
        modelId: String,
        systemPrompt: String,
        messages: List<AiTurnMessage>,
        temperature: Float,
        maxTokens: Int
    ): String {
        val root = buildJsonObject {
            put("model", modelId)
            put("temperature", temperature.toDouble())
            put("max_tokens", maxTokens)
            put("stream", true)
            put("messages", buildJsonArray {
                if (systemPrompt.isNotBlank()) {
                    add(buildJsonObject {
                        put("role", "system")
                        put("content", systemPrompt)
                    })
                }
                messages.forEach { msg ->
                    add(buildJsonObject {
                        put("role", if (msg.role == "model") "assistant" else "user")
                        if (!msg.imageBase64.isNullOrBlank()) {
                            put("content", buildJsonArray {
                                if (msg.text.isNotBlank()) {
                                    add(buildJsonObject {
                                        put("type", "text")
                                        put("text", msg.text)
                                    })
                                }
                                add(buildJsonObject {
                                    put("type", "image_url")
                                    put("image_url", buildJsonObject {
                                        put("url", "data:${msg.imageMimeType ?: "image/jpeg"};base64,${msg.imageBase64}")
                                    })
                                })
                            })
                        } else {
                            put("content", msg.text)
                        }
                    })
                }
            })
        }
        return root.toString()
    }

    private fun extractRateLimitHeaders(response: Response): String {
        val remReq = response.header("x-ratelimit-remaining-requests")
        val limReq = response.header("x-ratelimit-limit-requests")
        val remTok = response.header("x-ratelimit-remaining-tokens")
        val limTok = response.header("x-ratelimit-limit-tokens")
        return if (remReq != null || remTok != null) {
            "Zapytania: ${remReq ?: "?"}/${limReq ?: "?"} • Tokeny: ${remTok ?: "?"}/${limTok ?: "?"}"
        } else {
            "Brak danych"
        }
    }

    private fun parseGroqError(body: String, code: Int): String {
        val msg = runCatching {
            json.parseToJsonElement(body).jsonObject["error"]?.jsonObject?.get("message")?.jsonPrimitive?.content
        }.getOrNull()
        return when (code) {
            401, 403 -> "Błąd autoryzacji ($code): Sprawdź poprawność klucza Groq API. ${msg.orEmpty()}"
            429 -> "Przekroczono limit zapytań Groq (429). ${msg.orEmpty()}"
            else -> "Błąd Groq API ($code): ${msg ?: body.take(220)}"
        }
    }
}
