package pl.ultraai.android.ui.tools

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pl.ultraai.android.AppContainer
import pl.ultraai.android.core.files.DocumentExtractor
import pl.ultraai.android.core.files.ExtractedAttachment
import pl.ultraai.android.core.pricing.CostEstimator
import pl.ultraai.android.data.local.entity.PromptTemplateEntity
import pl.ultraai.android.data.local.entity.UsageLogEntity
import pl.ultraai.android.data.remote.AiTurnMessage
import pl.ultraai.android.domain.model.AiModelInfo
import pl.ultraai.android.domain.model.ModelCapability

enum class UltraToolType(val titlePl: String, val subtitlePl: String) {
    RESEARCH("AI Research", "Głęboka analiza tematu, tezy, źródła i wnioski"),
    CODE_STUDIO("AI Code Studio", "Generowanie, refaktoryzacja i debugowanie kodu"),
    WRITER("AI Writer", "Artykuły, maile, scenariusze i copywriting"),
    TRANSLATOR("AI Translator", "Tłumacz kontekstowy z wyborem stylu i lektorem"),
    TUTOR("AI Tutor", "Nauka krok po kroku i sprawdzanie wiedzy"),
    PROMPT_GENERATOR("Generator i Biblioteka Promptów", "Twórz, ulepszaj i zapisuj szablony promptów"),
    DOC_ANALYZER("Analiza PDF i TXT", "Ekstrakcja tekstu i analiza wielkich dokumentów (Smart Chunker)"),
    VISION("Rozpoznawanie obrazów", "Analiza zdjęć, zrzutów ekranu i diagramów"),
    STATS_COSTS("Statystyki i Historia Kosztów", "Tokeny, wydatki i macierz opłacalności modeli"),
    BACKUP("Kopie Zapasowe (Eksport/Import)", "Bezpieczny eksport i import danych JSON")
}

data class ToolsUiState(
    val activeTool: UltraToolType? = null,
    val availableModels: List<AiModelInfo> = emptyList(),
    val prompts: List<PromptTemplateEntity> = emptyList(),
    val usageLogs: List<UsageLogEntity> = emptyList(),
    val attachment: ExtractedAttachment? = null,
    val isRunning: Boolean = false,
    val outputText: String = "",
    val statusMessage: String? = null
)

class ToolsViewModel(private val container: AppContainer) : ViewModel() {

    private val activeTool = MutableStateFlow<UltraToolType?>(null)
    private val attachment = MutableStateFlow<ExtractedAttachment?>(null)
    private val isRunning = MutableStateFlow(false)
    private val outputText = MutableStateFlow("")
    private val statusMessage = MutableStateFlow<String?>(null)

    val uiState: StateFlow<ToolsUiState> = combine(
        listOf<Flow<Any?>>(
            container.apiKeyAndModelRepo.discoveredModels,
            container.characterAndPromptRepo.observePrompts(),
            container.usageRepo.observeUsage(),
            activeTool,
            attachment,
            isRunning,
            outputText,
            statusMessage
        )
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        ToolsUiState(
            availableModels = arr[0] as List<AiModelInfo>,
            prompts = arr[1] as List<PromptTemplateEntity>,
            usageLogs = arr[2] as List<UsageLogEntity>,
            activeTool = arr[3] as UltraToolType?,
            attachment = arr[4] as ExtractedAttachment?,
            isRunning = arr[5] as Boolean,
            outputText = arr[6] as String,
            statusMessage = arr[7] as String?
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ToolsUiState())

    fun openTool(tool: UltraToolType?) {
        activeTool.value = tool
        outputText.value = ""
        statusMessage.value = null
    }

    fun attachDocumentOrImage(context: Context, uri: Uri) {
        viewModelScope.launch {
            DocumentExtractor.extractFromUri(context, uri)
                .onSuccess { attachment.value = it }
                .onFailure { statusMessage.value = "Błąd odczytu pliku: ${it.localizedMessage}" }
        }
    }

    fun runToolPrompt(
        featureLabel: String,
        systemPrompt: String,
        userPrompt: String,
        requiresVision: Boolean = false,
        temperature: Float = 0.5f
    ) {
        val state = uiState.value
        val model = if (requiresVision) {
            state.availableModels.firstOrNull { ModelCapability.VISION in it.capabilities }
                ?: state.availableModels.firstOrNull()
        } else {
            state.availableModels.firstOrNull()
        }
        if (model == null) {
            statusMessage.value = "Brak dostępnego modelu. Dodaj klucz API w Ustawieniach."
            return
        }

        viewModelScope.launch {
            isRunning.value = true
            outputText.value = ""
            statusMessage.value = null
            val key = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider).orEmpty()

            val att = state.attachment
            if (att?.extractedText != null && att.extractedText.length > 14_000) {
                // Smart Chunker dla długich plików PDF/TXT
                val chunks = DocumentExtractor.chunkText(att.extractedText, 12_000).take(5)
                val partials = StringBuilder()
                chunks.forEachIndexed { idx, chunk ->
                    statusMessage.value = "Analiza części ${idx + 1}/${chunks.size}..."
                    val partRes = container.aiGateway.completeOnce(
                        model = model,
                        apiKey = key,
                        systemPrompt = systemPrompt,
                        messages = listOf(AiTurnMessage("user", "Polecenie: $userPrompt\n\nFragment ${idx + 1}/${chunks.size}:\n$chunk")),
                        temperature = temperature,
                        maxOutputTokens = 1200
                    )
                    partials.appendLine("### Fragment ${idx + 1}").appendLine(partRes.text).appendLine()
                }
                outputText.value = partials.toString()
                statusMessage.value = "Zakończono analizę ${chunks.size} fragmentów."
            } else {
                val combinedText = buildString {
                    append(userPrompt)
                    att?.extractedText?.let {
                        append("\n\n--- Dokument (${att.displayName}) ---\n")
                        append(it)
                    }
                }
                val res = container.aiGateway.completeOnce(
                    model = model,
                    apiKey = key,
                    systemPrompt = systemPrompt,
                    messages = listOf(
                        AiTurnMessage(
                            role = "user",
                            text = combinedText,
                            imageBase64 = if (requiresVision) att?.imageBase64 else null,
                            imageMimeType = if (requiresVision) att?.mimeType else null
                        )
                    ),
                    temperature = temperature,
                    maxOutputTokens = 2600
                )
                container.usageRepo.logUsage(
                    featureName = featureLabel,
                    provider = model.provider,
                    modelId = model.id,
                    inputTokens = res.inputTokens,
                    outputTokens = res.outputTokens,
                    estimatedCostUsd = res.estimatedCostUsd,
                    latencyMs = res.latencyMs
                )
                outputText.value = if (res.isError) (res.errorMessage ?: "Błąd API") else res.text
                statusMessage.value = "Model: ${model.displayName} • ${res.latencyMs} ms • ${CostEstimator.formatUsd(res.estimatedCostUsd)}"
            }
            isRunning.value = false
        }
    }

    fun savePromptTemplate(title: String, category: String, content: String) {
        if (title.isBlank() || content.isBlank()) return
        viewModelScope.launch {
            container.characterAndPromptRepo.savePrompt(
                PromptTemplateEntity(
                    title = title.trim(),
                    category = category.ifBlank { "Ogólne" },
                    content = content.trim()
                )
            )
            statusMessage.value = "Zapisano szablon promptu."
        }
    }

    fun deletePromptTemplate(template: PromptTemplateEntity) {
        viewModelScope.launch { container.characterAndPromptRepo.deletePrompt(template) }
    }

    fun exportBackup(uri: Uri) {
        viewModelScope.launch {
            container.backupManager.exportToUri(uri)
                .onSuccess { statusMessage.value = it }
                .onFailure { statusMessage.value = "Błąd eksportu: ${it.localizedMessage}" }
        }
    }

    fun importBackup(uri: Uri) {
        viewModelScope.launch {
            container.backupManager.importFromUri(uri)
                .onSuccess { statusMessage.value = it }
                .onFailure { statusMessage.value = "Błąd importu: ${it.localizedMessage}" }
        }
    }
}
