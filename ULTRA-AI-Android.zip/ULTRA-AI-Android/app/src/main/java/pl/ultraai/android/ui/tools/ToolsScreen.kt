package pl.ultraai.android.ui.tools

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.UploadFile
import androidx.compose.material.icons.outlined.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import pl.ultraai.android.core.pricing.CostEstimator
import pl.ultraai.android.core.speech.SpeechAndTtsManager
import pl.ultraai.android.ui.components.MarkdownText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ToolsScreen(
    viewModel: ToolsViewModel,
    speechManager: SpeechAndTtsManager
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current

    val docPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.attachDocumentOrImage(context, uri)
    }
    val backupExportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) viewModel.exportBackup(uri)
    }
    val backupImportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) viewModel.importBackup(uri)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    if (state.activeTool != null) {
                        IconButton(onClick = { viewModel.openTool(null) }) {
                            Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Powrót")
                        }
                    }
                },
                title = { Text(state.activeTool?.titlePl ?: "Narzędzia ULTRA AI") }
            )
        }
    ) { padding ->
        if (state.activeTool == null) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item { Spacer(modifier = Modifier.height(4.dp)) }
                items(UltraToolType.entries) { tool ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.openTool(tool) }
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Build, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(tool.titlePl, fontWeight = FontWeight.Bold)
                                Text(
                                    text = tool.subtitlePl,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                when (state.activeTool) {
                    UltraToolType.RESEARCH -> ToolPromptRunner(
                        label = "Temat lub pytanie badawcze",
                        buttonText = "Rozpocznij AI Research",
                        isRunning = state.isRunning,
                        onRun = { input ->
                            viewModel.runToolPrompt(
                                featureLabel = "AI Research",
                                systemPrompt = "Jesteś analitykiem badawczym. Opracuj temat w strukturze: 1) Streszczenie, 2) Kluczowe fakty i mechanizmy, 3) Ryzyka i ograniczenia, 4) Lista kontrolna dalszej weryfikacji.",
                                userPrompt = input,
                                temperature = 0.35f
                            )
                        }
                    )

                    UltraToolType.CODE_STUDIO -> {
                        var lang by remember { mutableStateOf("Kotlin") }
                        var taskType by remember { mutableStateOf("Napisz kod") }
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Kotlin", "Python", "TypeScript", "SQL", "C++").forEach { l ->
                                FilterChip(selected = lang == l, onClick = { lang = l }, label = { Text(l) })
                            }
                        }
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Napisz kod", "Debuguj błąd", "Refaktoryzuj", "Napisz testy").forEach { t ->
                                FilterChip(selected = taskType == t, onClick = { taskType = t }, label = { Text(t) })
                            }
                        }
                        ToolPromptRunner(
                            label = "Specyfikacja lub kod źródłowy ($lang)",
                            buttonText = "Uruchom Code Studio",
                            isRunning = state.isRunning,
                            onRun = { input ->
                                viewModel.runToolPrompt(
                                    featureLabel = "AI Code Studio",
                                    systemPrompt = "Jesteś starszym inżynierem $lang. Zadanie: $taskType. Podaj kompletny, bezpieczny kod w blokach Markdown i krótkie uzasadnienie architektoniczne.",
                                    userPrompt = input,
                                    temperature = 0.25f
                                )
                            }
                        )
                    }

                    UltraToolType.WRITER -> {
                        var style by remember { mutableStateOf("Artykuł ekspercki") }
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Artykuł ekspercki", "E-mail biznesowy", "Post social", "Scenariusz wideo").forEach { s ->
                                FilterChip(selected = style == s, onClick = { style = s }, label = { Text(s) })
                            }
                        }
                        ToolPromptRunner(
                            label = "Temat, odbiorca i kluczowe punkty",
                            buttonText = "Generuj tekst ($style)",
                            isRunning = state.isRunning,
                            onRun = { input ->
                                viewModel.runToolPrompt(
                                    featureLabel = "AI Writer",
                                    systemPrompt = "Jesteś profesjonalnym redaktorem. Napisz treść w formacie: $style. Zadbaj o naturalny polski styl, wyraźną strukturę i brak pustych frazesów.",
                                    userPrompt = input,
                                    temperature = 0.75f
                                )
                            }
                        )
                    }

                    UltraToolType.TRANSLATOR -> {
                        var targetLang by remember { mutableStateOf("Angielski (biznesowy)") }
                        Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf("Angielski (biznesowy)", "Polski", "Niemiecki", "Hiszpański", "Francuski").forEach { l ->
                                FilterChip(selected = targetLang == l, onClick = { targetLang = l }, label = { Text(l) })
                            }
                        }
                        ToolPromptRunner(
                            label = "Tekst do przetłumaczenia",
                            buttonText = "Przetłumacz na $targetLang",
                            isRunning = state.isRunning,
                            onRun = { input ->
                                viewModel.runToolPrompt(
                                    featureLabel = "AI Translator",
                                    systemPrompt = "Przetłumacz tekst precyzyjnie na język: $targetLang. Zachowaj kontekst, idiomy i ton wypowiedzi.",
                                    userPrompt = input,
                                    temperature = 0.25f
                                )
                            }
                        )
                    }

                    UltraToolType.TUTOR -> ToolPromptRunner(
                        label = "Czego chcesz się dziś nauczyć?",
                        buttonText = "Rozpocznij lekcję AI Tutor",
                        isRunning = state.isRunning,
                        onRun = { input ->
                            viewModel.runToolPrompt(
                                featureLabel = "AI Tutor",
                                systemPrompt = "Jesteś nauczycielem AI Tutor. Wyjaśnij zagadnienie od podstaw do poziomu zaawansowanego, podaj przykład praktyczny oraz 3 pytania kontrolne.",
                                userPrompt = input,
                                temperature = 0.55f
                            )
                        }
                    )

                    UltraToolType.PROMPT_GENERATOR -> {
                        var title by remember { mutableStateOf("") }
                        var cat by remember { mutableStateOf("Produktywność") }
                        var content by remember { mutableStateOf("") }

                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Tytuł szablonu") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = cat, onValueChange = { cat = it }, label = { Text("Kategoria") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Cel lub treść promptu") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { viewModel.savePromptTemplate(title, cat, content) }, modifier = Modifier.weight(1f)) {
                                Text("Zapisz w bibliotece")
                            }
                            OutlinedButton(
                                onClick = {
                                    viewModel.runToolPrompt(
                                        featureLabel = "Generator Promptów",
                                        systemPrompt = "Przekształć opis celu w profesjonalny prompt systemowy z rolą, formatem wyjściowym i ograniczeniami.",
                                        userPrompt = content.ifBlank { title }
                                    )
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Optymalizuj AI")
                            }
                        }

                        HorizontalDivider()
                        Text("Biblioteka promptów (${state.prompts.size}):", fontWeight = FontWeight.Bold)
                        state.prompts.forEach { p ->
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = MaterialTheme.colorScheme.surface,
                                tonalElevation = 1.dp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${p.title} • ${p.category}", fontWeight = FontWeight.SemiBold)
                                        Text(p.content.take(120), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(onClick = { clipboard.setText(AnnotatedString(p.content)) }) {
                                        Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopiuj")
                                    }
                                    IconButton(onClick = { viewModel.deletePromptTemplate(p) }) {
                                        Icon(Icons.Outlined.Delete, contentDescription = "Usuń")
                                    }
                                }
                            }
                        }
                    }

                    UltraToolType.DOC_ANALYZER -> {
                        OutlinedButton(
                            onClick = { docPicker.launch(arrayOf("application/pdf", "text/*", "application/vnd.openxmlformats-officedocument.wordprocessingml.document")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Outlined.UploadFile, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(state.attachment?.displayName ?: "Wybierz plik PDF / TXT / DOCX")
                        }
                        ToolPromptRunner(
                            label = "Pytanie lub instrukcja do dokumentu",
                            buttonText = "Analizuj dokument",
                            isRunning = state.isRunning,
                            onRun = { input ->
                                viewModel.runToolPrompt(
                                    featureLabel = "Analiza PDF/TXT",
                                    systemPrompt = "Przeanalizuj dokładnie załączoną treść dokumentu i odpowiedz na polecenie użytkownika po polsku.",
                                    userPrompt = input,
                                    temperature = 0.2f
                                )
                            }
                        )
                    }

                    UltraToolType.VISION -> {
                        OutlinedButton(
                            onClick = { docPicker.launch(arrayOf("image/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Outlined.UploadFile, contentDescription = null)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(state.attachment?.displayName ?: "Wybierz obraz z urządzenia")
                        }
                        ToolPromptRunner(
                            label = "Co AI ma rozpoznać lub opisać na obrazie?",
                            buttonText = "Analizuj obraz",
                            isRunning = state.isRunning,
                            onRun = { input ->
                                viewModel.runToolPrompt(
                                    featureLabel = "Rozpoznawanie obrazów",
                                    systemPrompt = "Opisz i przeanalizuj obraz szczegółowo po polsku, uwzględniając tekst, obiekty i kontekst.",
                                    userPrompt = input.ifBlank { "Opisz dokładnie co znajduje się na tym obrazie." },
                                    requiresVision = true,
                                    temperature = 0.3f
                                )
                            }
                        )
                    }

                    UltraToolType.STATS_COSTS -> {
                        val totalIn = state.usageLogs.sumOf { it.inputTokens }
                        val totalOut = state.usageLogs.sumOf { it.outputTokens }
                        val totalCost = state.usageLogs.mapNotNull { it.estimatedCostUsd }.sum()
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surface,
                            tonalElevation = 1.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Podsumowanie użycia", fontWeight = FontWeight.Bold)
                                Text("Liczba zapytań: ${state.usageLogs.size}")
                                Text("Tokeny wejściowe: $totalIn • Wyjściowe: $totalOut")
                                Text("Szacowany koszt całkowity: ${CostEstimator.formatUsd(totalCost)}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                        }
                        Text("Historia operacji:", fontWeight = FontWeight.Bold)
                        state.usageLogs.take(40).forEach { log ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("${log.featureName} (${log.modelId})", modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                                Text(
                                    text = "${log.inputTokens + log.outputTokens} tok. • ${CostEstimator.formatUsd(log.estimatedCostUsd)}",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            HorizontalDivider()
                        }
                    }

                    UltraToolType.BACKUP -> {
                        Text(
                            text = "Eksportuj rozmowy, foldery, postacie, prompty i historię kosztów do jednego pliku JSON. Ze względów bezpieczeństwa zaszyfrowane klucze API nie są dołączane do pliku.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        Button(
                            onClick = { backupExportLauncher.launch("ultra_ai_kopia_${System.currentTimeMillis()}.json") },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Eksportuj dane (JSON)")
                        }
                        OutlinedButton(
                            onClick = { backupImportLauncher.launch(arrayOf("application/json", "*/*")) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Importuj dane z kopii JSON")
                        }
                    }

                    null -> Unit
                }

                if (state.isRunning) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }
                state.statusMessage?.let {
                    Text(it, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                }
                if (state.outputText.isNotBlank()) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                IconButton(onClick = { speechManager.speak(state.outputText) }) {
                                    Icon(Icons.Outlined.VolumeUp, contentDescription = "Czytaj na głos")
                                }
                                IconButton(onClick = { clipboard.setText(AnnotatedString(state.outputText)) }) {
                                    Icon(Icons.Outlined.ContentCopy, contentDescription = "Kopiuj")
                                }
                            }
                            MarkdownText(markdown = state.outputText)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ToolPromptRunner(
    label: String,
    buttonText: String,
    isRunning: Boolean,
    onRun: (String) -> Unit
) {
    var input by remember { mutableStateOf("") }
    OutlinedTextField(
        value = input,
        onValueChange = { input = it },
        label = { Text(label) },
        minLines = 3,
        maxLines = 8,
        modifier = Modifier.fillMaxWidth()
    )
    Button(
        onClick = { onRun(input) },
        enabled = !isRunning,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(if (isRunning) "Przetwarzanie..." else buttonText)
    }
}
