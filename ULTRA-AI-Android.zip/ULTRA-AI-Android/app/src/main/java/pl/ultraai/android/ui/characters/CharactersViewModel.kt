package pl.ultraai.android.ui.characters

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pl.ultraai.android.AppContainer
import pl.ultraai.android.data.local.entity.AiCharacterEntity
import pl.ultraai.android.data.local.entity.ChatSessionEntity
import pl.ultraai.android.data.remote.AiTurnMessage
import pl.ultraai.android.domain.model.AiModelInfo

data class CharactersUiState(
    val characters: List<AiCharacterEntity> = emptyList(),
    val availableModels: List<AiModelInfo> = emptyList(),
    val selectedCharacterForHistory: AiCharacterEntity? = null,
    val characterSessions: List<ChatSessionEntity> = emptyList(),
    val isSummarizingMemory: Boolean = false
)

class CharactersViewModel(private val container: AppContainer) : ViewModel() {

    private val selectedCharId = MutableStateFlow<Long?>(null)
    private val isSummarizing = MutableStateFlow(false)

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val charSessionsFlow = selectedCharId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else container.chatRepo.observeCharacterSessions(id)
    }

    val uiState: StateFlow<CharactersUiState> = combine(
        container.characterAndPromptRepo.observeCharacters(),
        container.apiKeyAndModelRepo.discoveredModels,
        selectedCharId,
        charSessionsFlow,
        isSummarizing
    ) { chars, models, selId, sessions, summarizing ->
        CharactersUiState(
            characters = chars,
            availableModels = models,
            selectedCharacterForHistory = chars.firstOrNull { it.id == selId },
            characterSessions = sessions,
            isSummarizingMemory = summarizing
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), CharactersUiState())

    fun saveCharacter(character: AiCharacterEntity) {
        viewModelScope.launch { container.characterAndPromptRepo.saveCharacter(character) }
    }

    fun duplicateCharacter(character: AiCharacterEntity) {
        viewModelScope.launch { container.characterAndPromptRepo.duplicateCharacter(character) }
    }

    fun deleteCharacter(character: AiCharacterEntity) {
        viewModelScope.launch { container.characterAndPromptRepo.deleteCharacter(character) }
    }

    fun inspectHistory(character: AiCharacterEntity?) {
        selectedCharId.value = character?.id
    }

    fun updateMemoryFromHistory(character: AiCharacterEntity) {
        val model = uiState.value.availableModels.firstOrNull { it.id == character.preferredModelId }
            ?: uiState.value.availableModels.firstOrNull()
            ?: return
        viewModelScope.launch {
            isSummarizing.value = true
            val key = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider).orEmpty()
            val sessions = uiState.value.characterSessions.take(5)
            val transcript = buildString {
                for (s in sessions) {
                    val msgs = container.chatRepo.getMessagesOnce(s.id).takeLast(12)
                    msgs.forEach { appendLine("${it.role}: ${it.content.take(400)}") }
                }
            }
            if (transcript.isNotBlank()) {
                val res = container.aiGateway.completeOnce(
                    model = model,
                    apiKey = key,
                    systemPrompt = "Wypisz w maksymalnie 6 krótkich punktach po polsku najważniejsze fakty o użytkowniku i ustaleniach z rozmów, które postać powinna zapamiętać.",
                    messages = listOf(AiTurnMessage("user", "Obecna pamięć:\n${character.memorySummary}\n\nNowe rozmowy:\n$transcript")),
                    temperature = 0.2f,
                    maxOutputTokens = 400
                )
                if (!res.isError && res.text.isNotBlank()) {
                    container.characterAndPromptRepo.saveCharacter(character.copy(memorySummary = res.text.trim()))
                }
            }
            isSummarizing.value = false
        }
    }
}
