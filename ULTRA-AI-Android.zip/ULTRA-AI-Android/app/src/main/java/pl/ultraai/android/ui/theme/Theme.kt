package pl.ultraai.android.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import pl.ultraai.android.domain.model.ThemePreset

@Composable
fun UltraAiTheme(
    darkTheme: Boolean = true,
    themePreset: ThemePreset = ThemePreset.OBSIDIAN,
    accentColorHex: Long = 0xFF3B82F6,
    fontScale: Float = 1.0f,
    content: @Composable () -> Unit
) {
    val accent = Color(accentColorHex)

    val (bgDark, surfDark, surfVarDark) = when (themePreset) {
        ThemePreset.OBSIDIAN -> Triple(Color(0xFF090C12), Color(0xFF111622), Color(0xFF1A2233))
        ThemePreset.COBALT -> Triple(Color(0xFF060D1A), Color(0xFF0E182B), Color(0xFF16243D))
        ThemePreset.EMERALD -> Triple(Color(0xFF07120E), Color(0xFF0E1F18), Color(0xFF162E24))
        ThemePreset.GRAPHITE -> Triple(Color(0xFF101114), Color(0xFF191B20), Color(0xFF23262E))
    }

    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = accent,
            onPrimary = Color.White,
            primaryContainer = accent.copy(alpha = 0.22f),
            onPrimaryContainer = Color(0xFFE2E8F0),
            secondary = Color(0xFF38BDF8),
            onSecondary = Color(0xFF082F49),
            tertiary = Color(0xFF10B981),
            background = bgDark,
            onBackground = Color(0xFFF1F5F9),
            surface = surfDark,
            onSurface = Color(0xFFF1F5F9),
            surfaceVariant = surfVarDark,
            onSurfaceVariant = Color(0xFF94A3B8),
            outline = Color(0xFF283247),
            error = Color(0xFFEF4444),
            onError = Color.White
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = Color.White,
            primaryContainer = accent.copy(alpha = 0.14f),
            onPrimaryContainer = Color(0xFF0F172A),
            secondary = Color(0xFF0284C7),
            onSecondary = Color.White,
            tertiary = Color(0xFF059669),
            background = Color(0xFFF8FAFC),
            onBackground = Color(0xFF0F172A),
            surface = Color.White,
            onSurface = Color(0xFF0F172A),
            surfaceVariant = Color(0xFFE2E8F0),
            onSurfaceVariant = Color(0xFF475569),
            outline = Color(0xFFCBD5E1),
            error = Color(0xFFDC2626),
            onError = Color.White
        )
    }

    val scaledTypography = Typography(
        headlineMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Bold,
            fontSize = (24 * fontScale).sp,
            lineHeight = (30 * fontScale).sp
        ),
        titleLarge = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.SemiBold,
            fontSize = (20 * fontScale).sp,
            lineHeight = (26 * fontScale).sp
        ),
        titleMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.SemiBold,
            fontSize = (16 * fontScale).sp,
            lineHeight = (22 * fontScale).sp
        ),
        bodyLarge = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Normal,
            fontSize = (15 * fontScale).sp,
            lineHeight = (22 * fontScale).sp
        ),
        bodyMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Normal,
            fontSize = (14 * fontScale).sp,
            lineHeight = (20 * fontScale).sp
        ),
        labelMedium = TextStyle(
            fontFamily = FontFamily.SansSerif,
            fontWeight = FontWeight.Medium,
            fontSize = (12 * fontScale).sp
        )
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = scaledTypography,
        content = content
    )
}
