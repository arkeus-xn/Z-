package pl.ultraai.android.core.security

import java.security.MessageDigest
import java.security.SecureRandom
import android.util.Base64

object PinSecurityHelper {

    fun hashPin(pin: String): String {
        val salt = ByteArray(16)
        SecureRandom().nextBytes(salt)
        val saltB64 = Base64.encodeToString(salt, Base64.NO_WRAP)
        val digest = sha256("$saltB64:$pin")
        return "$saltB64:$digest"
    }

    fun verifyPin(pin: String, storedHash: String): Boolean {
        val parts = storedHash.split(":")
        if (parts.size != 2) return false
        val saltB64 = parts[0]
        val expected = parts[1]
        val actual = sha256("$saltB64:$pin")
        return MessageDigest.isEqual(actual.toByteArray(), expected.toByteArray())
    }

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

object SecurityNotices {
    const val KEYSTORE_LIMITATIONS_PL: String =
        "Ważna informacja o bezpieczeństwie kluczy API:\n" +
        "• Klucze są szyfrowane lokalnie algorytmem AES-256-GCM z użyciem Android Keystore.\n" +
        "• Aplikacja komunikuje się bezpośrednio z serwerami Google Gemini i Groq — bez serwera pośredniczącego.\n" +
        "• Przechowywanie klucza na urządzeniu użytkownika nie gwarantuje 100% odporności przed atakami na zrootowanym telefonie, zrzutem pamięci RAM w trakcie działania aplikacji ani przy przejęciu odblokowanego urządzenia.\n" +
        "• Zalecamy ustawienie niskich limitów wydatków (budget caps) bezpośrednio w panelu Google AI Studio oraz Groq Console, włączenie blokady PIN/biometrii w aplikacji i regularne rotowanie kluczy."
}
