package pl.ultraai.android.core.pricing

import pl.ultraai.android.domain.model.AiModelInfo
import pl.ultraai.android.domain.model.AiProvider
import pl.ultraai.android.domain.model.CostEstimate
import pl.ultraai.android.domain.model.ModelCapability
import pl.ultraai.android.domain.model.SelectionMode
import java.util.Locale
import kotlin.math.ceil

data class VerifiedPricingMetadata(
    val inputPricePer1MUsd: Double?,
    val outputPricePer1MUsd: Double?,
    val freeTierInfo: String,
    val speedTier: Int,
    val qualityTier: Int,
    val extraCapabilities: Set<ModelCapability> = emptySet(),
    val defaultContextLimit: Int? = null
)

/**
 * Rejestr zweryfikowanych stawek dla oficjalnych identyfikatorów modeli.
 * Jeśli model zwrócony przez API nie znajduje się w zweryfikowanym cenniku,
 * pola cenowe pozostają null, a interfejs wyświetla „Brak danych”.
 */
object ModelPricingRegistry {

    private val knownGeminiPricing: Map<String, VerifiedPricingMetadata> = mapOf(
        "gemini-2.5-flash" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 0.15,
            outputPricePer1MUsd = 0.60,
            freeTierInfo = "Darmowy limit w AI Studio (z ograniczeniami RPM/RPD)",
            speedTier = 3,
            qualityTier = 3,
            extraCapabilities = setOf(ModelCapability.VISION, ModelCapability.CODE, ModelCapability.REASONING, ModelCapability.LONG_CONTEXT),
            defaultContextLimit = 1_048_576
        ),
        "gemini-2.5-flash-lite" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 0.10,
            outputPricePer1MUsd = 0.40,
            freeTierInfo = "Darmowy limit w AI Studio (z ograniczeniami RPM/RPD)",
            speedTier = 3,
            qualityTier = 2,
            extraCapabilities = setOf(ModelCapability.VISION, ModelCapability.CODE, ModelCapability.LONG_CONTEXT),
            defaultContextLimit = 1_048_576
        ),
        "gemini-2.5-pro" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 1.25,
            outputPricePer1MUsd = 10.00,
            freeTierInfo = "Ograniczony darmowy dostęp lub płatne API",
            speedTier = 1,
            qualityTier = 3,
            extraCapabilities = setOf(ModelCapability.VISION, ModelCapability.CODE, ModelCapability.REASONING, ModelCapability.LONG_CONTEXT),
            defaultContextLimit = 1_048_576
        ),
        "gemini-2.0-flash" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 0.10,
            outputPricePer1MUsd = 0.40,
            freeTierInfo = "Darmowy limit w AI Studio (RPM/TPM wg planu)",
            speedTier = 3,
            qualityTier = 2,
            extraCapabilities = setOf(ModelCapability.VISION, ModelCapability.CODE, ModelCapability.LONG_CONTEXT),
            defaultContextLimit = 1_048_576
        ),
        "gemini-2.0-flash-lite" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 0.075,
            outputPricePer1MUsd = 0.30,
            freeTierInfo = "Darmowy limit w AI Studio",
            speedTier = 3,
            qualityTier = 1,
            extraCapabilities = setOf(ModelCapability.VISION, ModelCapability.LONG_CONTEXT),
            defaultContextLimit = 1_048_576
        ),
        "gemini-1.5-flash" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 0.075,
            outputPricePer1MUsd = 0.30,
            freeTierInfo = "Darmowy limit w AI Studio",
            speedTier = 3,
            qualityTier = 2,
            extraCapabilities = setOf(ModelCapability.VISION, ModelCapability.LONG_CONTEXT),
            defaultContextLimit = 1_048_576
        ),
        "gemini-1.5-pro" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 1.25,
            outputPricePer1MUsd = 5.00,
            freeTierInfo = "Darmowy limit w AI Studio (niski RPM)",
            speedTier = 1,
            qualityTier = 3,
            extraCapabilities = setOf(ModelCapability.VISION, ModelCapability.CODE, ModelCapability.REASONING, ModelCapability.LONG_CONTEXT),
            defaultContextLimit = 2_097_152
        )
    )

    private val knownGroqPricing: Map<String, VerifiedPricingMetadata> = mapOf(
        "llama-3.3-70b-versatile" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 0.59,
            outputPricePer1MUsd = 0.79,
            freeTierInfo = "Dostępny darmowy plan Groq (z limitami RPM/TPM/TPD)",
            speedTier = 3,
            qualityTier = 3,
            extraCapabilities = setOf(ModelCapability.CODE, ModelCapability.REASONING)
        ),
        "llama-3.1-8b-instant" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 0.05,
            outputPricePer1MUsd = 0.08,
            freeTierInfo = "Dostępny darmowy plan Groq (wysoki limit RPM)",
            speedTier = 3,
            qualityTier = 1,
            extraCapabilities = setOf(ModelCapability.CODE)
        ),
        "gemma2-9b-it" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 0.20,
            outputPricePer1MUsd = 0.20,
            freeTierInfo = "Dostępny darmowy plan Groq",
            speedTier = 3,
            qualityTier = 2
        ),
        "mixtral-8x7b-32768" to VerifiedPricingMetadata(
            inputPricePer1MUsd = 0.24,
            outputPricePer1MUsd = 0.24,
            freeTierInfo = "Dostępny darmowy plan Groq",
            speedTier = 3,
            qualityTier = 2
        )
    )

    fun lookupMetadata(provider: AiProvider, rawModelId: String): VerifiedPricingMetadata? {
        val cleanId = rawModelId.removePrefix("models/").lowercase(Locale.ROOT)
        return when (provider) {
            AiProvider.GEMINI -> knownGeminiPricing[cleanId]
                ?: knownGeminiPricing.entries.firstOrNull { cleanId.startsWith(it.key) }?.value
            AiProvider.GROQ -> knownGroqPricing[cleanId]
        }
    }

    fun formatPricePer1M(price: Double?): String {
        return if (price == null) {
            "Brak danych"
        } else {
            String.format(Locale.US, "$%.3f / 1M", price)
        }
    }
}

object CostEstimator {

    fun estimateTokens(text: String): Int {
        if (text.isBlank()) return 0
        return ceil(text.length / 3.6).toInt().coerceAtLeast(1)
    }

    fun calculateExactCost(
        model: AiModelInfo?,
        inputTokens: Int,
        outputTokens: Int
    ): Double? {
        val inPrice = model?.inputPricePer1MUsd ?: return null
        val outPrice = model.outputPricePer1MUsd ?: return null
        return (inputTokens / 1_000_000.0) * inPrice + (outputTokens / 1_000_000.0) * outPrice
    }

    fun formatUsd(cost: Double?): String {
        if (cost == null) return "Brak danych"
        return when {
            cost == 0.0 -> "$0.0000"
            cost < 0.0001 -> "<$0.0001"
            else -> String.format(Locale.US, "$%.4f", cost)
        }
    }

    fun preflightEstimate(
        model: AiModelInfo?,
        promptText: String,
        expectedOutputTokens: Int,
        thresholdUsd: Double,
        todaySpentUsd: Double,
        dailyLimitUsd: Double
    ): CostEstimate {
        val inputTokens = estimateTokens(promptText)
        val estCost = calculateExactCost(model, inputTokens, expectedOutputTokens)
        val exceedsThreshold = estCost != null && estCost >= thresholdUsd
        val exceedsDaily = estCost != null && (todaySpentUsd + estCost) > dailyLimitUsd
        val warning = when {
            exceedsDaily -> "Szacowany koszt przekroczy dzienny limit wydatków ($${String.format(Locale.US, "%.2f", dailyLimitUsd)})."
            exceedsThreshold -> "Operacja o podwyższonym koszcie szacunkowym (${formatUsd(estCost)})."
            model != null && model.inputContextLimit != null && inputTokens > model.inputContextLimit ->
                "Tekst przekracza okno kontekstowe modelu (${model.inputContextLimit} tokenów)."
            else -> null
        }
        return CostEstimate(
            estimatedInputTokens = inputTokens,
            estimatedOutputTokens = expectedOutputTokens,
            estimatedCostUsd = estCost,
            formattedCost = formatUsd(estCost),
            exceedsThreshold = exceedsThreshold,
            exceedsDailyLimit = exceedsDaily,
            warningMessage = warning
        )
    }
}

object ModelSelector {

    data class SelectionCriteria(
        val mode: SelectionMode,
        val preferredModelId: String?,
        val promptText: String,
        val requiresVision: Boolean = false,
        val requiresCodeOrReasoning: Boolean = false
    )

    fun selectModel(
        availableModels: List<AiModelInfo>,
        criteria: SelectionCriteria
    ): AiModelInfo? {
        if (availableModels.isEmpty()) return null
        val estimatedInputTokens = CostEstimator.estimateTokens(criteria.promptText)

        // Odfiltruj modele niedostępne i nieobsługujące wymaganych możliwości / rozmiaru kontekstu
        val eligible = availableModels.filter { model ->
            model.isAvailable &&
                (!criteria.requiresVision || ModelCapability.VISION in model.capabilities) &&
                (model.inputContextLimit == null || model.inputContextLimit >= estimatedInputTokens + 512)
        }.ifEmpty { availableModels.filter { it.isAvailable }.ifEmpty { availableModels } }

        return when (criteria.mode) {
            SelectionMode.MANUAL -> {
                eligible.firstOrNull { it.id == criteria.preferredModelId }
                    ?: eligible.firstOrNull()
            }

            SelectionMode.CHEAPEST -> {
                eligible.sortedWith(
                    compareBy<AiModelInfo>(
                        { if (it.hasVerifiedPricing) 0 else 1 },
                        { (it.inputPricePer1MUsd ?: Double.MAX_VALUE) + (it.outputPricePer1MUsd ?: Double.MAX_VALUE) },
                        { -it.speedTier }
                    )
                ).firstOrNull()
            }

            SelectionMode.BEST_QUALITY -> {
                eligible.sortedWith(
                    compareByDescending<AiModelInfo> { it.qualityTier }
                        .thenByDescending { if (criteria.requiresCodeOrReasoning && ModelCapability.REASONING in it.capabilities) 1 else 0 }
                        .thenByDescending { it.inputContextLimit ?: 0 }
                ).firstOrNull()
            }

            SelectionMode.FASTEST -> {
                eligible.sortedWith(
                    compareByDescending<AiModelInfo> { it.speedTier }
                        .thenByDescending { if (it.provider == AiProvider.GROQ) 1 else 0 }
                        .thenBy { it.inputPricePer1MUsd ?: Double.MAX_VALUE }
                ).firstOrNull()
            }

            SelectionMode.AUTO -> {
                val isComplex = criteria.requiresCodeOrReasoning ||
                    estimatedInputTokens > 2500 ||
                    detectComplexIntent(criteria.promptText)
                if (isComplex) {
                    eligible.sortedWith(
                        compareByDescending<AiModelInfo> { it.qualityTier }
                            .thenByDescending { it.speedTier }
                            .thenBy { it.outputPricePer1MUsd ?: 999.0 }
                    ).firstOrNull()
                } else {
                    eligible.sortedWith(
                        compareByDescending<AiModelInfo> { it.speedTier }
                            .thenBy { it.outputPricePer1MUsd ?: 999.0 }
                            .thenByDescending { it.qualityTier }
                    ).firstOrNull()
                }
            }
        }
    }

    private fun detectComplexIntent(prompt: String): Boolean {
        val lower = prompt.lowercase(Locale.ROOT)
        val keywords = listOf(
            "architektur", "algorytm", "zaprojektuj", "refaktoryz", "debug",
            "kotlin", "python", "sql", "analiz", "porównaj", "dowód", "matemat"
        )
        return keywords.any { lower.contains(it) }
    }
}
