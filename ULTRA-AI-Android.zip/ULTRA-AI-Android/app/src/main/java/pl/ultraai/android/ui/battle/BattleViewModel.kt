package pl.ultraai.android.ui.battle

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pl.ultraai.android.AppContainer
import pl.ultraai.android.core.pricing.CostEstimator
import pl.ultraai.android.data.remote.AiTurnMessage
import pl.ultraai.android.domain.model.AiModelInfo
import pl.ultraai.android.domain.model.CostEstimate

data class BattleParticipantResult(
    val model: AiModelInfo,
    val responseText: String,
    val latencyMs: Long,
    val inputTokens: Int,
    val outputTokens: Int,
    val estimatedCostUsd: Double?,
    val isError: Boolean = false,
    val userVotes: Int = 0
)

data class BattleUiState(
    val availableModels: List<AiModelInfo> = emptyList(),
    val selectedContestantIds: Set<String> = emptySet(),
    val judgeModelId: String? = null,
    val prompt: String = "",
    val isRunning: Boolean = false,
    val isJudging: Boolean = false,
    val results: List<BattleParticipantResult> = emptyList(),
    val winnerModelId: String? = null,
    val judgeVerdict: String = "",
    val pendingCostEstimate: CostEstimate? = null,
    val error: String? = null
)

class BattleViewModel(private val container: AppContainer) : ViewModel() {

    private val selectedContestants = MutableStateFlow<Set<String>>(emptySet())
    private val judgeModelId = MutableStateFlow<String?>(null)
    private val prompt = MutableStateFlow("")
    private val isRunning = MutableStateFlow(false)
    private val isJudging = MutableStateFlow(false)
    private val results = MutableStateFlow<List<BattleParticipantResult>>(emptyList())
    private val winnerModelId = MutableStateFlow<String?>(null)
    private val judgeVerdict = MutableStateFlow("")
    private val pendingCostEstimate = MutableStateFlow<CostEstimate?>(null)
    private val error = MutableStateFlow<String?>(null)

    val uiState: StateFlow<BattleUiState> = combine(
        listOf<Flow<Any?>>(
            container.apiKeyAndModelRepo.discoveredModels,
            selectedContestants,
            judgeModelId,
            prompt,
            isRunning,
            isJudging,
            results,
            winnerModelId,
            judgeVerdict,
            pendingCostEstimate,
            error
        )
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        val models = arr[0] as List<AiModelInfo>
        @Suppress("UNCHECKED_CAST")
        val selected = arr[1] as Set<String>
        val effectiveSelected = if (selected.isEmpty() && models.size >= 2) {
            models.take(2).map { it.id }.toSet()
        } else {
            selected
        }
        val judge = (arr[2] as String?) ?: models.firstOrNull()?.id
        BattleUiState(
            availableModels = models,
            selectedContestantIds = effectiveSelected,
            judgeModelId = judge,
            prompt = arr[3] as String,
            isRunning = arr[4] as Boolean,
            isJudging = arr[5] as Boolean,
            results = arr[6] as List<BattleParticipantResult>,
            winnerModelId = arr[7] as String?,
            judgeVerdict = arr[8] as String,
            pendingCostEstimate = arr[9] as CostEstimate?,
            error = arr[10] as String?
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BattleUiState())

    fun updatePrompt(value: String) {
        prompt.value = value
    }

    fun toggleContestant(modelId: String) {
        val current = uiState.value.selectedContestantIds.toMutableSet()
        if (modelId in current) {
            current.remove(modelId)
        } else if (current.size < 5) {
            current.add(modelId)
        } else {
            error.value = "Możesz wybrać maksymalnie 5 modeli do jednej bitwy."
            return
        }
        selectedContestants.value = current
    }

    fun selectJudge(modelId: String) {
        judgeModelId.value = modelId
    }

    fun requestBattleStart() {
        val state = uiState.value
        if (state.prompt.isBlank()) {
            error.value = "Wpisz pytanie do porównania modeli."
            return
        }
        val contestants = state.availableModels.filter { it.id in state.selectedContestantIds }
        if (contestants.size < 2) {
            error.value = "Wybierz od 2 do 5 modeli (najpierw dodaj klucze API w Ustawieniach)."
            return
        }
        viewModelScope.launch {
            val todaySpent = container.usageRepo.getTodaySpentUsd()
            val combinedCost = contestants.mapNotNull {
                CostEstimator.calculateExactCost(it, CostEstimator.estimateTokens(state.prompt), 1500)
            }.sum()
            val est = CostEstimate(
                estimatedInputTokens = CostEstimator.estimateTokens(state.prompt) * contestants.size,
                estimatedOutputTokens = 1500 * contestants.size,
                estimatedCostUsd = if (contestants.any { it.hasVerifiedPricing }) combinedCost else null,
                formattedCost = if (contestants.any { it.hasVerifiedPricing }) CostEstimator.formatUsd(combinedCost) else "Brak danych",
                exceedsThreshold = combinedCost >= 0.01,
                exceedsDailyLimit = (todaySpent + combinedCost) > 2.0
            )
            if (est.exceedsThreshold) {
                pendingCostEstimate.value = est
            } else {
                executeBattle()
            }
        }
    }

    fun dismissCostDialog() {
        pendingCostEstimate.value = null
    }

    fun confirmAndExecuteBattle() {
        pendingCostEstimate.value = null
        executeBattle()
    }

    private fun executeBattle() {
        val state = uiState.value
        val contestants = state.availableModels.filter { it.id in state.selectedContestantIds }
        viewModelScope.launch {
            isRunning.value = true
            results.value = emptyList()
            winnerModelId.value = null
            judgeVerdict.value = ""
            error.value = null

            val list = coroutineScope {
                contestants.map { model ->
                    async {
                        val key = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider).orEmpty()
                        val res = container.aiGateway.completeOnce(
                            model = model,
                            apiKey = key,
                            systemPrompt = "Odpowiadaj precyzyjnie, rzetelnie i przejrzyście po polsku.",
                            messages = listOf(AiTurnMessage("user", state.prompt)),
                            temperature = 0.7f,
                            maxOutputTokens = 2048
                        )
                        container.usageRepo.logUsage(
                            featureName = "AI Battle",
                            provider = model.provider,
                            modelId = model.id,
                            inputTokens = res.inputTokens,
                            outputTokens = res.outputTokens,
                            estimatedCostUsd = res.estimatedCostUsd,
                            latencyMs = res.latencyMs
                        )
                        BattleParticipantResult(
                            model = model,
                            responseText = if (res.isError) (res.errorMessage ?: "Błąd modelu") else res.text,
                            latencyMs = res.latencyMs,
                            inputTokens = res.inputTokens,
                            outputTokens = res.outputTokens,
                            estimatedCostUsd = res.estimatedCostUsd,
                            isError = res.isError
                        )
                    }
                }.awaitAll()
            }
            results.value = list
            isRunning.value = false
        }
    }

    fun voteForModel(modelId: String) {
        winnerModelId.value = modelId
        results.value = results.value.map {
            if (it.model.id == modelId) it.copy(userVotes = it.userVotes + 1) else it
        }
    }

    fun runAiJudge() {
        val state = uiState.value
        val judge = state.availableModels.firstOrNull { it.id == state.judgeModelId } ?: return
        if (state.results.isEmpty()) return

        viewModelScope.launch {
            isJudging.value = true
            val key = container.apiKeyAndModelRepo.getDecryptedActiveKey(judge.provider).orEmpty()
            val dossier = buildString {
                appendLine("Pytanie użytkownika: ${state.prompt}")
                appendLine()
                state.results.forEachIndexed { idx, r ->
                    appendLine("=== KANDYDAT ${idx + 1}: ${r.model.displayName} (${r.latencyMs} ms, ${r.outputTokens} tok.) ===")
                    appendLine(r.responseText.take(4000))
                    appendLine()
                }
            }
            val verdict = container.aiGateway.completeOnce(
                model = judge,
                apiKey = key,
                systemPrompt = "Jesteś bezstronnym Sędzią AI. Porównaj odpowiedzi kandydatów pod kątem trafności, kompletności, poprawności merytorycznej i zwięzłości. Na końcu wskaż jednoznacznego zwycięzcę i uzasadnij wybór po polsku.",
                messages = listOf(AiTurnMessage("user", dossier)),
                temperature = 0.25f,
                maxOutputTokens = 1500
            )
            judgeVerdict.value = if (verdict.isError) {
                verdict.errorMessage ?: "Nie udało się uzyskać werdyktu Sędziego AI."
            } else {
                verdict.text
            }
            isJudging.value = false
        }
    }

    fun clearError() {
        error.value = null
    }
}
