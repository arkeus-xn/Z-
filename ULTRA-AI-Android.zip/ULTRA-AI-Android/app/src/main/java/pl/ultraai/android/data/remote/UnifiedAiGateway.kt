package pl.ultraai.android.data.remote

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import pl.ultraai.android.core.pricing.CostEstimator
import pl.ultraai.android.domain.model.AiModelInfo
import pl.ultraai.android.domain.model.AiProvider

data class AiCompletionResult(
    val text: String,
    val inputTokens: Int,
    val outputTokens: Int,
    val estimatedCostUsd: Double?,
    val latencyMs: Long,
    val isError: Boolean = false,
    val errorMessage: String? = null
)

class UnifiedAiGateway(
    private val geminiClient: GeminiApiClient,
    private val groqClient: GroqApiClient
) {
    suspend fun testAndFetchModels(provider: AiProvider, apiKey: String): ConnectionTestResult {
        return when (provider) {
            AiProvider.GEMINI -> geminiClient.fetchModels(apiKey)
            AiProvider.GROQ -> groqClient.fetchModels(apiKey)
        }
    }

    fun streamChat(
        provider: AiProvider,
        apiKey: String,
        modelId: String,
        systemPrompt: String,
        messages: List<AiTurnMessage>,
        temperature: Float,
        maxOutputTokens: Int
    ): Flow<AiStreamEvent> {
        if (apiKey.isBlank()) {
            return flow {
                emit(AiStreamEvent.Error("Brak aktywnego klucza API dla dostawcy ${provider.displayName}. Dodaj klucz w Ustawieniach."))
            }
        }
        return when (provider) {
            AiProvider.GEMINI -> geminiClient.streamGenerateContent(
                apiKey = apiKey,
                modelId = modelId,
                systemPrompt = systemPrompt,
                messages = messages,
                temperature = temperature,
                maxOutputTokens = maxOutputTokens
            )
            AiProvider.GROQ -> groqClient.streamChatCompletion(
                apiKey = apiKey,
                modelId = modelId,
                systemPrompt = systemPrompt,
                messages = messages,
                temperature = temperature,
                maxTokens = maxOutputTokens
            )
        }
    }

    suspend fun completeOnce(
        model: AiModelInfo,
        apiKey: String,
        systemPrompt: String,
        messages: List<AiTurnMessage>,
        temperature: Float = 0.7f,
        maxOutputTokens: Int = 2048
    ): AiCompletionResult {
        var finalText = StringBuilder()
        var inTok = 0
        var outTok = 0
        var latency = 0L
        var errMsg: String? = null

        streamChat(
            provider = model.provider,
            apiKey = apiKey,
            modelId = model.id,
            systemPrompt = systemPrompt,
            messages = messages,
            temperature = temperature,
            maxOutputTokens = maxOutputTokens
        ).collect { event ->
            when (event) {
                is AiStreamEvent.Delta -> finalText.append(event.text)
                is AiStreamEvent.Completed -> {
                    if (finalText.isEmpty()) finalText.append(event.fullText)
                    inTok = if (event.inputTokens > 0) event.inputTokens else CostEstimator.estimateTokens(
                        systemPrompt + messages.joinToString("\n") { it.text }
                    )
                    outTok = if (event.outputTokens > 0) event.outputTokens else CostEstimator.estimateTokens(finalText.toString())
                    latency = event.latencyMs
                }
                is AiStreamEvent.Error -> {
                    errMsg = event.message
                }
            }
        }

        return if (errMsg != null && finalText.isEmpty()) {
            AiCompletionResult(
                text = "",
                inputTokens = 0,
                outputTokens = 0,
                estimatedCostUsd = null,
                latencyMs = latency,
                isError = true,
                errorMessage = errMsg
            )
        } else {
            val cost = CostEstimator.calculateExactCost(model, inTok, outTok)
            AiCompletionResult(
                text = finalText.toString(),
                inputTokens = inTok,
                outputTokens = outTok,
                estimatedCostUsd = cost,
                latencyMs = latency,
                isError = errMsg != null,
                errorMessage = errMsg
            )
        }
    }
}
