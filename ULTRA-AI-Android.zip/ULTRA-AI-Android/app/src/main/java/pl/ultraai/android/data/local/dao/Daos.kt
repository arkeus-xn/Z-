package pl.ultraai.android.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import pl.ultraai.android.data.local.entity.AiCharacterEntity
import pl.ultraai.android.data.local.entity.ApiKeyEntity
import pl.ultraai.android.data.local.entity.CachedResponseEntity
import pl.ultraai.android.data.local.entity.ChatMessageEntity
import pl.ultraai.android.data.local.entity.ChatSessionEntity
import pl.ultraai.android.data.local.entity.DiagnosticLogEntity
import pl.ultraai.android.data.local.entity.FolderEntity
import pl.ultraai.android.data.local.entity.PromptTemplateEntity
import pl.ultraai.android.data.local.entity.UsageLogEntity

@Dao
interface ApiKeyDao {
    @Query("SELECT * FROM api_keys ORDER BY isActive DESC, createdAt DESC")
    fun observeAll(): Flow<List<ApiKeyEntity>>

    @Query("SELECT * FROM api_keys WHERE provider = :provider ORDER BY isActive DESC, createdAt DESC")
    suspend fun getByProvider(provider: String): List<ApiKeyEntity>

    @Query("SELECT * FROM api_keys WHERE provider = :provider AND isActive = 1 LIMIT 1")
    suspend fun getActiveForProvider(provider: String): ApiKeyEntity?

    @Insert
    suspend fun insert(entity: ApiKeyEntity): Long

    @Update
    suspend fun update(entity: ApiKeyEntity)

    @Delete
    suspend fun delete(entity: ApiKeyEntity)

    @Query("UPDATE api_keys SET isActive = 0 WHERE provider = :provider")
    suspend fun deactivateAllForProvider(provider: String)

    @Query("UPDATE api_keys SET isActive = 1 WHERE id = :id")
    suspend fun activateKey(id: Long)

    @Query("DELETE FROM api_keys")
    suspend fun deleteAll()
}

@Dao
interface FolderDao {
    @Query("SELECT * FROM folders ORDER BY name ASC")
    fun observeAll(): Flow<List<FolderEntity>>

    @Query("SELECT * FROM folders")
    suspend fun getAllOnce(): List<FolderEntity>

    @Insert
    suspend fun insert(folder: FolderEntity): Long

    @Delete
    suspend fun delete(folder: FolderEntity)

    @Query("DELETE FROM folders")
    suspend fun deleteAll()
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chat_sessions WHERE isIncognito = 0 ORDER BY isPinned DESC, updatedAt DESC")
    fun observeSessions(): Flow<List<ChatSessionEntity>>

    @Query("SELECT * FROM chat_sessions WHERE isIncognito = 0")
    suspend fun getAllSessionsOnce(): List<ChatSessionEntity>

    @Query("SELECT * FROM chat_sessions WHERE id = :id")
    suspend fun getSessionById(id: Long): ChatSessionEntity?

    @Query("SELECT * FROM chat_sessions WHERE characterId = :characterId ORDER BY updatedAt DESC")
    fun observeSessionsByCharacter(characterId: Long): Flow<List<ChatSessionEntity>>

    @Insert
    suspend fun insertSession(session: ChatSessionEntity): Long

    @Update
    suspend fun updateSession(session: ChatSessionEntity)

    @Delete
    suspend fun deleteSession(session: ChatSessionEntity)

    @Query("DELETE FROM chat_sessions")
    suspend fun deleteAllSessions()

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY createdAt ASC, id ASC")
    fun observeMessages(sessionId: Long): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY createdAt ASC, id ASC")
    suspend fun getMessagesOnce(sessionId: Long): List<ChatMessageEntity>

    @Query("SELECT * FROM chat_messages")
    suspend fun getAllMessagesOnce(): List<ChatMessageEntity>

    @Query("SELECT DISTINCT sessionId FROM chat_messages WHERE content LIKE '%' || :query || '%'")
    suspend fun searchSessionIdsByContent(query: String): List<Long>

    @Insert
    suspend fun insertMessage(message: ChatMessageEntity): Long

    @Update
    suspend fun updateMessage(message: ChatMessageEntity)

    @Delete
    suspend fun deleteMessage(message: ChatMessageEntity)

    @Query("DELETE FROM chat_messages WHERE sessionId = :sessionId AND id >= :fromMessageId")
    suspend fun deleteMessagesFrom(sessionId: Long, fromMessageId: Long)
}

@Dao
interface CharacterDao {
    @Query("SELECT * FROM ai_characters ORDER BY isBuiltIn ASC, createdAt DESC")
    fun observeAll(): Flow<List<AiCharacterEntity>>

    @Query("SELECT * FROM ai_characters")
    suspend fun getAllOnce(): List<AiCharacterEntity>

    @Query("SELECT * FROM ai_characters WHERE id = :id")
    suspend fun getById(id: Long): AiCharacterEntity?

    @Insert
    suspend fun insert(character: AiCharacterEntity): Long

    @Update
    suspend fun update(character: AiCharacterEntity)

    @Delete
    suspend fun delete(character: AiCharacterEntity)

    @Query("UPDATE ai_characters SET memorySummary = ''")
    suspend fun clearAllMemories()
}

@Dao
interface PromptDao {
    @Query("SELECT * FROM prompt_templates ORDER BY isFavorite DESC, usageCount DESC, createdAt DESC")
    fun observeAll(): Flow<List<PromptTemplateEntity>>

    @Query("SELECT * FROM prompt_templates")
    suspend fun getAllOnce(): List<PromptTemplateEntity>

    @Insert
    suspend fun insert(template: PromptTemplateEntity): Long

    @Update
    suspend fun update(template: PromptTemplateEntity)

    @Delete
    suspend fun delete(template: PromptTemplateEntity)
}

@Dao
interface UsageAndDiagnosticDao {
    @Query("SELECT * FROM usage_logs ORDER BY timestamp DESC")
    fun observeUsageLogs(): Flow<List<UsageLogEntity>>

    @Query("SELECT * FROM usage_logs")
    suspend fun getAllUsageOnce(): List<UsageLogEntity>

    @Query("SELECT COALESCE(SUM(estimatedCostUsd), 0.0) FROM usage_logs WHERE timestamp >= :sinceMs")
    suspend fun sumCostSince(sinceMs: Long): Double

    @Query("SELECT COUNT(*) FROM usage_logs WHERE timestamp >= :sinceMs")
    suspend fun countRequestsSince(sinceMs: Long): Int

    @Insert
    suspend fun insertUsage(log: UsageLogEntity)

    @Query("DELETE FROM usage_logs")
    suspend fun clearUsage()

    @Query("SELECT * FROM diagnostic_logs ORDER BY timestamp DESC LIMIT 250")
    fun observeDiagnostics(): Flow<List<DiagnosticLogEntity>>

    @Insert
    suspend fun insertDiagnostic(log: DiagnosticLogEntity)

    @Query("DELETE FROM diagnostic_logs")
    suspend fun clearDiagnostics()

    @Query("SELECT * FROM cached_responses WHERE promptHash = :hash LIMIT 1")
    suspend fun getCachedResponse(hash: String): CachedResponseEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun putCachedResponse(cache: CachedResponseEntity)

    @Query("DELETE FROM cached_responses")
    suspend fun clearCache()
}
