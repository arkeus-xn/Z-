package pl.ultraai.android.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okio.BufferedSource
import pl.ultraai.android.core.pricing.ModelPricingRegistry
import pl.ultraai.android.domain.model.AiModelInfo
import pl.ultraai.android.domain.model.AiProvider
import pl.ultraai.android.domain.model.ModelCapability
import java.io.IOException
import java.util.concurrent.TimeUnit

data class AiTurnMessage(
    val role: String, // "user" | "model"
    val text: String,
    val imageBase64: String? = null,
    val imageMimeType: String? = null
)

sealed interface AiStreamEvent {
    data class Delta(val text: String) : AiStreamEvent
    data class Completed(
        val fullText: String,
        val inputTokens: Int,
        val outputTokens: Int,
        val latencyMs: Long,
        val rateLimitInfo: String = "Brak danych"
    ) : AiStreamEvent
    data class Error(val message: String, val httpCode: Int? = null) : AiStreamEvent
}

data class ConnectionTestResult(
    val success: Boolean,
    val message: String,
    val models: List<AiModelInfo> = emptyList(),
    val rateLimitSummary: String = "Brak danych"
)

class GeminiApiClient(
    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()
) {
    private val json = Json { ignoreUnknownKeys = true }
    private val mediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun fetchModels(apiKey: String): ConnectionTestResult = withContext(Dispatchers.IO) {
        val cleanKey = apiKey.trim()
        if (cleanKey.isBlank()) {
            return@withContext ConnectionTestResult(false, "Klucz API jest pusty.")
        }
        val request = Request.Builder()
            .url("${AiProvider.GEMINI.baseUrl}/models?pageSize=100")
            .addHeader("x-goog-api-key", cleanKey)
            .get()
            .build()

        runCatching {
            okHttpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    val errMsg = parseGeminiError(bodyStr, response.code)
                    return@withContext ConnectionTestResult(false, errMsg)
                }
                val root = json.parseToJsonElement(bodyStr).jsonObject
                val modelsArr = root["models"]?.jsonArray ?: JsonArray(emptyList())
                val parsed = modelsArr.mapNotNull { elem ->
                    val obj = elem.jsonObject
                    val rawName = obj["name"]?.jsonPrimitive?.content ?: return@mapNotNull null
                    val id = rawName.removePrefix("models/")
                    val methods = obj["supportedGenerationMethods"]?.jsonArray
                        ?.mapNotNull { it.jsonPrimitive.content }
                        .orEmpty()
                    if ("generateContent" !in methods) return@mapNotNull null

                    val displayName = obj["displayName"]?.jsonPrimitive?.content ?: id
                    val description = obj["description"]?.jsonPrimitive?.content.orEmpty()
                    val inputLimit = obj["inputTokenLimit"]?.jsonPrimitive?.intOrNull
                    val outputLimit = obj["outputTokenLimit"]?.jsonPrimitive?.intOrNull
                    val verified = ModelPricingRegistry.lookupMetadata(AiProvider.GEMINI, id)

                    val caps = mutableSetOf(ModelCapability.TEXT, ModelCapability.STREAMING)
                    if (verified != null) caps.addAll(verified.extraCapabilities)
                    if ((inputLimit ?: 0) >= 128_000) caps.add(ModelCapability.LONG_CONTEXT)

                    AiModelInfo(
                        id = id,
                        displayName = displayName,
                        provider = AiProvider.GEMINI,
                        description = description,
                        inputContextLimit = inputLimit ?: verified?.defaultContextLimit,
                        outputTokenLimit = outputLimit,
                        inputPricePer1MUsd = verified?.inputPricePer1MUsd,
                        outputPricePer1MUsd = verified?.outputPricePer1MUsd,
                        freeTierInfo = verified?.freeTierInfo ?: "Brak danych",
                        capabilities = caps,
                        isAvailable = true,
                        speedTier = verified?.speedTier ?: 2,
                        qualityTier = verified?.qualityTier ?: 2
                    )
                }.sortedByDescending { it.qualityTier }

                ConnectionTestResult(
                    success = true,
                    message = "Połączono z Google Gemini API. Pobrano ${parsed.size} modeli.",
                    models = parsed,
                    rateLimitSummary = "Limity RPM/RPD zależą od planu Google AI Studio"
                )
            }
        }.getOrElse { ex ->
            ConnectionTestResult(false, "Błąd sieci: ${ex.localizedMessage ?: "nieznany błąd"}")
        }
    }

    fun streamGenerateContent(
        apiKey: String,
        modelId: String,
        systemPrompt: String,
        messages: List<AiTurnMessage>,
        temperature: Float,
        maxOutputTokens: Int
    ): Flow<AiStreamEvent> = callbackFlow {
        val startTime = System.currentTimeMillis()
        val cleanModel = modelId.removePrefix("models/")
        val payload = buildRequestJson(systemPrompt, messages, temperature, maxOutputTokens)
        val request = Request.Builder()
            .url("${AiProvider.GEMINI.baseUrl}/models/$cleanModel:streamGenerateContent?alt=sse")
            .addHeader("x-goog-api-key", apiKey.trim())
            .post(payload.toRequestBody(mediaType))
            .build()

        val call = okHttpClient.newCall(request)
        call.enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (!call.isCanceled()) {
                    trySend(AiStreamEvent.Error("Błąd połączenia z Gemini: ${e.localizedMessage}"))
                }
                close()
            }

            override fun onResponse(call: Call, response: Response) {
                response.use { res ->
                    if (!res.isSuccessful) {
                        val errBody = res.body?.string().orEmpty()
                        trySend(AiStreamEvent.Error(parseGeminiError(errBody, res.code), res.code))
                        close()
                        return
                    }

                    val source: BufferedSource = res.body?.source() ?: run {
                        trySend(AiStreamEvent.Error("Pusta odpowiedź z serwera Gemini."))
                        close()
                        return
                    }

                    val fullText = StringBuilder()
                    var inputTokens = 0
                    var outputTokens = 0

                    try {
                        while (!source.exhausted() && !call.isCanceled()) {
                            val line = source.readUtf8Line() ?: break
                            if (!line.startsWith("data:")) continue
                            val dataJson = line.removePrefix("data:").trim()
                            if (dataJson.isBlank() || dataJson == "[DONE]") continue

                            val obj = runCatching { json.parseToJsonElement(dataJson).jsonObject }.getOrNull()
                                ?: continue

                            obj["usageMetadata"]?.jsonObject?.let { usage ->
                                inputTokens = usage["promptTokenCount"]?.jsonPrimitive?.intOrNull ?: inputTokens
                                outputTokens = usage["candidatesTokenCount"]?.jsonPrimitive?.intOrNull ?: outputTokens
                            }

                            val candidates = obj["candidates"]?.jsonArray ?: continue
                            val firstCand = candidates.firstOrNull()?.jsonObject ?: continue
                            val parts = firstCand["content"]?.jsonObject?.get("parts")?.jsonArray ?: continue
                            for (part in parts) {
                                val chunkText = part.jsonObject["text"]?.jsonPrimitive?.content
                                if (!chunkText.isNullOrEmpty()) {
                                    fullText.append(chunkText)
                                    trySend(AiStreamEvent.Delta(chunkText))
                                }
                            }
                        }

                        if (!call.isCanceled()) {
                            val latency = System.currentTimeMillis() - startTime
                            trySend(
                                AiStreamEvent.Completed(
                                    fullText = fullText.toString(),
                                    inputTokens = inputTokens,
                                    outputTokens = outputTokens,
                                    latencyMs = latency
                                )
                            )
                        }
                    } catch (e: Exception) {
                        if (!call.isCanceled()) {
                            trySend(AiStreamEvent.Error("Błąd strumienia Gemini: ${e.localizedMessage}"))
                        }
                    } finally {
                        close()
                    }
                }
            }
        })

        awaitClose { call.cancel() }
    }

    private fun buildRequestJson(
        systemPrompt: String,
        messages: List<AiTurnMessage>,
        temperature: Float,
        maxOutputTokens: Int
    ): String {
        val root = buildJsonObject {
            if (systemPrompt.isNotBlank()) {
                put("systemInstruction", buildJsonObject {
                    put("parts", buildJsonArray {
                        add(buildJsonObject { put("text", systemPrompt) })
                    })
                })
            }
            put("contents", buildJsonArray {
                messages.forEach { msg ->
                    add(buildJsonObject {
                        put("role", if (msg.role == "model") "model" else "user")
                        put("parts", buildJsonArray {
                            if (msg.text.isNotBlank()) {
                                add(buildJsonObject { put("text", msg.text) })
                            }
                            if (!msg.imageBase64.isNullOrBlank()) {
                                add(buildJsonObject {
                                    put("inlineData", buildJsonObject {
                                        put("mimeType", msg.imageMimeType ?: "image/jpeg")
                                        put("data", msg.imageBase64)
                                    })
                                })
                            }
                        })
                    })
                }
            })
            put("generationConfig", buildJsonObject {
                put("temperature", temperature.toDouble())
                put("maxOutputTokens", maxOutputTokens)
            })
        }
        return root.toString()
    }

    private fun parseGeminiError(body: String, code: Int): String {
        val msg = runCatching {
            json.parseToJsonElement(body).jsonObject["error"]?.jsonObject?.get("message")?.jsonPrimitive?.content
        }.getOrNull()
        return when (code) {
            401, 403 -> "Błąd autoryzacji ($code): Sprawdź poprawność klucza Gemini API. ${msg.orEmpty()}"
            429 -> "Przekroczono limit zapytań Gemini (429). ${msg.orEmpty()}"
            else -> "Błąd Gemini API ($code): ${msg ?: body.take(220)}"
        }
    }
}
