package pl.ultraai.android.ui.chat

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pl.ultraai.android.AppContainer
import pl.ultraai.android.core.files.DocumentExtractor
import pl.ultraai.android.core.files.ExtractedAttachment
import pl.ultraai.android.core.pricing.CostEstimator
import pl.ultraai.android.core.pricing.ModelSelector
import pl.ultraai.android.data.local.entity.AiCharacterEntity
import pl.ultraai.android.data.local.entity.ChatMessageEntity
import pl.ultraai.android.data.local.entity.ChatSessionEntity
import pl.ultraai.android.data.local.entity.FolderEntity
import pl.ultraai.android.data.remote.AiStreamEvent
import pl.ultraai.android.data.remote.AiTurnMessage
import pl.ultraai.android.domain.model.AiModelInfo
import pl.ultraai.android.domain.model.AiProvider
import pl.ultraai.android.domain.model.AppSettings
import pl.ultraai.android.domain.model.CostEstimate
import pl.ultraai.android.domain.model.SelectionMode

data class ChatUiState(
    val activeSession: ChatSessionEntity? = null,
    val sessions: List<ChatSessionEntity> = emptyList(),
    val folders: List<FolderEntity> = emptyList(),
    val messages: List<ChatMessageEntity> = emptyList(),
    val characters: List<AiCharacterEntity> = emptyList(),
    val availableModels: List<AiModelInfo> = emptyList(),
    val selectedModel: AiModelInfo? = null,
    val settings: AppSettings = AppSettings(),
    val searchQuery: String = "",
    val selectedFolderId: Long? = null,
    val showArchived: Boolean = false,
    val isIncognitoDraft: Boolean = false,
    val pendingAttachment: ExtractedAttachment? = null,
    val isGenerating: Boolean = false,
    val streamingText: String = "",
    val editingMessage: ChatMessageEntity? = null,
    val pendingCostConfirmation: Pair<String, CostEstimate>? = null,
    val errorBanner: String? = null
)

class ChatViewModel(private val container: AppContainer) : ViewModel() {

    private val activeSessionId = MutableStateFlow<Long?>(null)
    private val searchQuery = MutableStateFlow("")
    private val selectedFolderId = MutableStateFlow<Long?>(null)
    private val showArchived = MutableStateFlow(false)
    private val isIncognitoDraft = MutableStateFlow(false)
    private val pendingAttachment = MutableStateFlow<ExtractedAttachment?>(null)
    private val isGenerating = MutableStateFlow(false)
    private val streamingText = MutableStateFlow("")
    private val editingMessage = MutableStateFlow<ChatMessageEntity?>(null)
    private val manualModelOverride = MutableStateFlow<AiModelInfo?>(null)
    private val pendingCostConfirmation = MutableStateFlow<Pair<String, CostEstimate>?>(null)
    private val errorBanner = MutableStateFlow<String?>(null)
    private val matchingSessionIds = MutableStateFlow<Set<Long>>(emptySet())

    private var generationJob: Job? = null

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    private val activeMessagesFlow = activeSessionId.flatMapLatest { id ->
        if (id == null) flowOf(emptyList()) else container.chatRepo.observeMessages(id)
    }

    val uiState: StateFlow<ChatUiState> = combine(
        listOf<Flow<Any?>>(
            container.chatRepo.observeSessions(),
            container.chatRepo.observeFolders(),
            activeMessagesFlow,
            container.characterAndPromptRepo.observeCharacters(),
            container.apiKeyAndModelRepo.discoveredModels,
            container.settingsStore.settingsFlow,
            activeSessionId,
            searchQuery,
            selectedFolderId,
            showArchived,
            isIncognitoDraft,
            pendingAttachment,
            isGenerating,
            streamingText,
            editingMessage,
            manualModelOverride,
            pendingCostConfirmation,
            errorBanner,
            matchingSessionIds
        )
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val allSessions = values[0] as List<ChatSessionEntity>
        @Suppress("UNCHECKED_CAST")
        val folders = values[1] as List<FolderEntity>
        @Suppress("UNCHECKED_CAST")
        val messages = values[2] as List<ChatMessageEntity>
        @Suppress("UNCHECKED_CAST")
        val characters = values[3] as List<AiCharacterEntity>
        @Suppress("UNCHECKED_CAST")
        val models = values[4] as List<AiModelInfo>
        val settings = values[5] as AppSettings
        val currentId = values[6] as Long?
        val query = values[7] as String
        val folderId = values[8] as Long?
        val archived = values[9] as Boolean
        val incognito = values[10] as Boolean
        val attachment = values[11] as ExtractedAttachment?
        val generating = values[12] as Boolean
        val streaming = values[13] as String
        val editing = values[14] as ChatMessageEntity?
        val overrideModel = values[15] as AiModelInfo?
        @Suppress("UNCHECKED_CAST")
        val costConfirm = values[16] as Pair<String, CostEstimate>?
        val err = values[17] as String?
        @Suppress("UNCHECKED_CAST")
        val contentMatches = values[18] as Set<Long>

        val filteredSessions = allSessions.filter { session ->
            val archiveMatch = session.isArchived == archived
            val folderMatch = folderId == null || session.folderId == folderId
            val searchMatch = query.isBlank() ||
                session.title.contains(query, ignoreCase = true) ||
                session.id in contentMatches
            archiveMatch && folderMatch && searchMatch
        }

        val activeSession = allSessions.firstOrNull { it.id == currentId }
        val resolvedModel = overrideModel
            ?: models.firstOrNull { it.id == activeSession?.modelId }
            ?: models.firstOrNull { it.id == settings.defaultModelId }
            ?: models.firstOrNull()

        ChatUiState(
            activeSession = activeSession,
            sessions = filteredSessions,
            folders = folders,
            messages = messages,
            characters = characters,
            availableModels = models,
            selectedModel = resolvedModel,
            settings = settings,
            searchQuery = query,
            selectedFolderId = folderId,
            showArchived = archived,
            isIncognitoDraft = incognito,
            pendingAttachment = attachment,
            isGenerating = generating,
            streamingText = streaming,
            editingMessage = editing,
            pendingCostConfirmation = costConfirm,
            errorBanner = err
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ChatUiState())

    fun selectSession(sessionId: Long?) {
        activeSessionId.value = sessionId
        editingMessage.value = null
    }

    fun startNewChat(characterId: Long? = null, incognito: Boolean = false) {
        activeSessionId.value = null
        isIncognitoDraft.value = incognito
        pendingAttachment.value = null
        editingMessage.value = null
        if (characterId != null) {
            viewModelScope.launch {
                val char = container.characterAndPromptRepo.getCharacter(characterId)
                val model = uiState.value.availableModels.firstOrNull { it.id == char?.preferredModelId }
                    ?: uiState.value.selectedModel
                    ?: return@launch
                val newId = container.chatRepo.createSession(
                    title = "Rozmowa: ${char?.name ?: "Postać"}",
                    provider = model.provider,
                    modelId = model.id,
                    characterId = characterId,
                    isIncognito = incognito
                )
                activeSessionId.value = newId
            }
        }
    }

    fun updateSearchQuery(query: String) {
        searchQuery.value = query
        viewModelScope.launch {
            matchingSessionIds.value = container.chatRepo.searchSessionIds(query)
        }
    }

    fun selectFolder(folderId: Long?) {
        selectedFolderId.value = folderId
    }

    fun toggleShowArchived() {
        showArchived.value = !showArchived.value
    }

    fun createFolder(name: String) {
        if (name.isBlank()) return
        viewModelScope.launch { container.chatRepo.createFolder(name) }
    }

    fun assignFolder(session: ChatSessionEntity, folderId: Long?) {
        viewModelScope.launch { container.chatRepo.updateSession(session.copy(folderId = folderId)) }
    }

    fun togglePin(session: ChatSessionEntity) {
        viewModelScope.launch { container.chatRepo.updateSession(session.copy(isPinned = !session.isPinned)) }
    }

    fun toggleArchive(session: ChatSessionEntity) {
        viewModelScope.launch { container.chatRepo.updateSession(session.copy(isArchived = !session.isArchived)) }
    }

    fun deleteSession(session: ChatSessionEntity) {
        viewModelScope.launch {
            if (activeSessionId.value == session.id) activeSessionId.value = null
            container.chatRepo.deleteSession(session)
        }
    }

    fun selectModel(model: AiModelInfo) {
        manualModelOverride.value = model
        viewModelScope.launch {
            uiState.value.activeSession?.let { session ->
                container.chatRepo.updateSession(
                    session.copy(provider = model.provider.name, modelId = model.id)
                )
            }
        }
    }

    fun setSelectionMode(mode: SelectionMode) {
        viewModelScope.launch {
            container.settingsStore.updateSettings { it.copy(selectionMode = mode) }
        }
    }

    fun toggleFavoriteModel(modelId: String) {
        viewModelScope.launch {
            container.settingsStore.updateSettings { s ->
                val updated = if (modelId in s.favoriteModelIds) s.favoriteModelIds - modelId else s.favoriteModelIds + modelId
                s.copy(favoriteModelIds = updated)
            }
        }
    }

    fun attachFile(context: Context, uri: Uri) {
        viewModelScope.launch {
            DocumentExtractor.extractFromUri(context, uri)
                .onSuccess { pendingAttachment.value = it }
                .onFailure { errorBanner.value = "Nie udało się odczytać pliku: ${it.localizedMessage}" }
        }
    }

    fun clearAttachment() {
        pendingAttachment.value = null
    }

    fun beginEditMessage(message: ChatMessageEntity) {
        editingMessage.value = message
    }

    fun cancelEditMessage() {
        editingMessage.value = null
    }

    fun clearError() {
        errorBanner.value = null
    }

    fun dismissCostDialog() {
        pendingCostConfirmation.value = null
    }

    fun confirmAndSendPending() {
        val pending = pendingCostConfirmation.value ?: return
        pendingCostConfirmation.value = null
        executeSend(pending.first, bypassCostCheck = true)
    }

    /**
     * Obsługa autorskich komend ukośnikowych (/tlumacz, /kod, /skrot, /sprawdz).
     */
    private fun expandSlashCommand(rawInput: String): String {
        val trimmed = rawInput.trim()
        return when {
            trimmed.startsWith("/tlumacz ") ->
                "Przetłumacz precyzyjnie i naturalnie na język angielski (lub na polski, jeśli tekst jest obcojęzyczny):\n\n${trimmed.removePrefix("/tlumacz ")}"
            trimmed.startsWith("/kod ") ->
                "Napisz czysty, bezpieczny i gotowy do użycia kod wraz z krótkim wyjaśnieniem:\n\n${trimmed.removePrefix("/kod ")}"
            trimmed.startsWith("/skrot ") ->
                "Streść poniższy materiał w zwięzłych punktach z najważniejszymi wnioskami:\n\n${trimmed.removePrefix("/skrot ")}"
            trimmed.startsWith("/sprawdz ") ->
                "Zweryfikuj poprawność merytoryczną, logiczną i językową poniższego tekstu:\n\n${trimmed.removePrefix("/sprawdz ")}"
            else -> trimmed
        }
    }

    fun sendMessage(rawText: String) {
        val expanded = expandSlashCommand(rawText)
        if (expanded.isBlank() && pendingAttachment.value == null) return

        val state = uiState.value
        val model = ModelSelector.selectModel(
            availableModels = state.availableModels,
            criteria = ModelSelector.SelectionCriteria(
                mode = state.settings.selectionMode,
                preferredModelId = state.selectedModel?.id,
                promptText = expanded,
                requiresVision = state.pendingAttachment?.imageBase64 != null
            )
        )

        if (model == null) {
            errorBanner.value = "Brak dostępnych modeli. Dodaj i przetestuj klucz API Google Gemini lub Groq w Ustawieniach."
            return
        }

        val combinedForEstimate = buildString {
            append(expanded)
            state.pendingAttachment?.extractedText?.let { append("\n").append(it) }
            state.messages.takeLast(8).forEach { append("\n").append(it.content) }
        }

        viewModelScope.launch {
            val todaySpent = container.usageRepo.getTodaySpentUsd()
            val todayReqs = container.usageRepo.getTodayRequestCount()
            if (todayReqs >= state.settings.dailyRequestLimit) {
                errorBanner.value = "Osiągnięto dzienny limit zapytań (${state.settings.dailyRequestLimit}). Zmień limit w Ustawieniach zaawansowanych."
                return@launch
            }
            val estimate = CostEstimator.preflightEstimate(
                model = model,
                promptText = combinedForEstimate,
                expectedOutputTokens = state.settings.maxOutputTokens,
                thresholdUsd = state.settings.confirmCostThresholdUsd,
                todaySpentUsd = todaySpent,
                dailyLimitUsd = state.settings.dailyCostLimitUsd
            )
            if (estimate.exceedsThreshold || estimate.exceedsDailyLimit) {
                pendingCostConfirmation.value = expanded to estimate
            } else {
                executeSend(expanded, bypassCostCheck = true)
            }
        }
    }

    private fun executeSend(promptText: String, bypassCostCheck: Boolean) {
        val state = uiState.value
        val attachment = state.pendingAttachment
        val editing = state.editingMessage

        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            val targetModel = ModelSelector.selectModel(
                availableModels = state.availableModels,
                criteria = ModelSelector.SelectionCriteria(
                    mode = state.settings.selectionMode,
                    preferredModelId = state.selectedModel?.id,
                    promptText = promptText,
                    requiresVision = attachment?.imageBase64 != null
                )
            ) ?: return@launch

            val sessionId = state.activeSession?.id ?: container.chatRepo.createSession(
                title = promptText.take(42).ifBlank { attachment?.displayName ?: "Nowa rozmowa" },
                provider = targetModel.provider,
                modelId = targetModel.id,
                folderId = state.selectedFolderId,
                isIncognito = state.isIncognitoDraft
            ).also { activeSessionId.value = it }

            if (editing != null) {
                container.chatRepo.deleteMessagesFrom(sessionId, editing.id)
                editingMessage.value = null
            }

            val fullUserContent = buildString {
                if (promptText.isNotBlank()) append(promptText)
                if (!attachment?.extractedText.isNullOrBlank()) {
                    if (isNotEmpty()) append("\n\n")
                    append("--- Treść załącznika: ${attachment?.displayName} ---\n")
                    append(attachment?.extractedText?.take(28_000))
                }
            }

            container.chatRepo.addMessage(
                ChatMessageEntity(
                    sessionId = sessionId,
                    role = "user",
                    content = fullUserContent,
                    attachmentName = attachment?.displayName,
                    attachmentMime = attachment?.mimeType,
                    imageBase64 = attachment?.imageBase64,
                    inputTokens = CostEstimator.estimateTokens(fullUserContent)
                )
            )
            pendingAttachment.value = null
            streamAssistantResponse(sessionId, targetModel)
        }
    }

    fun regenerateLastResponse() {
        val state = uiState.value
        val sessionId = state.activeSession?.id ?: return
        val lastModelMsg = state.messages.lastOrNull { it.role == "model" }
        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            if (lastModelMsg != null) {
                container.chatRepo.deleteMessagesFrom(sessionId, lastModelMsg.id)
            }
            val model = state.selectedModel ?: return@launch
            streamAssistantResponse(sessionId, model)
        }
    }

    fun continueLastResponse() {
        val state = uiState.value
        val sessionId = state.activeSession?.id ?: return
        val lastModelMsg = state.messages.lastOrNull { it.role == "model" } ?: return
        val model = state.selectedModel ?: return
        generationJob?.cancel()
        generationJob = viewModelScope.launch {
            container.chatRepo.addMessage(
                ChatMessageEntity(
                    sessionId = sessionId,
                    role = "user",
                    content = "Kontynuuj dokładnie od miejsca, w którym zakończyłeś powyższą odpowiedź (nie powtarzaj wcześniejszej treści)."
                )
            )
            streamAssistantResponse(sessionId, model)
        }
    }

    fun stopGeneration() {
        generationJob?.cancel()
        val partial = streamingText.value
        val sessionId = activeSessionId.value
        if (partial.isNotBlank() && sessionId != null) {
            viewModelScope.launch {
                container.chatRepo.addMessage(
                    ChatMessageEntity(
                        sessionId = sessionId,
                        role = "model",
                        content = "$partial\n\n*[Generowanie przerwane przez użytkownika]*",
                        modelUsed = uiState.value.selectedModel?.id
                    )
                )
                streamingText.value = ""
                isGenerating.value = false
            }
        } else {
            streamingText.value = ""
            isGenerating.value = false
        }
    }

    fun optimizePromptInPlace(draft: String, onOptimized: (String) -> Unit) {
        val model = uiState.value.selectedModel ?: return
        viewModelScope.launch {
            val apiKey = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider) ?: return@launch
            val res = container.aiGateway.completeOnce(
                model = model,
                apiKey = apiKey,
                systemPrompt = "Jesteś inżynierem promptów. Przepisz zapytanie użytkownika na precyzyjny, kompletny prompt po polsku. Zwróć wyłącznie treść ulepszonego promptu bez komentarzy.",
                messages = listOf(AiTurnMessage("user", draft)),
                temperature = 0.4f,
                maxOutputTokens = 600
            )
            if (!res.isError && res.text.isNotBlank()) {
                onOptimized(res.text.trim())
            }
        }
    }

    fun exportCurrentSessionMarkdown(): String {
        val state = uiState.value
        val title = state.activeSession?.title ?: "Rozmowa ULTRA AI"
        return buildString {
            appendLine("# $title")
            appendLine()
            state.messages.forEach { msg ->
                val who = if (msg.role == "user") "Użytkownik" else "ULTRA AI (${msg.modelUsed ?: ""})"
                appendLine("### $who")
                appendLine(msg.content)
                appendLine()
            }
        }
    }

    private suspend fun streamAssistantResponse(sessionId: Long, model: AiModelInfo) {
        val settings = uiState.value.settings
        val session = container.chatRepo.getSession(sessionId)
        val character = session?.characterId?.let { container.characterAndPromptRepo.getCharacter(it) }
        val apiKey = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider)

        if (apiKey.isNullOrBlank()) {
            errorBanner.value = "Brak aktywnego klucza API dla ${model.provider.displayName}."
            return
        }

        val systemPrompt = buildString {
            if (character != null) {
                appendLine(character.systemPrompt)
                appendLine("Osobowość: ${character.personality}. Cechy: ${character.traits}. Styl wypowiedzi: ${character.speakingStyle}.")
                if (character.memoryEnabled && character.memorySummary.isNotBlank()) {
                    appendLine("Zapamiętane informacje o użytkowniku: ${character.memorySummary}")
                }
            } else {
                append(settings.defaultSystemPrompt)
            }
        }

        val history = container.chatRepo.getMessagesOnce(sessionId)
            .takeLast(24)
            .map {
                AiTurnMessage(
                    role = it.role,
                    text = it.content,
                    imageBase64 = it.imageBase64,
                    imageMimeType = it.attachmentMime
                )
            }

        isGenerating.value = true
        streamingText.value = ""

        container.aiGateway.streamChat(
            provider = model.provider,
            apiKey = apiKey,
            modelId = model.id,
            systemPrompt = systemPrompt,
            messages = history,
            temperature = character?.temperature ?: settings.defaultTemperature,
            maxOutputTokens = settings.maxOutputTokens
        ).collect { event ->
            when (event) {
                is AiStreamEvent.Delta -> {
                    streamingText.value += event.text
                }
                is AiStreamEvent.Completed -> {
                    val finalContent = streamingText.value.ifBlank { event.fullText }
                    val inTokens = if (event.inputTokens > 0) event.inputTokens else CostEstimator.estimateTokens(history.joinToString { it.text })
                    val outTokens = if (event.outputTokens > 0) event.outputTokens else CostEstimator.estimateTokens(finalContent)
                    val cost = CostEstimator.calculateExactCost(model, inTokens, outTokens)

                    container.chatRepo.addMessage(
                        ChatMessageEntity(
                            sessionId = sessionId,
                            role = "model",
                            content = finalContent,
                            modelUsed = model.id,
                            inputTokens = inTokens,
                            outputTokens = outTokens,
                            costUsd = cost,
                            latencyMs = event.latencyMs
                        )
                    )
                    container.usageRepo.logUsage(
                        featureName = "Czat",
                        provider = model.provider,
                        modelId = model.id,
                        inputTokens = inTokens,
                        outputTokens = outTokens,
                        estimatedCostUsd = cost,
                        latencyMs = event.latencyMs
                    )
                    history.lastOrNull()?.text?.let { lastPrompt ->
                        container.chatRepo.cacheResponse(lastPrompt, model.id, finalContent)
                    }
                    streamingText.value = ""
                    isGenerating.value = false
                }
                is AiStreamEvent.Error -> {
                    container.chatRepo.addMessage(
                        ChatMessageEntity(
                            sessionId = sessionId,
                            role = "model",
                            content = event.message,
                            modelUsed = model.id,
                            isError = true
                        )
                    )
                    container.usageRepo.logDiagnostic("ERROR", model.provider.name, event.message)
                    streamingText.value = ""
                    isGenerating.value = false
                }
            }
        }
    }
}
