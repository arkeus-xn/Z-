package pl.ultraai.android.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class ThemePreset(val labelPl: String) {
    OBSIDIAN("Obsydian (Domyślny)"),
    COBALT("Kobalt Pro"),
    EMERALD("Szmaragdowy"),
    GRAPHITE("Grafitowy")
}

@Serializable
enum class MessageStyle(val labelPl: String) {
    MODERN("Nowoczesne dymki"),
    CLASSIC("Klasyczne karty"),
    COMPACT("Kompaktowy czat")
}

@Serializable
data class AppSettings(
    // Wygląd
    val darkTheme: Boolean = true,
    val themePreset: ThemePreset = ThemePreset.OBSIDIAN,
    val accentColorHex: Long = 0xFF3B82F6,
    val fontScale: Float = 1.0f,
    val animationsEnabled: Boolean = true,
    val messageStyle: MessageStyle = MessageStyle.MODERN,

    // AI
    val defaultProvider: AiProvider = AiProvider.GEMINI,
    val defaultModelId: String = "",
    val defaultTemperature: Float = 0.7f,
    val maxOutputTokens: Int = 4096,
    val defaultSystemPrompt: String = "Jesteś pomocnym, precyzyjnym asystentem ULTRA AI. Odpowiadaj po polsku, chyba że użytkownik poprosi o inny język.",
    val selectionMode: SelectionMode = SelectionMode.AUTO,
    val favoriteModelIds: Set<String> = emptySet(),

    // Prywatność i limity
    val pinEnabled: Boolean = false,
    val pinHash: String = "",
    val biometricEnabled: Boolean = false,
    val dailyCostLimitUsd: Double = 2.0,
    val monthlyCostLimitUsd: Double = 25.0,
    val dailyRequestLimit: Int = 250,
    val confirmCostThresholdUsd: Double = 0.02
)

@Serializable
data class CostEstimate(
    val estimatedInputTokens: Int,
    val estimatedOutputTokens: Int,
    val estimatedCostUsd: Double?,
    val formattedCost: String,
    val exceedsThreshold: Boolean,
    val exceedsDailyLimit: Boolean,
    val warningMessage: String? = null
)

@Serializable
data class ProviderRateStatus(
    val provider: AiProvider,
    val isConnected: Boolean,
    val activeKeyLabel: String?,
    val modelsCount: Int,
    val remainingRequests: String = "Brak danych",
    val remainingTokens: String = "Brak danych",
    val lastError: String? = null,
    val lastCheckedAt: Long? = null
)
