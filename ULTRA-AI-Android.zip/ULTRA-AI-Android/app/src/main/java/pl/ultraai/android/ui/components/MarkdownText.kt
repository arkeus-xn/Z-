package pl.ultraai.android.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private sealed interface MdBlock {
    data class Paragraph(val text: String) : MdBlock
    data class Heading(val level: Int, val text: String) : MdBlock
    data class CodeBlock(val language: String, val code: String) : MdBlock
    data class BulletItem(val text: String) : MdBlock
}

/**
 * Natywny renderer Markdown + kolorowanie składni kodu dla Jetpack Compose (bez WebView).
 */
@Composable
fun MarkdownText(
    markdown: String,
    modifier: Modifier = Modifier,
    textColor: Color = MaterialTheme.colorScheme.onSurface
) {
    val blocks = remember(markdown) { parseMarkdownBlocks(markdown) }
    val clipboard = LocalClipboardManager.current

    SelectionContainer(modifier = modifier) {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            blocks.forEach { block ->
                when (block) {
                    is MdBlock.Heading -> {
                        val size = when (block.level) {
                            1 -> 19.sp
                            2 -> 17.sp
                            else -> 15.5.sp
                        }
                        Text(
                            text = parseInlineMarkdown(block.text, MaterialTheme.colorScheme.primary),
                            fontSize = size,
                            fontWeight = FontWeight.Bold,
                            color = textColor
                        )
                    }

                    is MdBlock.BulletItem -> {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("•", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            Text(
                                text = parseInlineMarkdown(block.text, MaterialTheme.colorScheme.primary),
                                style = MaterialTheme.typography.bodyMedium,
                                color = textColor
                            )
                        }
                    }

                    is MdBlock.Paragraph -> {
                        Text(
                            text = parseInlineMarkdown(block.text, MaterialTheme.colorScheme.primary),
                            style = MaterialTheme.typography.bodyMedium,
                            color = textColor
                        )
                    }

                    is MdBlock.CodeBlock -> {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = Color(0xFF0D1117),
                            tonalElevation = 2.dp,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFF161B22))
                                        .padding(horizontal = 12.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = block.language.ifBlank { "kod" }.uppercase(),
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = Color(0xFF94A3B8),
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    IconButton(
                                        onClick = { clipboard.setText(AnnotatedString(block.code)) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.ContentCopy,
                                            contentDescription = "Kopiuj kod",
                                            tint = Color(0xFFCBD5E1),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Text(
                                    text = highlightCode(block.code),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.5.sp,
                                    lineHeight = 18.sp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .horizontalScroll(rememberScrollState())
                                        .padding(12.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                    }
                }
            }
        }
    }
}

private fun parseMarkdownBlocks(raw: String): List<MdBlock> {
    val lines = raw.lines()
    val result = mutableListOf<MdBlock>()
    var inCode = false
    var codeLang = ""
    val codeBuf = StringBuilder()
    val paraBuf = StringBuilder()

    fun flushPara() {
        val text = paraBuf.toString().trim()
        if (text.isNotEmpty()) result.add(MdBlock.Paragraph(text))
        paraBuf.clear()
    }

    for (line in lines) {
        val trimmed = line.trim()
        if (trimmed.startsWith("```")) {
            if (!inCode) {
                flushPara()
                inCode = true
                codeLang = trimmed.removePrefix("```").trim()
                codeBuf.clear()
            } else {
                result.add(MdBlock.CodeBlock(codeLang, codeBuf.toString().trimEnd()))
                inCode = false
                codeLang = ""
            }
            continue
        }
        if (inCode) {
            codeBuf.appendLine(line)
            continue
        }
        when {
            trimmed.startsWith("### ") -> {
                flushPara()
                result.add(MdBlock.Heading(3, trimmed.removePrefix("### ")))
            }
            trimmed.startsWith("## ") -> {
                flushPara()
                result.add(MdBlock.Heading(2, trimmed.removePrefix("## ")))
            }
            trimmed.startsWith("# ") -> {
                flushPara()
                result.add(MdBlock.Heading(1, trimmed.removePrefix("# ")))
            }
            trimmed.startsWith("- ") || trimmed.startsWith("* ") -> {
                flushPara()
                result.add(MdBlock.BulletItem(trimmed.drop(2)))
            }
            trimmed.isEmpty() -> flushPara()
            else -> {
                if (paraBuf.isNotEmpty()) paraBuf.append('\n')
                paraBuf.append(line)
            }
        }
    }
    if (inCode && codeBuf.isNotEmpty()) {
        result.add(MdBlock.CodeBlock(codeLang, codeBuf.toString().trimEnd()))
    }
    flushPara()
    return result
}

private fun parseInlineMarkdown(text: String, accent: Color): AnnotatedString {
    return buildAnnotatedString {
        var idx = 0
        while (idx < text.length) {
            when {
                text.startsWith("**", idx) -> {
                    val end = text.indexOf("**", idx + 2)
                    if (end != -1) {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold)) {
                            append(text.substring(idx + 2, end))
                        }
                        idx = end + 2
                    } else {
                        append("**")
                        idx += 2
                    }
                }
                text[idx] == '`' -> {
                    val end = text.indexOf('`', idx + 1)
                    if (end != -1) {
                        withStyle(
                            SpanStyle(
                                fontFamily = FontFamily.Monospace,
                                background = accent.copy(alpha = 0.16f),
                                color = accent
                            )
                        ) {
                            append(" ${text.substring(idx + 1, end)} ")
                        }
                        idx = end + 1
                    } else {
                        append('`')
                        idx++
                    }
                }
                text[idx] == '*' -> {
                    val end = text.indexOf('*', idx + 1)
                    if (end != -1) {
                        withStyle(SpanStyle(fontStyle = FontStyle.Italic)) {
                            append(text.substring(idx + 1, end))
                        }
                        idx = end + 1
                    } else {
                        append('*')
                        idx++
                    }
                }
                else -> {
                    append(text[idx])
                    idx++
                }
            }
        }
    }
}

private val codeKeywords = setOf(
    "fun", "val", "var", "class", "object", "interface", "data", "sealed", "enum",
    "return", "if", "else", "when", "for", "while", "import", "package", "suspend",
    "private", "public", "override", "def", "async", "await", "const", "let", "function",
    "SELECT", "FROM", "WHERE", "INSERT", "UPDATE", "DELETE", "true", "false", "null"
)

private fun highlightCode(code: String): AnnotatedString {
    val tokenRegex = Regex("(\"[^\"]*\"|'[^']*'|//[^\\n]*|#[^\\n]*|\\b[A-Za-z_][A-Za-z0-9_]*\\b|\\b\\d+(?:\\.\\d+)?\\b)")
    return buildAnnotatedString {
        var lastIdx = 0
        for (match in tokenRegex.findAll(code)) {
            if (match.range.first > lastIdx) {
                withStyle(SpanStyle(color = Color(0xFFE2E8F0))) {
                    append(code.substring(lastIdx, match.range.first))
                }
            }
            val token = match.value
            val color = when {
                token.startsWith("//") || token.startsWith("#") -> Color(0xFF64748B)
                token.startsWith("\"") || token.startsWith("'") -> Color(0xFF86EFAC)
                token in codeKeywords -> Color(0xFF93C5FD)
                token.first().isDigit() -> Color(0xFFFBBF24)
                token.first().isUpperCase() -> Color(0xFFC4B5FD)
                else -> Color(0xFFE2E8F0)
            }
            withStyle(SpanStyle(color = color)) {
                append(token)
            }
            lastIdx = match.range.last + 1
        }
        if (lastIdx < code.length) {
            withStyle(SpanStyle(color = Color(0xFFE2E8F0))) {
                append(code.substring(lastIdx))
            }
        }
    }
}
