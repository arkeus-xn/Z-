package pl.ultraai.android.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import pl.ultraai.android.domain.model.AiProvider
import pl.ultraai.android.domain.model.AppSettings
import pl.ultraai.android.domain.model.MessageStyle
import pl.ultraai.android.domain.model.SelectionMode
import pl.ultraai.android.domain.model.ThemePreset

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "ultra_ai_settings")

class SettingsDataStore(private val context: Context) {

    private object Keys {
        val DARK_THEME = booleanPreferencesKey("dark_theme")
        val THEME_PRESET = stringPreferencesKey("theme_preset")
        val ACCENT_COLOR_HEX = longPreferencesKey("accent_color_hex")
        val FONT_SCALE = floatPreferencesKey("font_scale")
        val ANIMATIONS_ENABLED = booleanPreferencesKey("animations_enabled")
        val MESSAGE_STYLE = stringPreferencesKey("message_style")

        val DEFAULT_PROVIDER = stringPreferencesKey("default_provider")
        val DEFAULT_MODEL_ID = stringPreferencesKey("default_model_id")
        val DEFAULT_TEMPERATURE = floatPreferencesKey("default_temperature")
        val MAX_OUTPUT_TOKENS = intPreferencesKey("max_output_tokens")
        val DEFAULT_SYSTEM_PROMPT = stringPreferencesKey("default_system_prompt")
        val SELECTION_MODE = stringPreferencesKey("selection_mode")
        val FAVORITE_MODEL_IDS = stringSetPreferencesKey("favorite_model_ids")

        val PIN_ENABLED = booleanPreferencesKey("pin_enabled")
        val PIN_HASH = stringPreferencesKey("pin_hash")
        val BIOMETRIC_ENABLED = booleanPreferencesKey("biometric_enabled")
        val DAILY_COST_LIMIT = doublePreferencesKey("daily_cost_limit_usd")
        val MONTHLY_COST_LIMIT = doublePreferencesKey("monthly_cost_limit_usd")
        val DAILY_REQUEST_LIMIT = intPreferencesKey("daily_request_limit")
        val CONFIRM_COST_THRESHOLD = doublePreferencesKey("confirm_cost_threshold_usd")
    }

    val settingsFlow: Flow<AppSettings> = context.settingsDataStore.data.map { prefs ->
        val defaults = AppSettings()
        AppSettings(
            darkTheme = prefs[Keys.DARK_THEME] ?: defaults.darkTheme,
            themePreset = prefs[Keys.THEME_PRESET]?.let { runCatching { ThemePreset.valueOf(it) }.getOrNull() } ?: defaults.themePreset,
            accentColorHex = prefs[Keys.ACCENT_COLOR_HEX] ?: defaults.accentColorHex,
            fontScale = prefs[Keys.FONT_SCALE] ?: defaults.fontScale,
            animationsEnabled = prefs[Keys.ANIMATIONS_ENABLED] ?: defaults.animationsEnabled,
            messageStyle = prefs[Keys.MESSAGE_STYLE]?.let { runCatching { MessageStyle.valueOf(it) }.getOrNull() } ?: defaults.messageStyle,
            defaultProvider = prefs[Keys.DEFAULT_PROVIDER]?.let { runCatching { AiProvider.valueOf(it) }.getOrNull() } ?: defaults.defaultProvider,
            defaultModelId = prefs[Keys.DEFAULT_MODEL_ID] ?: defaults.defaultModelId,
            defaultTemperature = prefs[Keys.DEFAULT_TEMPERATURE] ?: defaults.defaultTemperature,
            maxOutputTokens = prefs[Keys.MAX_OUTPUT_TOKENS] ?: defaults.maxOutputTokens,
            defaultSystemPrompt = prefs[Keys.DEFAULT_SYSTEM_PROMPT] ?: defaults.defaultSystemPrompt,
            selectionMode = prefs[Keys.SELECTION_MODE]?.let { runCatching { SelectionMode.valueOf(it) }.getOrNull() } ?: defaults.selectionMode,
            favoriteModelIds = prefs[Keys.FAVORITE_MODEL_IDS] ?: defaults.favoriteModelIds,
            pinEnabled = prefs[Keys.PIN_ENABLED] ?: defaults.pinEnabled,
            pinHash = prefs[Keys.PIN_HASH] ?: defaults.pinHash,
            biometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: defaults.biometricEnabled,
            dailyCostLimitUsd = prefs[Keys.DAILY_COST_LIMIT] ?: defaults.dailyCostLimitUsd,
            monthlyCostLimitUsd = prefs[Keys.MONTHLY_COST_LIMIT] ?: defaults.monthlyCostLimitUsd,
            dailyRequestLimit = prefs[Keys.DAILY_REQUEST_LIMIT] ?: defaults.dailyRequestLimit,
            confirmCostThresholdUsd = prefs[Keys.CONFIRM_COST_THRESHOLD] ?: defaults.confirmCostThresholdUsd
        )
    }

    suspend fun updateSettings(transform: (AppSettings) -> AppSettings) {
        context.settingsDataStore.edit { prefs ->
            val current = AppSettings(
                darkTheme = prefs[Keys.DARK_THEME] ?: true,
                themePreset = prefs[Keys.THEME_PRESET]?.let { runCatching { ThemePreset.valueOf(it) }.getOrNull() } ?: ThemePreset.OBSIDIAN,
                accentColorHex = prefs[Keys.ACCENT_COLOR_HEX] ?: 0xFF3B82F6,
                fontScale = prefs[Keys.FONT_SCALE] ?: 1.0f,
                animationsEnabled = prefs[Keys.ANIMATIONS_ENABLED] ?: true,
                messageStyle = prefs[Keys.MESSAGE_STYLE]?.let { runCatching { MessageStyle.valueOf(it) }.getOrNull() } ?: MessageStyle.MODERN,
                defaultProvider = prefs[Keys.DEFAULT_PROVIDER]?.let { runCatching { AiProvider.valueOf(it) }.getOrNull() } ?: AiProvider.GEMINI,
                defaultModelId = prefs[Keys.DEFAULT_MODEL_ID] ?: "",
                defaultTemperature = prefs[Keys.DEFAULT_TEMPERATURE] ?: 0.7f,
                maxOutputTokens = prefs[Keys.MAX_OUTPUT_TOKENS] ?: 4096,
                defaultSystemPrompt = prefs[Keys.DEFAULT_SYSTEM_PROMPT] ?: AppSettings().defaultSystemPrompt,
                selectionMode = prefs[Keys.SELECTION_MODE]?.let { runCatching { SelectionMode.valueOf(it) }.getOrNull() } ?: SelectionMode.AUTO,
                favoriteModelIds = prefs[Keys.FAVORITE_MODEL_IDS] ?: emptySet(),
                pinEnabled = prefs[Keys.PIN_ENABLED] ?: false,
                pinHash = prefs[Keys.PIN_HASH] ?: "",
                biometricEnabled = prefs[Keys.BIOMETRIC_ENABLED] ?: false,
                dailyCostLimitUsd = prefs[Keys.DAILY_COST_LIMIT] ?: 2.0,
                monthlyCostLimitUsd = prefs[Keys.MONTHLY_COST_LIMIT] ?: 25.0,
                dailyRequestLimit = prefs[Keys.DAILY_REQUEST_LIMIT] ?: 250,
                confirmCostThresholdUsd = prefs[Keys.CONFIRM_COST_THRESHOLD] ?: 0.02
            )
            val updated = transform(current)
            prefs[Keys.DARK_THEME] = updated.darkTheme
            prefs[Keys.THEME_PRESET] = updated.themePreset.name
            prefs[Keys.ACCENT_COLOR_HEX] = updated.accentColorHex
            prefs[Keys.FONT_SCALE] = updated.fontScale
            prefs[Keys.ANIMATIONS_ENABLED] = updated.animationsEnabled
            prefs[Keys.MESSAGE_STYLE] = updated.messageStyle.name
            prefs[Keys.DEFAULT_PROVIDER] = updated.defaultProvider.name
            prefs[Keys.DEFAULT_MODEL_ID] = updated.defaultModelId
            prefs[Keys.DEFAULT_TEMPERATURE] = updated.defaultTemperature
            prefs[Keys.MAX_OUTPUT_TOKENS] = updated.maxOutputTokens
            prefs[Keys.DEFAULT_SYSTEM_PROMPT] = updated.defaultSystemPrompt
            prefs[Keys.SELECTION_MODE] = updated.selectionMode.name
            prefs[Keys.FAVORITE_MODEL_IDS] = updated.favoriteModelIds
            prefs[Keys.PIN_ENABLED] = updated.pinEnabled
            prefs[Keys.PIN_HASH] = updated.pinHash
            prefs[Keys.BIOMETRIC_ENABLED] = updated.biometricEnabled
            prefs[Keys.DAILY_COST_LIMIT] = updated.dailyCostLimitUsd
            prefs[Keys.MONTHLY_COST_LIMIT] = updated.monthlyCostLimitUsd
            prefs[Keys.DAILY_REQUEST_LIMIT] = updated.dailyRequestLimit
            prefs[Keys.CONFIRM_COST_THRESHOLD] = updated.confirmCostThresholdUsd
        }
    }

    suspend fun resetDefaults() {
        context.settingsDataStore.edit { it.clear() }
    }
}
