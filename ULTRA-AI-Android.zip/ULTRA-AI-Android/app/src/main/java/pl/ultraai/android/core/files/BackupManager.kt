package pl.ultraai.android.core.files

import android.content.Context
import android.net.Uri
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import pl.ultraai.android.data.local.UltraAiDatabase
import pl.ultraai.android.data.local.entity.AiCharacterEntity
import pl.ultraai.android.data.local.entity.ChatMessageEntity
import pl.ultraai.android.data.local.entity.ChatSessionEntity
import pl.ultraai.android.data.local.entity.FolderEntity
import pl.ultraai.android.data.local.entity.PromptTemplateEntity
import pl.ultraai.android.data.local.entity.UsageLogEntity

@Serializable
data class UltraAiBackupPayload(
    val exportedAt: Long = System.currentTimeMillis(),
    val appVersion: String = "1.0.0",
    val folders: List<FolderEntity>,
    val sessions: List<ChatSessionEntity>,
    val messages: List<ChatMessageEntity>,
    val characters: List<AiCharacterEntity>,
    val prompts: List<PromptTemplateEntity>,
    val usageLogs: List<UsageLogEntity>
)

/**
 * Eksportuje i importuje dane użytkownika w formacie JSON.
 * Ze względów bezpieczeństwa klucze API NIE są eksportowane w jawnym pliku kopii zapasowej.
 */
class BackupManager(private val context: Context, private val db: UltraAiDatabase) {

    private val json = Json {
        prettyPrint = true
        ignoreUnknownKeys = true
    }

    suspend fun exportToUri(uri: Uri): Result<String> = runCatching {
        val payload = UltraAiBackupPayload(
            folders = db.folderDao().getAllOnce(),
            sessions = db.chatDao().getAllSessionsOnce(),
            messages = db.chatDao().getAllMessagesOnce(),
            characters = db.characterDao().getAllOnce(),
            prompts = db.promptDao().getAllOnce(),
            usageLogs = db.usageAndDiagnosticDao().getAllUsageOnce()
        )
        val serialized = json.encodeToString(payload)
        context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
            it.write(serialized)
        } ?: error("Nie można zapisać pliku kopii zapasowej.")
        "Wyeksportowano ${payload.sessions.size} rozmów, ${payload.characters.size} postaci i ${payload.prompts.size} promptów (bez kluczy API)."
    }

    suspend fun importFromUri(uri: Uri): Result<String> = runCatching {
        val raw = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use {
            it.readText()
        } ?: error("Nie można odczytać pliku kopii zapasowej.")
        val payload = json.decodeFromString<UltraAiBackupPayload>(raw)

        val folderIdMap = mutableMapOf<Long, Long>()
        payload.folders.forEach { folder ->
            val newId = db.folderDao().insert(folder.copy(id = 0))
            folderIdMap[folder.id] = newId
        }

        val sessionIdMap = mutableMapOf<Long, Long>()
        payload.sessions.forEach { session ->
            val mappedFolder = session.folderId?.let { folderIdMap[it] }
            val newId = db.chatDao().insertSession(session.copy(id = 0, folderId = mappedFolder))
            sessionIdMap[session.id] = newId
        }

        payload.messages.forEach { msg ->
            val newSessionId = sessionIdMap[msg.sessionId] ?: return@forEach
            db.chatDao().insertMessage(msg.copy(id = 0, sessionId = newSessionId))
        }

        payload.characters.filter { !it.isBuiltIn }.forEach { char ->
            db.characterDao().insert(char.copy(id = 0))
        }

        payload.prompts.forEach { prompt ->
            db.promptDao().insert(prompt.copy(id = 0))
        }

        "Zaimportowano ${payload.sessions.size} rozmów oraz ${payload.prompts.size} szablonów."
    }
}
