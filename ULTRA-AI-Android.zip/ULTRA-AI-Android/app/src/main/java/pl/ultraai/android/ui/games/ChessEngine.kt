package pl.ultraai.android.ui.games

import kotlin.math.abs

enum class ChessColor { WHITE, BLACK; fun opposite() = if (this == WHITE) BLACK else WHITE }
enum class PieceType(val value: Int, val whiteSymbol: String, val blackSymbol: String) {
    PAWN(100, "♙", "♟"),
    KNIGHT(320, "♘", "♞"),
    BISHOP(330, "♗", "♝"),
    ROOK(500, "♖", "♜"),
    QUEEN(900, "♕", "♛"),
    KING(20000, "♔", "♚")
}

data class ChessPiece(val type: PieceType, val color: ChessColor) {
    val symbol: String get() = if (color == ChessColor.WHITE) type.whiteSymbol else type.blackSymbol
}

data class ChessMove(
    val fromRow: Int,
    val fromCol: Int,
    val toRow: Int,
    val toCol: Int,
    val isPromotion: Boolean = false
) {
    fun toUci(): String {
        val files = "abcdefgh"
        val r1 = 8 - fromRow
        val r2 = 8 - toRow
        return "${files[fromCol]}$r1${files[toCol]}$r2${if (isPromotion) "q" else ""}"
    }
}

data class ChessGameState(
    val board: List<List<ChessPiece?>>,
    val turn: ChessColor = ChessColor.WHITE,
    val whiteKingMoved: Boolean = false,
    val blackKingMoved: Boolean = false,
    val whiteRookA: Boolean = false,
    val whiteRookH: Boolean = false,
    val blackRookA: Boolean = false,
    val blackRookH: Boolean = false,
    val enPassantTarget: Pair<Int, Int>? = null,
    val moveHistory: List<String> = emptyList(),
    val statusText: String = "Twój ruch (Białe)",
    val isGameOver: Boolean = false
)

/**
 * Pełny, deterministyczny silnik szachowy z walidacją szacha, mata, pata, roszady, bicia w przelocie i promocji.
 */
object ChessEngine {

    fun initialState(): ChessGameState {
        val b = MutableList(8) { MutableList<ChessPiece?>(8) { null } }
        val backRow = listOf(PieceType.ROOK, PieceType.KNIGHT, PieceType.BISHOP, PieceType.QUEEN, PieceType.KING, PieceType.BISHOP, PieceType.KNIGHT, PieceType.ROOK)
        for (c in 0..7) {
            b[0][c] = ChessPiece(backRow[c], ChessColor.BLACK)
            b[1][c] = ChessPiece(PieceType.PAWN, ChessColor.BLACK)
            b[6][c] = ChessPiece(PieceType.PAWN, ChessColor.WHITE)
            b[7][c] = ChessPiece(backRow[c], ChessColor.WHITE)
        }
        return ChessGameState(board = b.map { it.toList() })
    }

    fun legalMoves(state: ChessGameState): List<ChessMove> {
        val pseudo = mutableListOf<ChessMove>()
        for (r in 0..7) {
            for (c in 0..7) {
                val p = state.board[r][c] ?: continue
                if (p.color == state.turn) {
                    pseudo.addAll(pseudoLegalForPiece(state, r, c, p))
                }
            }
        }
        return pseudo.filter { move ->
            val next = applyUnchecked(state, move)
            !isKingInCheck(next.board, state.turn)
        }
    }

    fun applyMove(state: ChessGameState, move: ChessMove): ChessGameState {
        val valid = legalMoves(state)
        if (move !in valid) return state
        val next = applyUnchecked(state, move)
        val nextLegal = legalMoves(next)
        val inCheck = isKingInCheck(next.board, next.turn)
        val status = when {
            nextLegal.isEmpty() && inCheck ->
                if (state.turn == ChessColor.WHITE) "Szach-mat! Wygrywasz!" else "Szach-mat! Wygrywa AI!"
            nextLegal.isEmpty() -> "Pat! Remis."
            inCheck -> if (next.turn == ChessColor.WHITE) "Szach! Twój ruch (Białe)" else "Szach! Ruch AI (Czarne)"
            else -> if (next.turn == ChessColor.WHITE) "Twój ruch (Białe)" else "Ruch AI (Czarne)"
        }
        return next.copy(
            moveHistory = state.moveHistory + move.toUci(),
            statusText = status,
            isGameOver = nextLegal.isEmpty()
        )
    }

    fun pickBestHeuristicMove(state: ChessGameState): ChessMove? {
        val moves = legalMoves(state)
        if (moves.isEmpty()) return null
        return moves.minByOrNull { move ->
            val after = applyUnchecked(state, move)
            evaluateMaterial(after.board)
        }
    }

    private fun evaluateMaterial(board: List<List<ChessPiece?>>): Int {
        var score = 0
        for (r in 0..7) {
            for (c in 0..7) {
                val p = board[r][c] ?: continue
                val sign = if (p.color == ChessColor.WHITE) 1 else -1
                score += sign * p.type.value
            }
        }
        return score
    }

    private fun applyUnchecked(state: ChessGameState, move: ChessMove): ChessGameState {
        val grid = state.board.map { it.toMutableList() }.toMutableList()
        val moving = grid[move.fromRow][move.fromCol]!!
        grid[move.fromRow][move.fromCol] = null

        // Bicie w przelocie
        if (moving.type == PieceType.PAWN && state.enPassantTarget == (move.toRow to move.toCol)) {
            grid[move.fromRow][move.toCol] = null
        }

        // Roszada
        if (moving.type == PieceType.KING && abs(move.toCol - move.fromCol) == 2) {
            if (move.toCol == 6) {
                grid[move.fromRow][5] = grid[move.fromRow][7]
                grid[move.fromRow][7] = null
            } else if (move.toCol == 2) {
                grid[move.fromRow][3] = grid[move.fromRow][0]
                grid[move.fromRow][0] = null
            }
        }

        val placed = if (move.isPromotion) ChessPiece(PieceType.QUEEN, moving.color) else moving
        grid[move.toRow][move.toCol] = placed

        val newEp = if (moving.type == PieceType.PAWN && abs(move.toRow - move.fromRow) == 2) {
            ((move.fromRow + move.toRow) / 2) to move.fromCol
        } else null

        return state.copy(
            board = grid.map { it.toList() },
            turn = state.turn.opposite(),
            whiteKingMoved = state.whiteKingMoved || (moving.color == ChessColor.WHITE && moving.type == PieceType.KING),
            blackKingMoved = state.blackKingMoved || (moving.color == ChessColor.BLACK && moving.type == PieceType.KING),
            whiteRookA = state.whiteRookA || (move.fromRow == 7 && move.fromCol == 0),
            whiteRookH = state.whiteRookH || (move.fromRow == 7 && move.fromCol == 7),
            blackRookA = state.blackRookA || (move.fromRow == 0 && move.fromCol == 0),
            blackRookH = state.blackRookH || (move.fromRow == 0 && move.fromCol == 7),
            enPassantTarget = newEp
        )
    }

    private fun isKingInCheck(board: List<List<ChessPiece?>>, kingColor: ChessColor): Boolean {
        var kr = -1
        var kc = -1
        for (r in 0..7) for (c in 0..7) {
            val p = board[r][c]
            if (p?.color == kingColor && p.type == PieceType.KING) {
                kr = r; kc = c
            }
        }
        if (kr == -1) return true
        return isSquareAttacked(board, kr, kc, kingColor.opposite())
    }

    private fun isSquareAttacked(board: List<List<ChessPiece?>>, r: Int, c: Int, byColor: ChessColor): Boolean {
        val pawnDir = if (byColor == ChessColor.WHITE) 1 else -1
        for (dc in listOf(-1, 1)) {
            val pr = r + pawnDir
            val pc = c + dc
            if (pr in 0..7 && pc in 0..7) {
                val p = board[pr][pc]
                if (p?.color == byColor && p.type == PieceType.PAWN) return true
            }
        }
        val knightOffsets = listOf(-2 to -1, -2 to 1, -1 to -2, -1 to 2, 1 to -2, 1 to 2, 2 to -1, 2 to 1)
        for ((dr, dc) in knightOffsets) {
            val nr = r + dr; val nc = c + dc
            if (nr in 0..7 && nc in 0..7) {
                val p = board[nr][nc]
                if (p?.color == byColor && p.type == PieceType.KNIGHT) return true
            }
        }
        val straight = listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1)
        for ((dr, dc) in straight) {
            var nr = r + dr; var nc = c + dc
            while (nr in 0..7 && nc in 0..7) {
                val p = board[nr][nc]
                if (p != null) {
                    if (p.color == byColor && (p.type == PieceType.ROOK || p.type == PieceType.QUEEN)) return true
                    break
                }
                nr += dr; nc += dc
            }
        }
        val diag = listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1)
        for ((dr, dc) in diag) {
            var nr = r + dr; var nc = c + dc
            while (nr in 0..7 && nc in 0..7) {
                val p = board[nr][nc]
                if (p != null) {
                    if (p.color == byColor && (p.type == PieceType.BISHOP || p.type == PieceType.QUEEN)) return true
                    break
                }
                nr += dr; nc += dc
            }
        }
        for (dr in -1..1) for (dc in -1..1) {
            if (dr == 0 && dc == 0) continue
            val nr = r + dr; val nc = c + dc
            if (nr in 0..7 && nc in 0..7) {
                val p = board[nr][nc]
                if (p?.color == byColor && p.type == PieceType.KING) return true
            }
        }
        return false
    }

    private fun pseudoLegalForPiece(state: ChessGameState, r: Int, c: Int, piece: ChessPiece): List<ChessMove> {
        val out = mutableListOf<ChessMove>()
        val board = state.board
        when (piece.type) {
            PieceType.PAWN -> {
                val dir = if (piece.color == ChessColor.WHITE) -1 else 1
                val startRow = if (piece.color == ChessColor.WHITE) 6 else 1
                val promoRow = if (piece.color == ChessColor.WHITE) 0 else 7
                val nr = r + dir
                if (nr in 0..7 && board[nr][c] == null) {
                    out.add(ChessMove(r, c, nr, c, isPromotion = nr == promoRow))
                    val nr2 = r + dir * 2
                    if (r == startRow && board[nr2][c] == null) {
                        out.add(ChessMove(r, c, nr2, c))
                    }
                }
                for (dc in listOf(-1, 1)) {
                    val nc = c + dc
                    if (nr in 0..7 && nc in 0..7) {
                        val target = board[nr][nc]
                        if (target != null && target.color != piece.color) {
                            out.add(ChessMove(r, c, nr, nc, isPromotion = nr == promoRow))
                        } else if (state.enPassantTarget == (nr to nc)) {
                            out.add(ChessMove(r, c, nr, nc))
                        }
                    }
                }
            }
            PieceType.KNIGHT -> {
                val offsets = listOf(-2 to -1, -2 to 1, -1 to -2, -1 to 2, 1 to -2, 1 to 2, 2 to -1, 2 to 1)
                for ((dr, dc) in offsets) {
                    val nr = r + dr; val nc = c + dc
                    if (nr in 0..7 && nc in 0..7 && board[nr][nc]?.color != piece.color) {
                        out.add(ChessMove(r, c, nr, nc))
                    }
                }
            }
            PieceType.BISHOP -> addSliding(board, r, c, piece.color, listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1), out)
            PieceType.ROOK -> addSliding(board, r, c, piece.color, listOf(-1 to 0, 1 to 0, 0 to -1, 0 to 1), out)
            PieceType.QUEEN -> addSliding(board, r, c, piece.color, listOf(-1 to -1, -1 to 1, 1 to -1, 1 to 1, -1 to 0, 1 to 0, 0 to -1, 0 to 1), out)
            PieceType.KING -> {
                for (dr in -1..1) for (dc in -1..1) {
                    if (dr == 0 && dc == 0) continue
                    val nr = r + dr; val nc = c + dc
                    if (nr in 0..7 && nc in 0..7 && board[nr][nc]?.color != piece.color) {
                        out.add(ChessMove(r, c, nr, nc))
                    }
                }
                // Roszada
                val kingMoved = if (piece.color == ChessColor.WHITE) state.whiteKingMoved else state.blackKingMoved
                if (!kingMoved && !isKingInCheck(board, piece.color)) {
                    val rookHMoved = if (piece.color == ChessColor.WHITE) state.whiteRookH else state.blackRookH
                    if (!rookHMoved && board[r][5] == null && board[r][6] == null &&
                        !isSquareAttacked(board, r, 5, piece.color.opposite()) &&
                        !isSquareAttacked(board, r, 6, piece.color.opposite())
                    ) {
                        out.add(ChessMove(r, c, r, 6))
                    }
                    val rookAMoved = if (piece.color == ChessColor.WHITE) state.whiteRookA else state.blackRookA
                    if (!rookAMoved && board[r][3] == null && board[r][2] == null && board[r][1] == null &&
                        !isSquareAttacked(board, r, 3, piece.color.opposite()) &&
                        !isSquareAttacked(board, r, 2, piece.color.opposite())
                    ) {
                        out.add(ChessMove(r, c, r, 2))
                    }
                }
            }
        }
        return out
    }

    private fun addSliding(
        board: List<List<ChessPiece?>>,
        r: Int,
        c: Int,
        color: ChessColor,
        dirs: List<Pair<Int, Int>>,
        out: MutableList<ChessMove>
    ) {
        for ((dr, dc) in dirs) {
            var nr = r + dr; var nc = c + dc
            while (nr in 0..7 && nc in 0..7) {
                val target = board[nr][nc]
                if (target == null) {
                    out.add(ChessMove(r, c, nr, nc))
                } else {
                    if (target.color != color) out.add(ChessMove(r, c, nr, nc))
                    break
                }
                nr += dr; nc += dc
            }
        }
    }
}
