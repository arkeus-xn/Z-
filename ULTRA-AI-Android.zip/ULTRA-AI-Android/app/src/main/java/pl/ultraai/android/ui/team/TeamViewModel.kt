package pl.ultraai.android.ui.team

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import pl.ultraai.android.AppContainer
import pl.ultraai.android.data.remote.AiTurnMessage
import pl.ultraai.android.domain.model.AiModelInfo

enum class TeamRole(
    val titlePl: String,
    val instructionPl: String
) {
    ARCHITECT(
        titlePl = "Architekt",
        instructionPl = "Zaprojektuj architekturę rozwiązania, strukturę modułów, przepływ danych i kluczowe decyzje techniczne."
    ),
    ANALYST(
        titlePl = "Analityk",
        instructionPl = "Przeanalizuj wymagania, przypadki brzegowe, ryzyka, zależności oraz kryteria akceptacji."
    ),
    PROGRAMMER(
        titlePl = "Programista",
        instructionPl = "Na podstawie pracy Architekta i Analityka przygotuj kompletny, czysty i gotowy kod lub rozwiązanie implementacyjne."
    ),
    TESTER(
        titlePl = "Tester",
        instructionPl = "Zweryfikuj kod i projekt pod kątem błędów logicznych, testów jednostkowych, bezpieczeństwa i scenariuszy brzegowych."
    ),
    REVIEWER(
        titlePl = "Recenzent",
        instructionPl = "Dokonaj końcowej recenzji pracy zespołu, wskaż poprawki i przedstaw finalne, dopracowane podsumowanie."
    )
}

data class TeamMemberConfig(
    val role: TeamRole,
    val enabled: Boolean = true,
    val modelId: String = ""
)

data class TeamStepOutput(
    val role: TeamRole,
    val modelName: String,
    val output: String,
    val latencyMs: Long,
    val tokens: Int,
    val costUsd: Double?,
    val isError: Boolean = false
)

data class TeamUiState(
    val availableModels: List<AiModelInfo> = emptyList(),
    val members: List<TeamMemberConfig> = TeamRole.entries.map { TeamMemberConfig(it) },
    val taskBrief: String = "",
    val isRunning: Boolean = false,
    val activeRole: TeamRole? = null,
    val outputs: List<TeamStepOutput> = emptyList(),
    val error: String? = null
)

class TeamViewModel(private val container: AppContainer) : ViewModel() {

    private val members = MutableStateFlow(TeamRole.entries.map { TeamMemberConfig(it) })
    private val taskBrief = MutableStateFlow("")
    private val isRunning = MutableStateFlow(false)
    private val activeRole = MutableStateFlow<TeamRole?>(null)
    private val outputs = MutableStateFlow<List<TeamStepOutput>>(emptyList())
    private val error = MutableStateFlow<String?>(null)
    private var pipelineJob: Job? = null

    val uiState: StateFlow<TeamUiState> = combine(
        listOf<Flow<Any?>>(
            container.apiKeyAndModelRepo.discoveredModels,
            members,
            taskBrief,
            isRunning,
            activeRole,
            outputs,
            error
        )
    ) { arr ->
        @Suppress("UNCHECKED_CAST")
        val models = arr[0] as List<AiModelInfo>
        @Suppress("UNCHECKED_CAST")
        val rawMembers = arr[1] as List<TeamMemberConfig>
        val defaultModelId = models.firstOrNull()?.id.orEmpty()
        val resolvedMembers = rawMembers.map { m ->
            if (m.modelId.isBlank() && defaultModelId.isNotBlank()) m.copy(modelId = defaultModelId) else m
        }
        TeamUiState(
            availableModels = models,
            members = resolvedMembers,
            taskBrief = arr[2] as String,
            isRunning = arr[3] as Boolean,
            activeRole = arr[4] as TeamRole?,
            outputs = arr[5] as List<TeamStepOutput>,
            error = arr[6] as String?
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), TeamUiState())

    fun updateTaskBrief(text: String) {
        taskBrief.value = text
    }

    fun toggleRole(role: TeamRole) {
        members.value = uiState.value.members.map {
            if (it.role == role) it.copy(enabled = !it.enabled) else it
        }
    }

    fun assignModel(role: TeamRole, modelId: String) {
        members.value = uiState.value.members.map {
            if (it.role == role) it.copy(modelId = modelId) else it
        }
    }

    fun runTeamPipeline() {
        val state = uiState.value
        if (state.taskBrief.isBlank()) {
            error.value = "Opisz zadanie dla zespołu modeli AI."
            return
        }
        val activeMembers = state.members.filter { it.enabled }
        if (activeMembers.isEmpty()) {
            error.value = "Włącz co najmniej jedną rolę w zespole."
            return
        }
        if (state.availableModels.isEmpty()) {
            error.value = "Brak dostępnych modeli. Skonfiguruj klucz API w Ustawieniach."
            return
        }

        pipelineJob?.cancel()
        pipelineJob = viewModelScope.launch {
            isRunning.value = true
            outputs.value = emptyList()
            error.value = null

            val sharedContext = StringBuilder()
            sharedContext.appendLine("=== ZADANIE GŁÓWNE ===")
            sharedContext.appendLine(state.taskBrief)

            for (member in activeMembers) {
                activeRole.value = member.role
                val model = state.availableModels.firstOrNull { it.id == member.modelId }
                    ?: state.availableModels.first()
                val key = container.apiKeyAndModelRepo.getDecryptedActiveKey(model.provider).orEmpty()

                val promptForRole = buildString {
                    appendLine(sharedContext.toString())
                    appendLine()
                    appendLine("=== TWOJA ROLA: ${member.role.titlePl.uppercase()} ===")
                    appendLine(member.role.instructionPl)
                    appendLine("Odpowiedz po polsku i przekaż konkretny wynik kolejnemu członkowi zespołu.")
                }

                val res = container.aiGateway.completeOnce(
                    model = model,
                    apiKey = key,
                    systemPrompt = "Pracujesz jako ${member.role.titlePl} w zespole inżynierskim ULTRA AI.",
                    messages = listOf(AiTurnMessage("user", promptForRole)),
                    temperature = 0.45f,
                    maxOutputTokens = 2500
                )

                container.usageRepo.logUsage(
                    featureName = "AI Team (${member.role.titlePl})",
                    provider = model.provider,
                    modelId = model.id,
                    inputTokens = res.inputTokens,
                    outputTokens = res.outputTokens,
                    estimatedCostUsd = res.estimatedCostUsd,
                    latencyMs = res.latencyMs
                )

                val stepText = if (res.isError) (res.errorMessage ?: "Błąd wykonania roli") else res.text
                outputs.value = outputs.value + TeamStepOutput(
                    role = member.role,
                    modelName = model.displayName,
                    output = stepText,
                    latencyMs = res.latencyMs,
                    tokens = res.inputTokens + res.outputTokens,
                    costUsd = res.estimatedCostUsd,
                    isError = res.isError
                )

                if (!res.isError) {
                    sharedContext.appendLine()
                    sharedContext.appendLine("=== WYNIK ROLI: ${member.role.titlePl} (${model.displayName}) ===")
                    sharedContext.appendLine(stepText.take(5000))
                }
            }

            activeRole.value = null
            isRunning.value = false
        }
    }

    fun stopPipeline() {
        pipelineJob?.cancel()
        isRunning.value = false
        activeRole.value = null
    }
}
