package pl.ultraai.android.domain.model

import kotlinx.serialization.Serializable

@Serializable
enum class AiProvider(
    val displayName: String,
    val baseUrl: String,
    val docsUrl: String
) {
    GEMINI(
        displayName = "Google Gemini",
        baseUrl = "https://generativelanguage.googleapis.com/v1beta",
        docsUrl = "https://ai.google.dev/gemini-api/docs/models"
    ),
    GROQ(
        displayName = "Groq",
        baseUrl = "https://api.groq.com/openai/v1",
        docsUrl = "https://console.groq.com/docs/models"
    )
}

@Serializable
enum class SelectionMode(val labelPl: String, val descriptionPl: String) {
    AUTO(
        labelPl = "Automatyczny",
        descriptionPl = "Dobierz model optymalny dla zadania (jakość, koszt, długość kontekstu i załączniki)"
    ),
    MANUAL(
        labelPl = "Ręczny",
        descriptionPl = "Używaj dokładnie wybranego przez Ciebie modelu"
    ),
    CHEAPEST(
        labelPl = "Najtańszy odpowiedni",
        descriptionPl = "Wybierz najtańszy model spełniający wymagania kontekstu i możliwości"
    ),
    BEST_QUALITY(
        labelPl = "Najlepsza jakość",
        descriptionPl = "Priorytet maksymalnej jakości rozumowania i złożoności odpowiedzi"
    ),
    FASTEST(
        labelPl = "Najszybszy",
        descriptionPl = "Priorytet minimalnych opóźnień (np. modele Groq LPU lub Flash-Lite)"
    )
}

@Serializable
enum class ModelCapability(val labelPl: String) {
    TEXT("Tekst"),
    VISION("Obrazy"),
    CODE("Kod"),
    REASONING("Rozumowanie"),
    STREAMING("Streaming"),
    LONG_CONTEXT("Długi kontekst")
}

@Serializable
data class AiModelInfo(
    val id: String,
    val displayName: String,
    val provider: AiProvider,
    val description: String = "",
    val inputContextLimit: Int? = null,
    val outputTokenLimit: Int? = null,
    val inputPricePer1MUsd: Double? = null,
    val outputPricePer1MUsd: Double? = null,
    val freeTierInfo: String = "Brak danych",
    val capabilities: Set<ModelCapability> = setOf(ModelCapability.TEXT, ModelCapability.STREAMING),
    val isAvailable: Boolean = true,
    val isFavorite: Boolean = false,
    val speedTier: Int = 2, // 1 = wolniejszy/cięższy, 2 = zbalansowany, 3 = ultra szybki
    val qualityTier: Int = 2 // 1 = podstawowy, 2 = wysoki, 3 = flagowy
) {
    val hasVerifiedPricing: Boolean
        get() = inputPricePer1MUsd != null && outputPricePer1MUsd != null
}
