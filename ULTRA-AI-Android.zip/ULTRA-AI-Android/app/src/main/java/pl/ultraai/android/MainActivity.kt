package pl.ultraai.android

import android.os.Bundle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Casino
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Face
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import pl.ultraai.android.ui.battle.BattleScreen
import pl.ultraai.android.ui.battle.BattleViewModel
import pl.ultraai.android.ui.characters.CharactersScreen
import pl.ultraai.android.ui.characters.CharactersViewModel
import pl.ultraai.android.ui.chat.ChatScreen
import pl.ultraai.android.ui.chat.ChatViewModel
import pl.ultraai.android.ui.games.GameCenterScreen
import pl.ultraai.android.ui.games.GameCenterViewModel
import pl.ultraai.android.ui.settings.PinLockScreen
import pl.ultraai.android.ui.settings.SettingsScreen
import pl.ultraai.android.ui.settings.SettingsViewModel
import pl.ultraai.android.ui.team.TeamScreen
import pl.ultraai.android.ui.team.TeamViewModel
import pl.ultraai.android.ui.theme.UltraAiTheme
import pl.ultraai.android.ui.tools.ToolsScreen
import pl.ultraai.android.ui.tools.ToolsViewModel

sealed class UltraRoute(val route: String, val label: String) {
    data object Chat : UltraRoute("chat", "Czaty")
    data object Battle : UltraRoute("battle", "Bitwa")
    data object Team : UltraRoute("team", "Zespół")
    data object Games : UltraRoute("games", "Gry")
    data object Hub : UltraRoute("hub", "Moduły")
    data object Characters : UltraRoute("characters", "Postacie")
    data object Tools : UltraRoute("tools", "Narzędzia")
    data object Settings : UltraRoute("settings", "Ustawienia")
}

class UltraViewModelFactory(private val container: AppContainer) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(ChatViewModel::class.java) -> ChatViewModel(container) as T
            modelClass.isAssignableFrom(BattleViewModel::class.java) -> BattleViewModel(container) as T
            modelClass.isAssignableFrom(TeamViewModel::class.java) -> TeamViewModel(container) as T
            modelClass.isAssignableFrom(CharactersViewModel::class.java) -> CharactersViewModel(container) as T
            modelClass.isAssignableFrom(GameCenterViewModel::class.java) -> GameCenterViewModel(container) as T
            modelClass.isAssignableFrom(ToolsViewModel::class.java) -> ToolsViewModel(container) as T
            modelClass.isAssignableFrom(SettingsViewModel::class.java) -> SettingsViewModel(container) as T
            else -> throw IllegalArgumentException("Nieznany ViewModel: ${modelClass.name}")
        }
    }
}

class MainActivity : FragmentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val app = application as UltraAiApplication
        val factory = UltraViewModelFactory(app.container)

        val chatVm = ViewModelProvider(this, factory)[ChatViewModel::class.java]
        val battleVm = ViewModelProvider(this, factory)[BattleViewModel::class.java]
        val teamVm = ViewModelProvider(this, factory)[TeamViewModel::class.java]
        val charsVm = ViewModelProvider(this, factory)[CharactersViewModel::class.java]
        val gamesVm = ViewModelProvider(this, factory)[GameCenterViewModel::class.java]
        val toolsVm = ViewModelProvider(this, factory)[ToolsViewModel::class.java]
        val settingsVm = ViewModelProvider(this, factory)[SettingsViewModel::class.java]

        setContent {
            val settings by app.container.settingsStore.settingsFlow.collectAsState(initial = pl.ultraai.android.domain.model.AppSettings())
            var unlocked by remember(settings.pinEnabled) { mutableStateOf(!settings.pinEnabled) }
            var settingsTab by remember { mutableIntStateOf(0) }

            LaunchedEffect(settings.pinEnabled, settings.biometricEnabled) {
                if (settings.pinEnabled && settings.biometricEnabled && !unlocked) {
                    launchBiometricPrompt { unlocked = true }
                }
            }

            UltraAiTheme(
                darkTheme = settings.darkTheme,
                themePreset = settings.themePreset,
                accentColorHex = settings.accentColorHex,
                fontScale = settings.fontScale
            ) {
                if (settings.pinEnabled && !unlocked) {
                    PinLockScreen(
                        pinHash = settings.pinHash,
                        biometricEnabled = settings.biometricEnabled,
                        onUnlocked = { unlocked = true },
                        onRequestBiometric = { launchBiometricPrompt { unlocked = true } }
                    )
                } else {
                    UltraAiRootScaffold(
                        chatVm = chatVm,
                        battleVm = battleVm,
                        teamVm = teamVm,
                        charsVm = charsVm,
                        gamesVm = gamesVm,
                        toolsVm = toolsVm,
                        settingsVm = settingsVm,
                        appContainer = app.container,
                        settingsInitialTab = settingsTab,
                        onOpenSettingsTab = { tab -> settingsTab = tab }
                    )
                }
            }
        }
    }

    private fun launchBiometricPrompt(onSuccess: () -> Unit) {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }
            }
        )
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Odblokuj ULTRA AI")
            .setSubtitle("Użyj biometrii urządzenia")
            .setNegativeButtonText("Użyj kodu PIN")
            .build()
        prompt.authenticate(info)
    }

    override fun onDestroy() {
        super.onDestroy()
        (application as? UltraAiApplication)?.container?.speechAndTtsManager?.release()
    }
}

@Composable
private fun UltraAiRootScaffold(
    chatVm: ChatViewModel,
    battleVm: BattleViewModel,
    teamVm: TeamViewModel,
    charsVm: CharactersViewModel,
    gamesVm: GameCenterViewModel,
    toolsVm: ToolsViewModel,
    settingsVm: SettingsViewModel,
    appContainer: AppContainer,
    settingsInitialTab: Int,
    onOpenSettingsTab: (Int) -> Unit
) {
    val navController = rememberNavController()
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    val navItems = listOf(
        Triple(UltraRoute.Chat, Icons.Outlined.Chat, "Czaty"),
        Triple(UltraRoute.Battle, Icons.Outlined.AutoAwesome, "Bitwa"),
        Triple(UltraRoute.Team, Icons.Outlined.Groups, "Zespół"),
        Triple(UltraRoute.Games, Icons.Outlined.Casino, "Gry"),
        Triple(UltraRoute.Hub, Icons.Outlined.Apps, "Moduły")
    )

    Scaffold(
        bottomBar = {
            NavigationBar {
                navItems.forEach { (routeObj, icon, title) ->
                    val isSelected = currentRoute == routeObj.route ||
                        (routeObj == UltraRoute.Hub && currentRoute in setOf(
                            UltraRoute.Characters.route,
                            UltraRoute.Tools.route,
                            UltraRoute.Settings.route
                        ))
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            navController.navigate(routeObj.route) {
                                popUpTo(UltraRoute.Chat.route) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(icon, contentDescription = title) },
                        label = { Text(title, maxLines = 1) }
                    )
                }
            }
        }
    ) { padding ->
        Box(modifier = Modifier.padding(padding)) {
            NavHost(
                navController = navController,
                startDestination = UltraRoute.Chat.route
            ) {
                composable(UltraRoute.Chat.route) {
                    ChatScreen(
                        viewModel = chatVm,
                        speechManager = appContainer.speechAndTtsManager,
                        onNavigateToSettingsApi = {
                            onOpenSettingsTab(2)
                            navController.navigate(UltraRoute.Settings.route)
                        }
                    )
                }
                composable(UltraRoute.Battle.route) {
                    BattleScreen(
                        viewModel = battleVm,
                        onNavigateToSettingsApi = {
                            onOpenSettingsTab(2)
                            navController.navigate(UltraRoute.Settings.route)
                        }
                    )
                }
                composable(UltraRoute.Team.route) {
                    TeamScreen(
                        viewModel = teamVm,
                        onNavigateToSettingsApi = {
                            onOpenSettingsTab(2)
                            navController.navigate(UltraRoute.Settings.route)
                        }
                    )
                }
                composable(UltraRoute.Games.route) {
                    GameCenterScreen(viewModel = gamesVm)
                }
                composable(UltraRoute.Hub.route) {
                    ModulesHubScreen(
                        onOpenCharacters = { navController.navigate(UltraRoute.Characters.route) },
                        onOpenTools = { navController.navigate(UltraRoute.Tools.route) },
                        onOpenSettings = {
                            onOpenSettingsTab(0)
                            navController.navigate(UltraRoute.Settings.route)
                        },
                        onOpenApiSettings = {
                            onOpenSettingsTab(2)
                            navController.navigate(UltraRoute.Settings.route)
                        }
                    )
                }
                composable(UltraRoute.Characters.route) {
                    CharactersScreen(
                        viewModel = charsVm,
                        onStartChatWithCharacter = { charId ->
                            chatVm.startNewChat(characterId = charId)
                            navController.navigate(UltraRoute.Chat.route)
                        },
                        onOpenExistingSession = { sessionId ->
                            chatVm.selectSession(sessionId)
                            navController.navigate(UltraRoute.Chat.route)
                        }
                    )
                }
                composable(UltraRoute.Tools.route) {
                    ToolsScreen(
                        viewModel = toolsVm,
                        speechManager = appContainer.speechAndTtsManager
                    )
                }
                composable(UltraRoute.Settings.route) {
                    SettingsScreen(
                        viewModel = settingsVm,
                        initialTab = settingsInitialTab
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ModulesHubScreen(
    onOpenCharacters: () -> Unit,
    onOpenTools: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenApiSettings: () -> Unit
) {
    val cards = listOf(
        Triple("Postacie AI", "Twórz własne persony z pamięcią, temperaturą i historią rozmów", Icons.Outlined.Face to onOpenCharacters),
        Triple("Narzędzia Dodatkowe", "Research, Code Studio, Writer, Translator, Tutor, PDF/TXT, Obrazy, Statystyki i Kopie", Icons.Outlined.Build to onOpenTools),
        Triple("Klucze API i Modele", "Google Gemini, Groq, test połączenia i limity", Icons.Outlined.AutoAwesome to onOpenApiSettings),
        Triple("Ustawienia Aplikacji", "Wygląd, domyślne parametry AI, PIN, biometria i zaawansowane", Icons.Outlined.Settings to onOpenSettings)
    )

    Scaffold(
        topBar = { TopAppBar(title = { Text("Moduły ULTRA AI") }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            cards.forEach { (title, desc, pair) ->
                val (icon, onClick) = pair
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 1.dp,
                    modifier = Modifier.fillMaxWidth().clickable { onClick() }
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(title, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(desc, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}
