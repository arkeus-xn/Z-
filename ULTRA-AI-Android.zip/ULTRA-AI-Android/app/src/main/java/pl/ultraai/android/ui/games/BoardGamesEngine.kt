package pl.ultraai.android.ui.games

import kotlin.random.Random

/**
 * Silnik Kółko i krzyżyk z pełną walidacją wygranej i algorytmem Minimax.
 */
object TicTacToeEngine {
    val winLines = listOf(
        listOf(0, 1, 2), listOf(3, 4, 5), listOf(6, 7, 8),
        listOf(0, 3, 6), listOf(1, 4, 7), listOf(2, 5, 8),
        listOf(0, 4, 8), listOf(2, 4, 6)
    )

    fun checkWinner(board: List<String>): String? {
        for (line in winLines) {
            val a = board[line[0]]
            if (a.isNotEmpty() && a == board[line[1]] && a == board[line[2]]) return a
        }
        return null
    }

    fun isDraw(board: List<String>): Boolean = checkWinner(board) == null && board.none { it.isEmpty() }

    fun legalMoves(board: List<String>): List<Int> = board.indices.filter { board[it].isEmpty() }

    fun bestMinimaxMove(board: List<String>, aiMark: String = "O", humanMark: String = "X"): Int? {
        val legal = legalMoves(board)
        if (legal.isEmpty()) return null
        var bestScore = Int.MIN_VALUE
        var bestMove = legal.first()
        for (idx in legal) {
            val next = board.toMutableList().apply { this[idx] = aiMark }
            val score = minimax(next, false, aiMark, humanMark, 0)
            if (score > bestScore) {
                bestScore = score
                bestMove = idx
            }
        }
        return bestMove
    }

    private fun minimax(board: List<String>, isMax: Boolean, ai: String, human: String, depth: Int): Int {
        val w = checkWinner(board)
        if (w == ai) return 10 - depth
        if (w == human) return depth - 10
        if (board.none { it.isEmpty() }) return 0

        val legal = legalMoves(board)
        return if (isMax) {
            var best = Int.MIN_VALUE
            for (idx in legal) {
                val next = board.toMutableList().apply { this[idx] = ai }
                best = maxOf(best, minimax(next, false, ai, human, depth + 1))
            }
            best
        } else {
            var best = Int.MAX_VALUE
            for (idx in legal) {
                val next = board.toMutableList().apply { this[idx] = human }
                best = minOf(best, minimax(next, true, ai, human, depth + 1))
            }
            best
        }
    }
}

/**
 * Silnik Connect Four (7 kolumn x 6 wierszy) z grawitacją i detekcją 4 w linii.
 */
object ConnectFourEngine {
    const val ROWS = 6
    const val COLS = 7

    fun emptyBoard(): List<List<Int>> = List(ROWS) { List(COLS) { 0 } } // 0 = puste, 1 = gracz, 2 = AI

    fun legalColumns(board: List<List<Int>>): List<Int> =
        (0 until COLS).filter { col -> board[0][col] == 0 }

    fun dropDisc(board: List<List<Int>>, col: Int, player: Int): List<List<Int>>? {
        if (col !in 0 until COLS || board[0][col] != 0) return null
        val next = board.map { it.toMutableList() }
        for (r in (ROWS - 1) downTo 0) {
            if (next[r][col] == 0) {
                next[r][col] = player
                return next.map { it.toList() }
            }
        }
        return null
    }

    fun checkWinner(board: List<List<Int>>): Int? {
        val dirs = listOf(0 to 1, 1 to 0, 1 to 1, 1 to -1)
        for (r in 0 until ROWS) {
            for (c in 0 until COLS) {
                val p = board[r][c]
                if (p == 0) continue
                for ((dr, dc) in dirs) {
                    var count = 1
                    for (step in 1..3) {
                        val nr = r + dr * step
                        val nc = c + dc * step
                        if (nr in 0 until ROWS && nc in 0 until COLS && board[nr][nc] == p) count++ else break
                    }
                    if (count == 4) return p
                }
            }
        }
        return null
    }

    fun pickSmartColumn(board: List<List<Int>>): Int? {
        val legal = legalColumns(board)
        if (legal.isEmpty()) return null
        // 1. Natychmiastowa wygrana AI
        for (c in legal) {
            val sim = dropDisc(board, c, 2)!!
            if (checkWinner(sim) == 2) return c
        }
        // 2. Blokada wygranej gracza
        for (c in legal) {
            val sim = dropDisc(board, c, 1)!!
            if (checkWinner(sim) == 1) return c
        }
        // 3. Preferuj środek planszy
        return legal.minByOrNull { kotlin.math.abs(it - 3) }
    }
}

/**
 * Silnik 2048 z pełnym przesuwaniem, łączeniem kafelków i detekcją końca gry.
 */
enum class Direction2048 { UP, DOWN, LEFT, RIGHT }

data class Game2048State(
    val grid: List<List<Int>>,
    val score: Int = 0,
    val isGameOver: Boolean = false,
    val won2048: Boolean = false
)

object Game2048Engine {

    fun initialState(): Game2048State {
        var g = List(4) { List(4) { 0 } }
        g = spawnTile(g)
        g = spawnTile(g)
        return Game2048State(grid = g)
    }

    fun move(state: Game2048State, dir: Direction2048): Game2048State {
        if (state.isGameOver) return state
        var gained = 0
        var moved = false
        val newGrid = MutableList(4) { MutableList(4) { 0 } }

        for (i in 0..3) {
            val line = when (dir) {
                Direction2048.LEFT -> (0..3).map { state.grid[i][it] }
                Direction2048.RIGHT -> (3 downTo 0).map { state.grid[i][it] }
                Direction2048.UP -> (0..3).map { state.grid[it][i] }
                Direction2048.DOWN -> (3 downTo 0).map { state.grid[it][i] }
            }
            val (merged, pts) = slideAndMerge(line)
            gained += pts
            if (merged != line) moved = true

            for (j in 0..3) {
                when (dir) {
                    Direction2048.LEFT -> newGrid[i][j] = merged[j]
                    Direction2048.RIGHT -> newGrid[i][3 - j] = merged[j]
                    Direction2048.UP -> newGrid[j][i] = merged[j]
                    Direction2048.DOWN -> newGrid[3 - j][i] = merged[j]
                }
            }
        }

        if (!moved) return state
        val spawned = spawnTile(newGrid.map { it.toList() })
        val has2048 = spawned.any { row -> row.any { it >= 2048 } }
        val over = !hasMovesAvailable(spawned)
        return Game2048State(
            grid = spawned,
            score = state.score + gained,
            isGameOver = over,
            won2048 = state.won2048 || has2048
        )
    }

    private fun slideAndMerge(line: List<Int>): Pair<List<Int>, Int> {
        val nonZero = line.filter { it != 0 }
        val out = mutableListOf<Int>()
        var pts = 0
        var i = 0
        while (i < nonZero.size) {
            if (i + 1 < nonZero.size && nonZero[i] == nonZero[i + 1]) {
                val merged = nonZero[i] * 2
                out.add(merged)
                pts += merged
                i += 2
            } else {
                out.add(nonZero[i])
                i++
            }
        }
        while (out.size < 4) out.add(0)
        return out to pts
    }

    private fun spawnTile(grid: List<List<Int>>): List<List<Int>> {
        val empties = mutableListOf<Pair<Int, Int>>()
        for (r in 0..3) for (c in 0..3) if (grid[r][c] == 0) empties.add(r to c)
        if (empties.isEmpty()) return grid
        val (r, c) = empties.random()
        val value = if (Random.nextFloat() < 0.9f) 2 else 4
        return grid.mapIndexed { ri, row ->
            row.mapIndexed { ci, cell -> if (ri == r && ci == c) value else cell }
        }
    }

    private fun hasMovesAvailable(grid: List<List<Int>>): Boolean {
        for (r in 0..3) for (c in 0..3) {
            if (grid[r][c] == 0) return true
            if (r < 3 && grid[r][c] == grid[r + 1][c]) return true
            if (c < 3 && grid[r][c] == grid[r][c + 1]) return true
        }
        return false
    }
}

enum class RpsChoice(val labelPl: String, val emoji: String) {
    ROCK("Kamień", "🪨"),
    PAPER("Papier", "📄"),
    SCISSORS("Nożyce", "✂️");

    fun beats(other: RpsChoice): Boolean =
        (this == ROCK && other == SCISSORS) ||
            (this == PAPER && other == ROCK) ||
            (this == SCISSORS && other == PAPER)
}
