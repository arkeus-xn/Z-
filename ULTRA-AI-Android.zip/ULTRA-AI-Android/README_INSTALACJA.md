# ULTRA AI – Natywna aplikacja Android (Kotlin + Jetpack Compose + Material 3)

## Wymagania uruchomienia
- **Android Studio Ladybug (2024.2+) lub nowszy**
- **JDK 17**
- **Android SDK Platform 35** (minSdk 28 / Android 9.0+)
- Fizyczny telefon z Androidem 9+ (włączone Debugowanie USB) lub Emulator Android Studio

## Instrukcja budowy APK i instalacji na telefonie
1. Rozpakuj archiwum `ULTRA-AI-Android.zip`.
2. Otwórz folder w Android Studio (`File -> Open...`) i poczekaj na synchronizację Gradle.
3. Podłącz telefon z Androidem przez kabel USB (włącz *Opcje programistyczne -> Debugowanie USB*) i zatwierdź odcisk klucza RSA na ekranie telefonu.
4. Kliknij **Run ▶** w Android Studio, aby zainstalować aplikację bezpośrednio na telefonie, LUB zbuduj plik APK:
   - W Android Studio: `Build -> Build Bundle(s) / APK(s) -> Build APK(s)`.
   - Z wiersza poleceń: `./gradlew assembleDebug` (wyjściowy plik: `app/build/outputs/apk/debug/app-debug.apk`).
   - Instalacja przez ADB: `adb install -r app/build/outputs/apk/debug/app-debug.apk`.

## Pierwsza konfiguracja
1. Otwórz w aplikacji zakładkę **Moduły -> Klucze API i Modele** (lub **Ustawienia -> API**).
2. Dodaj swój klucz **Google Gemini API** (Google AI Studio) i/lub **Groq API** (Groq Console).
3. Kliknij **Testuj** — aplikacja pobierze aktualną listę modeli bezpośrednio z oficjalnego API i wyświetli status połączenia.
4. Klucze są szyfrowane lokalnie przez **Android Keystore (AES-256-GCM)**, bez serwera pośredniczącego.
